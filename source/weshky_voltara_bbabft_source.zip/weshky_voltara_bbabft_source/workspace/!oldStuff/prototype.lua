_G.X = _G.X or {}
local X = _G.X

X.library = loadstring(game:HttpGet("https://raw.githubusercontent.com/Vyrusspcs/weshkyv2/refs/heads/main/server/library2.lua"))()
X.listing = loadstring(game:HttpGet("https://raw.githubusercontent.com/Vyrusspcs/weshkyv2/refs/heads/main/server/listing.lua"))()
local NormalColorBlock = loadstring(game:HttpGet("https://raw.githubusercontent.com/Vyrusspcs/weshkyv2/refs/heads/main/special/extras/blockcolors.lua"))()
local lualzw = loadstring(game:HttpGet("https://raw.githubusercontent.com/Rochet2/lualzw/master/lualzw.lua"))()
print(X.library)

local apikey = "i-know-the-key-is-visible-please-be-kind"
X.ReplicatedStorage = game:GetService("ReplicatedStorage")
X.HttpService = game:GetService("HttpService")
X.Players = game:GetService("Players")
X.Workspace = game:GetService("Workspace")

if not isfolder("WeshkyBuildStorage") then
    makefolder("WeshkyBuildStorage")
    workspace.CheckCodeFunction:InvokeServer("=D")
    workspace.CheckCodeFunction:InvokeServer("=p")
    workspace.CheckCodeFunction:InvokeServer("hi")
    workspace.CheckCodeFunction:InvokeServer("squid army")
    workspace.CheckCodeFunction:InvokeServer("chillthrill709 was here")
end

local MainHighlight = X.Workspace:FindFirstChild("Global_Preview_Highlight")
if not MainHighlight then
    MainHighlight = Instance.new("Highlight")
    MainHighlight.Name = "Global_Preview_Highlight"
    MainHighlight.FillColor = Color3.fromRGB(83, 101, 153)
    MainHighlight.OutlineColor = Color3.fromRGB(14, 17, 26)
    MainHighlight.FillTransparency = 0.85
    MainHighlight.OutlineTransparency = 0.3
    MainHighlight.DepthMode = Enum.HighlightDepthMode.AlwaysOnTop
    MainHighlight.Parent = X.Workspace
end

X.CurrentZone = nil
local BuildingParts = X.ReplicatedStorage.BuildingParts

function X.StringToByteTable(str)
    local bytes = {}
    for i = 1, #str do
        table.insert(bytes, string.byte(str, i))
    end
    return bytes
end

function X.ByteTableToString(bytes)
    local str = ""
    for _, byte in ipairs(bytes) do
        str = str .. string.char(byte)
    end
    return str
end

function X.SafeCompress(jsonString)
    local compressed = lualzw.compress(jsonString)
    if not compressed then
        return jsonString
    end
    
    local byteTable = X.StringToByteTable(compressed)
    local encoded = X.HttpService:JSONEncode(byteTable)
    return "STRUCTURE:" .. encoded
end

function X.SafeDecompress(data)
    if type(data) ~= "string" or data == "" then
        return data
    end
    
    if string.sub(data, 1, 10) == "STRUCTURE:" then
        local encoded = string.sub(data, 11)
        local decodeSuccess, byteTable = pcall(function()
            return X.HttpService:JSONDecode(encoded)
        end)
        
        if decodeSuccess and byteTable and type(byteTable) == "table" then
            local decompressSuccess, decompressed = pcall(function()
                local binaryString = X.ByteTableToString(byteTable)
                return lualzw.decompress(binaryString)
            end)
            
            if decompressSuccess and decompressed and decompressed ~= "" then
                return decompressed
            end
        end
    end
    
    return data
end

X.Config = {
    zones = {
        blue = workspace["Really blueZone"],
        yellow = workspace["New YellerZone"],
        red = workspace["Really redZone"],
        magenta = workspace.MagentaZone,
        black = workspace.BlackZone,
        white = workspace.WhiteZone,
        green = workspace.CamoZone,
    },
    speedMode = 1,
    safeMode = false,
}

local BuildPreview = nil

if workspace:FindFirstChild("BuildPreview") then
    BuildPreview = workspace.BuildPreview
else
    BuildPreview = Instance.new("Model")
    BuildPreview.Name = "BuildPreview"
    BuildPreview.Parent = workspace
end

local player = X.Players.LocalPlayer
local playerData = player.Data
local deg = 57.29577951308232
local precision = 0.01
local defaultSize = Vector3.new(2, 2, 2)

local Color3_new = Color3.new
local Color3_fromRGB = Color3.fromRGB
local Vector3_new = Vector3.new
X.CFrame_new = CFrame.new
local CFrame_Angles = CFrame.Angles

X.math_floor = math.floor
local math_ceil = math.ceil

X.math_rad = math.rad
local math_pow = math.pow
local math_abs = math.abs

local string_split = string.split
local string_gsub = string.gsub
local string_find = string.find

X.table_insert = table.insert
local table_remove = table.remove

local loadstring = loadstring
local unpack = unpack
local task_spawn = task.spawn

local remoteInvoke = Instance.new("RemoteFunction").InvokeServer
local remoteFire = Instance.new("RemoteEvent").FireServer

local modelSetPrimary = Instance.new("Model").SetPrimaryPartCFrame

local workspaceFind = workspace.FindFirstChild
local workspaceDescendants = workspace.GetDescendants
local workspaceChildren = workspace.GetChildren
local workspaceDestroy = workspace.Destroy
local workspaceClone = workspace.Clone

local CFrameToAngles = CFrame.new().ToEulerAnglesXYZ
local CFrameToObjectSpace = CFrame.new().ToObjectSpace

local request = syn and syn.request or request or http_request

local rotX = 0
local rotY = 0 
local rotZ = 0
local moveMultiplier = 1

function X.ColorsAreEqual(color1, color2, tolerance)
    tolerance = tolerance or 0.01 -- tolerance 0.01%
    return math_abs(color1.R - color2.R) <= tolerance and
           math_abs(color1.G - color2.G) <= tolerance and
           math_abs(color1.B - color2.B) <= tolerance
end

function X.ShouldPaintBlock(blockName, targetColor)
    local defaultColorData = NormalColorBlock[blockName]
    
    if not defaultColorData then
        return true
    end
    
    local defaultColor = Color3.new(
        defaultColorData[1] or 1,
        defaultColorData[2] or 1,
        defaultColorData[3] or 1
    )
    
    return not X.ColorsAreEqual(targetColor, defaultColor)
end

function X.ShouldWait(index)
    if X.Config.speedMode == 3 then
        wait(0.0001) 
        return true
    end
    if X.Config.speedMode == 2 then
        wait(0.05)
        return true
    end
    if X.Config.speedMode == 1 then
        if index % 2 == 0 then
            task.wait()
        end
        return true
    end
    return true
end

function X.Memoize(func)
    local cache = setmetatable({}, { __mode = "v" })
    return function(key)
        local value = cache[key]
        if not value then
            value = func(key)
            cache[key] = value
        end
        return value
    end
end

function X.ListBuilds()
    local files = listfiles("WeshkyBuildStorage")
    local builds = {}
    for _, file in next, files, nil do
        -- Check for both .Build and .vBuild files
        if string.sub(file, #file - 5, #file) == ".Build" or string.sub(file, #file - 6, #file) == ".vBuild" then
            local fileName = file:match(".+/(.+)") or file
            local buildName = string.sub(fileName, 1, #fileName - (string.sub(file, #file - 5, #file) == ".Build" and 6 or 7))
            X.table_insert(builds, {name = buildName, path = file}) 
        end
    end
    return builds
end

function X.DecodeColor(encoded)
    -- Handle different color formats
    if type(encoded) == "number" then
        -- In Lua 5.1 (Roblox), we need to use math.floor and division
        local r = math.floor(encoded / 16777216)  -- 256^3
        local remaining = encoded - (r * 16777216)
        local g = math.floor(remaining / 65536)    -- 256^2
        remaining = remaining - (g * 65536)
        local b = math.floor(remaining / 256)      -- 256^1
        local a = remaining - (b * 256)             -- 256^0
        
        return {
            Color = Color3.fromRGB(r, g, b),
            Alpha = a
        }
    elseif type(encoded) == "string" then
        local r, g, b, a = string.match(encoded, "(%d+),(%d+),(%d+),(%d+)")
        if r and g and b and a then
            return {
                Color = Color3.fromRGB(tonumber(r), tonumber(g), tonumber(b)),
                Alpha = tonumber(a)
            }
        end
        
        local r, g, b = string.match(encoded, "(%d+),(%d+),(%d+)")
        if r and g and b then
            return {
                Color = Color3.fromRGB(tonumber(r), tonumber(g), tonumber(b)),
                Alpha = 255
            }
        end
    end
    
    return {
        Color = Color3.new(1, 1, 1),
        Alpha = 255
    }
end

X.GetColor = X.Memoize(X.DecodeColor)

function X.CreateInstance(className, properties)
    local instance = Instance.new(className)
    for property, value in next, properties, nil do
        instance[property] = value
    end
    return instance
end

function X.AnglesString(angles)
    local split = string_split(angles, ",")
    return CFrame_Angles(X.math_rad(split[1]), X.math_rad(split[2]), X.math_rad(split[3]))
end

function X.String(value)
    return string_gsub(tostring(value), " ", "")
end

function X.Raw(value)
    return unpack(string_split(value, ","))
end

function X.Floor(value, decimals)
    return X.math_floor((value * 10 ^ decimals + 0.5)) / 10 ^ decimals
end

function X.GetStringAngles(cframe)
    local x, y, z = CFrameToAngles(cframe)
    return X.Floor(x * deg, 5) .. "," .. X.Floor(y * deg, 5) .. "," .. X.Floor(z * deg, 5)
end

function X.GetAngles(cframe)
    local x, y, z = CFrameToAngles(cframe)
    return CFrame_Angles(x, y, z)
end

function X.GetTeam()
    print(player.Team)
end

function X.GetPlot()
    return X.Config.zones[tostring(player.Team)]
end

local teamPlayersCache = {}

function X.GetTeamPlayers(team)
	local players = {}
	for _, player in ipairs(X.Players:GetPlayers()) do
		if tostring(player.Team) == team then
			X.table_insert(players, player.Name)
		end
	end
	return players
end

function X.GetBlocks(team)
    local teamPlayers = X.GetTeamPlayers(team)
    local blocks = {}
    
    for _, playerName in ipairs(teamPlayers) do
        local playerBlocks = workspace.Blocks:FindFirstChild(playerName)
        
        if playerBlocks then
            for _, block in ipairs(playerBlocks:GetChildren()) do
                if block:FindFirstChild("Health") then
                    X.table_insert(blocks, block)
                end
            end
        end
    end
    
    return blocks
end

function X.GetTeamBlocks(team)
	return X.GetBlocks(team)
end

function X.GetPreviewBlocks()
    local blocks = {}
    for _, block in next, workspaceChildren(BuildPreview), nil do
        X.table_insert(blocks, block)
    end
    return blocks
end

function X.GetTool(toolName)
    local tool = workspaceFind(player.Backpack, toolName)
    if tool then
        tool = player.Backpack[toolName].RF
        if tool then
            return tool
        end
    else
        tool = workspaceFind(player.Character, toolName)
        if tool then
            tool = player.Character[toolName].RF
            return tool
        end
    end
    return nil
end

local existingGui = game:GetService("CoreGui"):FindFirstChild("progressBar")
if existingGui then
    existingGui:Destroy()
end

local screenGui = X.CreateInstance("ScreenGui", {
    Parent = game:GetService("CoreGui"),
    Name = "progressBar",
})

local progressBar = X.CreateInstance("Frame", {
    Parent = screenGui,
    Name = "ProgressContainer",
    BackgroundColor3 = Color3_fromRGB(20, 20, 20),
    BackgroundTransparency = 0.025,
    BorderSizePixel = 0,
    Position = UDim2.new(0, 10, 1, -97),
    Size = UDim2.new(0, 300, 0, 90),
})

-- Add corner radius
X.CreateInstance("UICorner", {
    Parent = progressBar,
    CornerRadius = UDim.new(0, 8),
})

-- Add border stroke
X.CreateInstance("UIStroke", {
    Parent = progressBar,
    Color = Color3_fromRGB(50, 50, 50),
    Thickness = 1,
    ApplyStrokeMode = Enum.ApplyStrokeMode.Border,
})

-- Title
X.CreateInstance("TextLabel", {
    Parent = progressBar,
    BackgroundTransparency = 1,
    Position = UDim2.new(0, 15, 0, 15),
    Size = UDim2.new(1, -30, 0, 18),
    Font = Enum.Font.GothamBold,
    Text = "Building Progress",
    TextColor3 = Color3_fromRGB(255, 255, 255),
    TextSize = 13,
    TextXAlignment = Enum.TextXAlignment.Left,
    TextYAlignment = Enum.TextYAlignment.Top,
    ZIndex = 2,
})

-- Progress bar background
X.CreateInstance("Frame", {
    Parent = progressBar,
    BackgroundColor3 = Color3_fromRGB(64, 64, 64),
    BorderSizePixel = 0,
    Position = UDim2.new(0, 15, 0, 43),
    Size = UDim2.new(1, -30, 0, 14),
    ZIndex = 1,
})

X.CreateInstance("UICorner", {
    Parent = progressBar:FindFirstChild("Frame"),
    CornerRadius = UDim.new(0, 3),
})

-- Progress bar fill
local progressFill = X.CreateInstance("Frame", {
    Parent = progressBar:FindFirstChild("Frame"),
    Name = "ProgressFill",
    BackgroundColor3 = Color3_fromRGB(59, 130, 246),
    BorderSizePixel = 0,
    Position = UDim2.new(0, 0, 0, 0),
    Size = UDim2.new(0, 0, 1, 0),
    ZIndex = 2,
})

X.CreateInstance("UICorner", {
    Parent = progressFill,
    CornerRadius = UDim.new(0, 3),
})

-- Progress text (percentage) - overlay on bar
local progressText = X.CreateInstance("TextLabel", {
    Parent = progressBar,
    BackgroundTransparency = 1,
    Position = UDim2.new(0, 15, 0, 43),
    Size = UDim2.new(1, -30, 0, 14),
    Font = Enum.Font.GothamBold,
    Text = "0%",
    TextColor3 = Color3_fromRGB(255, 255, 255),
    TextSize = 12,
    TextXAlignment = Enum.TextXAlignment.Center,
    TextYAlignment = Enum.TextYAlignment.Center,
    ZIndex = 3,
})

-- Action text
local actionText = X.CreateInstance("TextLabel", {
    Parent = progressBar,
    BackgroundTransparency = 1,
    Position = UDim2.new(0, 15, 0, 67),
    Size = UDim2.new(1, -30, 0, 14),
    Font = Enum.Font.GothamBold,
    Text = "Ready",
    TextColor3 = Color3_fromRGB(200, 200, 200),
    TextSize = 11,
    TextXAlignment = Enum.TextXAlignment.Left,
    TextYAlignment = Enum.TextYAlignment.Top,
    ZIndex = 2,
})

local totalBlocks = 0
local processedBlocks = 0
local currentStatus = "Ready"
local currentAction = "Building"
local scaledBlocksCount = 0
local propertiesBlocksCount = 0
local paintedBlocksCount = 0

function X.UpdateProgression(text)
    local progress = progressText
    local typeofText = typeof(text)
    local progressValue = 0
    
    if typeofText == "number" then
        progressValue = math.min(math_ceil(text), 100)
        typeofText = progressValue .. "%"
    else
        typeofText = text
        progressValue = 0
    end
    
    progress.Text = typeofText
    
    -- Animate the progress bar fill
    local bgFrame = progressBar:FindFirstChild("Frame")
    if bgFrame then
        local fillElement = bgFrame:FindFirstChild("ProgressFill")
        if fillElement then
            local barWidth = bgFrame.AbsoluteSize.X
            local fillWidth = (progressValue / 100) * barWidth
            local tweenInfo = TweenInfo.new(
                0.2,
                Enum.EasingStyle.Quad,
                Enum.EasingDirection.Out
            )
            local tween = game:GetService("TweenService"):Create(
                fillElement,
                tweenInfo,
                { Size = UDim2.new(0, fillWidth, 1, 0) }
            )
            tween:Play()
        end
    end
end

-- Enhanced progression update with status and block count
function X.UpdateProgressionWithStatus(progress, status, blocksProcessed, blocksTotal)
    -- Update progress bar percentage
    if progress then
        X.UpdateProgression(progress)
    end
    
    -- Update action text
    if status then
        currentAction = status
        actionText.Text = status
    end
end

-- Quick status update function
function X.SetStatus(statusMessage)
    currentAction = statusMessage
    actionText.Text = statusMessage
end

-- Set total blocks count
function X.SetTotalBlocks(count)
    totalBlocks = count
    processedBlocks = 0
end

-- Increment processed block count
function X.IncrementBlocksProcessed()
    processedBlocks = processedBlocks + 1
    return processedBlocks
end

-- ============================================
-- AUTO-WELD SYSTEM DEFINITION
-- ============================================
X.AutoWeld = {
    Enabled = true,
    WeldedBlocks = {},
    PendingWelds = {},
    Initialized = false,
}

function X.AutoWeld:WeldParts(part0, part1, weldName)
    if not self.Enabled then return nil end
    
    -- Check if already welded
    local key = part0:GetFullName() .. ":" .. part1:GetFullName()
    if self.WeldedBlocks[key] then return self.WeldedBlocks[key] end
    
    -- Create weld with proper CFrame
    local weld = Instance.new("Weld")
    weld.Name = weldName or "AutoWeld"
    weld.Part0 = part0
    weld.Part1 = part1
    
    -- Calculate correct relative position
    weld.C0 = CFrame.new()
    weld.C1 = part1.CFrame:toObjectSpace(part0.CFrame)
    
    -- Add required tag for server sync
    game:GetService("CollectionService"):AddTag(weld, "ClientCanUpdate")
    
    -- Parent to part0
    weld.Parent = part0
    
    -- Track it
    self.WeldedBlocks[key] = weld
    table.insert(self.PendingWelds, weld)
    
    return weld
end

function X.AutoWeld:ScanAndWeld(model)
    if not self.Enabled then return end
    
    -- Get all parts in the model
    local parts = {}
    for _, child in ipairs(model:GetDescendants()) do
        if child:IsA("BasePart") then
            table.insert(parts, child)
        end
    end
    
    -- Check each pair of parts
    for i = 1, #parts do
        for j = i + 1, #parts do
            local partA, partB = parts[i], parts[j]
            
            -- Calculate if they're touching
            local dist = (partA.Position - partB.Position).Magnitude
            local threshold = (partA.Size.Magnitude + partB.Size.Magnitude) / 2 + 0.1
            
            if dist <= threshold then
                self:WeldParts(partA, partB, "TouchWeld")
            end
        end
    end
end

function X.AutoWeld:SyncToServer()
    if #self.PendingWelds == 0 then return end
    
    -- Get weld sync remote
    local player = game.Players.LocalPlayer
    local weldScript = workspace:FindFirstChild(player.Name) and 
                      workspace[player.Name]:FindFirstChild("UpdateWeldLS")
    
    if not weldScript then return end
    
    local sendRemote = weldScript:FindFirstChild("UpdateOtherClientsRE")
    if not sendRemote then return end
    
    -- Prepare batch
    local syncData = {}
    for _, weld in ipairs(self.PendingWelds) do
        table.insert(syncData, {weld, weld.C0, weld.C1})
        
        -- Add to main batch
        if #syncData >= 20 then
            sendRemote:FireServer(syncData)
            syncData = {}
            task.wait()
        end
    end
    
    -- Send remaining
    if #syncData > 0 then
        sendRemote:FireServer(syncData)
    end
    
    -- Clear pending
    self.PendingWelds = {}
end

function X.AutoWeld:ProcessNewBlock(block)
    if not self.Enabled then return end
    
    task.spawn(function()
        -- Wait for block to initialize
        task.wait(0.1)
        
        -- Weld internal parts
        self:ScanAndWeld(block)
        
        -- Check neighbors
        local blockPos = block.PrimaryPart and block.PrimaryPart.Position
        if not blockPos then return end
        
        -- Find nearby blocks in the same plot
        local player = game.Players.LocalPlayer
        local playerBlocks = workspace.Blocks:FindFirstChild(player.Name)
        
        if playerBlocks then
            for _, otherBlock in ipairs(playerBlocks:GetChildren()) do
                if otherBlock ~= block and otherBlock.PrimaryPart then
                    local dist = (blockPos - otherBlock.PrimaryPart.Position).Magnitude
                    if dist < 10 then -- Within welding range
                        -- Get parts from both blocks
                        local blockParts = {}
                        for _, p in ipairs(block:GetDescendants()) do
                            if p:IsA("BasePart") then table.insert(blockParts, p) end
                        end
                        
                        local otherParts = {}
                        for _, p in ipairs(otherBlock:GetDescendants()) do
                            if p:IsA("BasePart") then table.insert(otherParts, p) end
                        end
                        
                        -- Weld touching parts between blocks
                        for _, p1 in ipairs(blockParts) do
                            for _, p2 in ipairs(otherParts) do
                                local d = (p1.Position - p2.Position).Magnitude
                                if d <= (p1.Size.Magnitude + p2.Size.Magnitude) / 2 + 0.1 then
                                    self:WeldParts(p1, p2, "InterBlockWeld")
                                end
                            end
                        end
                    end
                end
            end
        end
        
        -- Periodic sync
        if #self.PendingWelds >= 10 then
            self:SyncToServer()
        end
    end)
end

function X.AutoWeld:Init()
    if self.Initialized then return end
    self.Initialized = true
    
    -- Monitor for new blocks
    local player = game.Players.LocalPlayer
    local playerBlocks = workspace.Blocks:FindFirstChild(player.Name)
    
    if playerBlocks then
        playerBlocks.ChildAdded:Connect(function(block)
            self:ProcessNewBlock(block)
        end)
    end
    
    -- Periodic sync thread
    task.spawn(function()
        while self.Enabled do
            task.wait(2)
            self:SyncToServer()
        end
    end)
end

function X.AutoWeld:ProcessAllBlocks(blocks)
    if not self.Enabled then return end
    
    X.SetStatus("Welding Blocks")
    
    -- First, weld internal parts of each block
    for _, blockInfo in ipairs(blocks) do
        self:ScanAndWeld(blockInfo.Block)
        task.wait()
    end
    
    -- Then weld between blocks
    for i = 1, #blocks do
        for j = i + 1, #blocks do
            local block1 = blocks[i].Block
            local block2 = blocks[j].Block
            
            if block1.PrimaryPart and block2.PrimaryPart then
                local dist = (block1.PrimaryPart.Position - block2.PrimaryPart.Position).Magnitude
                if dist < 15 then
                    -- Get all parts from both blocks
                    local parts1 = {}
                    for _, p in ipairs(block1:GetDescendants()) do
                        if p:IsA("BasePart") then table.insert(parts1, p) end
                    end
                    
                    local parts2 = {}
                    for _, p in ipairs(block2:GetDescendants()) do
                        if p:IsA("BasePart") then table.insert(parts2, p) end
                    end
                    
                    -- Check each pair
                    for _, p1 in ipairs(parts1) do
                        for _, p2 in ipairs(parts2) do
                            local d = (p1.Position - p2.Position).Magnitude
                            local threshold = (p1.Size.Magnitude + p2.Size.Magnitude) / 2 + 0.5
                            if d <= threshold then
                                self:WeldParts(p1, p2, "BuildWeld")
                            end
                        end
                    end
                end
            end
        end
        if i % 10 == 0 then task.wait() end
    end
    
    -- Final sync
    self:SyncToServer()
end

local function getBindToolRF()
    local character = LocalPlayer.Character
    local backpack = LocalPlayer:FindFirstChild("Backpack")
    local tool = (character and character:FindFirstChild("BindTool")) or (backpack and backpack:FindFirstChild("BindTool"))
    return tool and (tool:FindFirstChild("RF") or tool:FindFirstChild("RF2"))
end

local CollectionService = game:GetService("CollectionService")

local function isControllerModel(model)
    if not model or not model:IsA("Model") then return false end
    if model:FindFirstChild("ControllerId") or model:FindFirstChild("ControllerRefTemplate") then
        return true
    end
    if model:FindFirstChild("VehicleSeat") then
        return true
    end
    local n = model.Name
    if n == "Lever" or n == "Switch" or n == "SwitchBig" or n == "Button" or n == "Delay" or n == "Gate" then
        return true
    end
    if CollectionService:HasTag(model, "SeatInput") or CollectionService:HasTag(model, "SwitchInput") then
        return true
    end
    return false
end

local function getAllControllers()
    local blocksFolder = workspace:FindFirstChild("Blocks")
    if not blocksFolder then return {} end
    local controllers = {}
    for _, folder in ipairs(blocksFolder:GetChildren()) do
        for _, model in ipairs(folder:GetChildren()) do
            if isControllerModel(model) then
                table.insert(controllers, model)
            end
        end
    end
    return controllers
end

local function findControllerForBlock(block)
    local blocksFolder = workspace:FindFirstChild("Blocks")
    if not blocksFolder then return nil end
    for _, folder in ipairs(blocksFolder:GetChildren()) do
        for _, model in ipairs(folder:GetChildren()) do
            if model:IsA("Model") then
                for _, child in ipairs(model:GetChildren()) do
                    if child:IsA("Beam") and child.Attachment1 and child.Attachment1.Parent and child.Attachment1.Parent.Parent == block then
                        return model
                    end
                end
            end
        end
    end
    return nil
end

local function findBlockByNameAndPos(blockName, posString)
    local blocksFolder = workspace:FindFirstChild("Blocks")
    if not blocksFolder then return nil end
    if not posString then
        for _, folder in ipairs(blocksFolder:GetChildren()) do
            local block = folder:FindFirstChild(blockName)
            if block and block:IsA("Model") then
                return block
            end
        end
        return nil
    end

    local ok, targetPos = pcall(function()
        return Vector3_new(X.Raw(posString))
    end)
    if not ok then
        return nil
    end

    local best = nil
    local bestDist = math.huge
    for _, folder in ipairs(blocksFolder:GetChildren()) do
        for _, block in ipairs(folder:GetChildren()) do
            if block:IsA("Model") and block.Name == blockName then
                local part = block:FindFirstChild("PPart") or block.PrimaryPart
                if part then
                    local dist = (part.Position - targetPos).Magnitude
                    if dist < bestDist then
                        best = block
                        bestDist = dist
                    end
                end
            end
        end
    end
    return best
end

local function findControllerByHint(name, posString)
    local blocksFolder = workspace:FindFirstChild("Blocks")
    if not blocksFolder then return nil end
    local best = nil
    local bestDist = math.huge

    local targetPos = nil
    if posString then
        local ok, vec = pcall(function()
            return Vector3_new(X.Raw(posString))
        end)
        if ok then
            targetPos = vec
        end
    end

    for _, folder in ipairs(blocksFolder:GetChildren()) do
        for _, model in ipairs(folder:GetChildren()) do
            if model:IsA("Model") and model.Name == name then
                if not targetPos or not model.PrimaryPart then
                    return model
                end
                local dist = (model.PrimaryPart.Position - targetPos).Magnitude
                if dist < bestDist then
                    best = model
                    bestDist = dist
                end
            end
        end
    end
    return best
end

function X.ExtractConnections(teamName)
    local connections = {}
    
    local teamPlayers = X.GetTeamPlayers(teamName)
    if not teamPlayers or #teamPlayers == 0 then
        return connections
    end
    
    local zone = X.Config.zones[teamName] or X.GetPlot()
    if not zone then
        return connections
    end
    
    -- First pass: collect all controllers
    local controllers = {}
    for _, playerName in ipairs(teamPlayers) do
        local playerFolder = workspace.Blocks:FindFirstChild(playerName)
        if playerFolder then
            for _, block in ipairs(playerFolder:GetChildren()) do
                if block:IsA("Model") then
                    local isController = block.Name:match("Switch") 
                        or block.Name:match("Button") 
                        or block.Name:match("Lever")
                        or block.Name:match("Gate")
                        or block.Name:match("Delay")
                        or block.Name:match("VehicleSeat")
                        or block.Name:match("CarSeat")
                        or block.Name:match("PilotSeat")
                    
                    if isController then
                        local part = block:FindFirstChild("PPart") or block.PrimaryPart
                        if part then
                            -- Convert to RELATIVE position (same as how blocks are saved)
                            local relativeCF = zone.CFrame:ToObjectSpace(part.CFrame)
                            controllers[block] = {
                                type = block.Name,
                                position = relativeCF.p,
                                model = block
                            }
                        end
                    end
                end
            end
        end
    end
    
    -- Find connections
    for controller, controllerInfo in pairs(controllers) do
        for _, playerName in ipairs(teamPlayers) do
            local playerFolder = workspace.Blocks:FindFirstChild(playerName)
            if playerFolder then
                for _, block in ipairs(playerFolder:GetChildren()) do
                    if block:IsA("Model") and block ~= controller then
                        local connected = false
                        local connectionType = nil
                        
                        -- Check for ControllerId
                        local controllerId = block:FindFirstChild("ControllerId")
                        if controllerId and controllerId.Value == controller then
                            connected = true
                            connectionType = "ControllerId"
                        end
                        
                        -- Check for ControllerRef
                        local controllerRef = block:FindFirstChild("ControllerRef")
                        if controllerRef and controllerRef.Value == controller then
                            connected = true
                            connectionType = "ControllerRef"
                        end
                        
                        -- Check for weld constraints
                        if not connected then
                            for _, constraint in ipairs(controller:GetDescendants()) do
                                if constraint:IsA("WeldConstraint") or constraint:IsA("Weld") then
                                    local part0 = constraint.Part0
                                    local part1 = constraint.Part1
                                    
                                    if (part0 and part0:IsDescendantOf(block)) or 
                                       (part1 and part1:IsDescendantOf(block)) then
                                        connected = true
                                        connectionType = "WeldConstraint"
                                        break
                                    end
                                end
                            end
                        end
                        
                        if connected then
                            local targetPart = block:FindFirstChild("PPart") or block.PrimaryPart
                            if targetPart then
                                -- Convert target position to RELATIVE
                                local targetRelativeCF = zone.CFrame:ToObjectSpace(targetPart.CFrame)
                                
                                table.insert(connections, {
                                    ControllerType = controller.Name,
                                    ControllerPos = X.String(controllerInfo.position), -- Already relative
                                    TargetType = block.Name,
                                    TargetPos = X.String(targetRelativeCF.p),
                                    ConnectionType = connectionType
                                })
                            end
                        end
                    end
                end
            end
        end
    end
    
    return connections
end

function X.ExtractKeybinds(teamName)
    local keybinds = {}
    
    local teamPlayers = X.GetTeamPlayers(teamName)
    if not teamPlayers or #teamPlayers == 0 then
        return keybinds
    end
    
    local zone = X.Config.zones[teamName] or X.GetPlot()
    if not zone then
        return keybinds
    end
    
    -- First, collect all controllers and their relative positions
    local controllersByModel = {}
    for _, playerName in ipairs(teamPlayers) do
        local playerFolder = workspace.Blocks:FindFirstChild(playerName)
        if playerFolder then
            for _, block in ipairs(playerFolder:GetChildren()) do
                if typeof(block) == "Instance" and block:IsA("Model") then
                    local isController = block.Name:match("Switch") 
                        or block.Name:match("Button") 
                        or block.Name:match("Lever")
                        or block.Name:match("Gate")
                        or block.Name:match("Delay")
                        or block.Name:match("VehicleSeat")
                        or block.Name:match("CarSeat")
                        or block.Name:match("PilotSeat")
                    
                    if isController then
                        local part = block:FindFirstChild("PPart") or block.PrimaryPart
                        if part then
                            local relativeCF = zone.CFrame:ToObjectSpace(part.CFrame)
                            controllersByModel[block] = {
                                name = block.Name,
                                relativePos = relativeCF.p
                            }
                        end
                    end
                end
            end
        end
    end
    
    -- Now find blocks with keybinds to these controllers
    for _, playerName in ipairs(teamPlayers) do
        local playerFolder = workspace.Blocks:FindFirstChild(playerName)
        if playerFolder then
            for _, block in ipairs(playerFolder:GetChildren()) do
                if typeof(block) == "Instance" and block:IsA("Model") then
                    local hasControllerConnection = false
                    local controllerData = {}
                    
                    -- Check for ControllerRef
                    local controllerRef = block:FindFirstChild("ControllerRef")
                    if controllerRef and controllerRef:IsA("ObjectValue") and controllerRef.Value then
                        local controller = controllerRef.Value
                        if controllersByModel[controller] then
                            controllerData.ControllerRef = controller.Name
                            controllerData.ControllerRelativePos = X.String(controllersByModel[controller].relativePos)
                            hasControllerConnection = true
                        end
                    end
                    
                    -- Check for ControllerId
                    local controllerId = block:FindFirstChild("ControllerId")
                    if controllerId and controllerId:IsA("ObjectValue") and controllerId.Value then
                        local controller = controllerId.Value
                        if controllersByModel[controller] then
                            controllerData.ControllerId = controller.Name
                            controllerData.ControllerRelativePos = X.String(controllersByModel[controller].relativePos)
                            hasControllerConnection = true
                        end
                    end
                    
                    -- Only save keybinds for non-controller blocks
                    local isController = block.Name:match("Switch") 
                        or block.Name:match("Button") 
                        or block.Name:match("CarSeat")
                        or block.Name:match("PilotSeat")
                        or block.Name:match("Lever")
                        or block.Name:match("Gate")
                        or block.Name:match("Delay")
                        or block.Name:match("VehicleSeat")
                    
                    if not isController then
                        -- Save actual bind values
                        local bindAttributes = {"BindUp", "BindDown", "BindLeft", "BindRight", "BindFire", "BindAim", "BindInteract"}
                        local blockKeybinds = {}
                        
                        for _, bindName in ipairs(bindAttributes) do
                            local bindValue = block:FindFirstChild(bindName)
                            if bindValue and bindValue:IsA("IntValue") and bindValue.Value ~= -1 then
                                blockKeybinds[bindName] = bindValue.Value
                                hasControllerConnection = true
                            end
                        end
                        
                        if next(blockKeybinds) then
                            controllerData.Keybinds = blockKeybinds
                        end
                    end
                    
                    -- Save if there's any connection
                    if hasControllerConnection then
                        local part = block:FindFirstChild("PPart") or block.PrimaryPart
                        if part then
                            local relativeCF = zone.CFrame:ToObjectSpace(part.CFrame)
                            
                            table.insert(keybinds, {
                                BlockName = block.Name,
                                BlockPos = X.String(relativeCF.p),
                                ControllerData = controllerData
                            })
                        end
                    end
                end
            end
        end
    end
    
    return keybinds
end

function X.Encode(blocks, teamName)
    if not blocks or #blocks == 0 then
        warn("No blocks provided")
        return nil
    end
    
    local encoded = {}
    local zone = nil
    if teamName then
        zone = X.Config.zones[teamName]
        if not zone then
            zone = X.GetPlot()
        end
    else
        zone = X.GetPlot()
    end
    
    if not zone then
        warn("No valid zone found")
        return nil
    end
    
    X.CurrentZone = zone
    local blocksEncoded = 0
    
    for _, block in next, blocks, nil do
        if not block or not block.Name or not block.PPart then
            warn("Invalid block structure", block)
            continue
        end
        
        local blockName = block.Name
        local part = block.PPart
        if not encoded[blockName] then
            encoded[blockName] = {}
        end
        
        local relativeCFrame = CFrameToObjectSpace(zone.CFrame, part.CFrame)
        local blockData = {
            Rotation = X.GetStringAngles(relativeCFrame),
            Position = X.String(relativeCFrame.p),
        }
        
        if part.CastShadow ~= true then
            blockData.ShowShadow = false
        end
        
        if part.CanCollide ~= true then
            blockData.CanCollide = false
        end
        
        if part.Anchored ~= true then
            blockData.Anchored = false
        end
        
        if part.Transparency > 0 then
            blockData.Transparency = part.Transparency
        end
        
        if not string_find(blockName, "Block") or part.Size ~= Vector3_new(2, 2, 2) then
            blockData.Size = X.String(part.Size)
        end
        
        if part.Color ~= BuildingParts[blockName].PPart.Color then
            blockData.Color = X.String(part.Color)
        end
        
        X.table_insert(encoded[blockName], blockData)
        blocksEncoded = blocksEncoded + 1
    end
    
    if blocksEncoded == 0 then
        warn("No blocks were successfully encoded")
        return nil
    end
    
    local success, result = pcall(function()
        return X.HttpService:JSONEncode(encoded)
    end)
    
    if success then
        print("Successfully encoded " .. blocksEncoded .. " blocks")
        return result
    else
        warn("Failed to JSON encode -", result)
        return nil
    end
end

function X.Decode(json, scale)
    if not json or json == "" then
        warn("No JSON data provided")
        return {}
    end
    
    local decoded = {}
    if not scale then
        scale = 1
    end

    local success, result = xpcall(function()
        decoded = X.HttpService:JSONDecode(json)
    end, function(err)
        warn("Invalid JSON -", err)
    end)
    
    if not success then
        return {}
    end

    local blockTypesProcessed = 0
    local totalBlocksDecoded = 0
    
    for blockName, blockData in next, decoded, nil do
        if blockName == "Keybinds" or blockName == "BlockConnections" then
            continue
        end
        if workspaceFind(BuildingParts, blockName) then
            local blocksInType = 0
            for _, data in next, blockData, nil do
                local entry = decoded[blockName][_]
                if entry then
                    local posSuccess, pos = pcall(function()
                        return X.CFrame_new(Vector3_new(X.Raw(data.Position)) * scale)
                    end)
                    local rotSuccess, rot = pcall(function()
                        return X.AnglesString(data.Rotation)
                    end)
                    
                    if posSuccess and rotSuccess then
                        entry.Position = pos
                        entry.Rotation = rot
                        entry.Color = data.Color and pcall(function() return Color3_new(X.Raw(data.Color)) end) and Color3_new(X.Raw(data.Color)) or nil
                        entry.Size = data.Size and (data.Size ~= "2,2,2" and Vector3_new(X.Raw(data.Size)) * scale or nil)
                        decoded[blockName][_] = entry
                        blocksInType = blocksInType + 1
                    else
                        warn("Failed to parse block position/rotation for", blockName)
                    end
                end
            end
            blockTypesProcessed = blockTypesProcessed + 1
            totalBlocksDecoded = totalBlocksDecoded + blocksInType
        else
            warn("Block type not found in BuildingParts -", blockName)
            decoded[blockName] = nil
        end
    end
    print("Successfully decoded " .. totalBlocksDecoded .. " blocks across " .. blockTypesProcessed .. " types")
    return decoded
end

function X.Convert(filename)
    if not filename or filename == "" then
        warn("No filename provided")
        return nil
    end
    
    local success, content = pcall(function()
        return readfile(filename)
    end)
    
    if not success then
        warn("Failed to read file ", filename)
        return nil
    end
    
    if not content or content == "" then
        warn("File is empty ", filename)
        return nil
    end
    
    local converted = {}
    if not string_find(content, "/") then
        return nil
    end
    
    local blocksConverted = 0
    for _, entry in next, string_split(content, "/"), nil do
        if entry and entry ~= "" then
            local parts = string_split(entry, ":")
            if #parts == 5 and workspaceFind(BuildingParts, parts[5]) then
                if not converted[parts[5]] then
                    converted[parts[5]] = {}
                end
                
                local posSuccess, rotSuccess = pcall(function()
                    local relativeCFrame = CFrameToObjectSpace(X.CFrame_new(0, -17.9999924, 0), 
                        X.CFrame_new(X.Raw(parts[1])) * X.AnglesString(parts[2]))
                    
                    local blockInfo = {
                        Color = parts[3] ~= "-" and parts[3] or nil,
                        Size = parts[4] ~= "-" and parts[4] or nil,
                        Position = X.String(relativeCFrame.p),
                        Rotation = X.GetStringAngles(relativeCFrame)
                    }
                    
                    X.table_insert(converted[parts[5]], blockInfo)
                end)
                
                if posSuccess and rotSuccess then
                    blocksConverted = blocksConverted + 1
                else
                    warn("Failed to parse block entry. ", entry)
                end
            end
        end
    end
    
    if blocksConverted == 0 then
        return nil
    end
    
    local encodeSuccess, result = pcall(function()
        return X.HttpService:JSONEncode(converted)
    end)
    
    if encodeSuccess then
        return result
    else
        return nil
    end
end

local function unbindAllWithAllControllers()
	local Players = game:GetService("Players")
	local CollectionService = game:GetService("CollectionService")

	local lp = Players.LocalPlayer

	local function getBindToolRF()
		local backpack = lp:FindFirstChild("Backpack") or lp:WaitForChild("Backpack", 5)
		local char = lp.Character
		local tool = (backpack and backpack:FindFirstChild("BindTool")) or (char and char:FindFirstChild("BindTool"))
		return tool and tool:FindFirstChild("RF")
	end

	local function isController(model)
		if not model then return false end
		if model:FindFirstChild("VehicleSeat") then return true end
		local n = model.Name
		if n == "Lever" or n == "Switch" or n == "SwitchBig" or n == "Button" or n == "Delay" or n == "Gate" then
			return true
		end
		if CollectionService:HasTag(model, "SeatInput") or CollectionService:HasTag(model, "SwitchInput") then
			return true
		end
		return false
	end

	local function getMyBlocks()
		local blocksFolder = workspace:FindFirstChild("Blocks")
		if not blocksFolder then return {} end
		local myFolder = blocksFolder:FindFirstChild(lp.Name)
		if not myFolder then return {} end
		return myFolder:GetChildren()
	end

	local rf = getBindToolRF()
	if not rf then
		return
	end

	local blocks = getMyBlocks()

	local controllers = {}
	local binds = {}

	for _, model in ipairs(blocks) do
		if model:IsA("Model") then
			if isController(model) then
				table.insert(controllers, model)
			end
			-- FIX: Check if child exists and is an IntValue before accessing
			for _, child in ipairs(model:GetChildren()) do
				-- Only process IntValues with names starting with "Bind"
				if child:IsA("IntValue") and child.Name:sub(1, 4) == "Bind" then
					table.insert(binds, child)
				end
			end
		end
	end

	if #controllers == 0 then
		return
	end

	local count = 0
	for _, controller in ipairs(controllers) do
		for _, bindVal in ipairs(binds) do
			-- FIX: Add pcall to handle any errors when invoking
			local success = pcall(function()
				rf:InvokeServer({ bindVal }, controller, -1, true)
			end)
			if success then
				bindVal.Value = -1
				count += 1
			end
			task.wait()
		end
	end
end

local PropertiesToSave = {
    Default = {
        "ShowShadow",  -- PPart.CastShadow (inverted)
        "CanCollide",  -- PPart.CanCollide
        "Anchored",    -- PPart.Anchored
        "Color",       -- PPart.Color (only if different from default)
        "Rotation",    -- Calculated from CFrame
        "Position",    -- Calculated from CFrame
        "Transparency",-- TransparencyModifier.Value or default for GlassBlock
        "Size"         -- Only if not default (2,2,2)
    },
    
    Fireworks = {
        "FlightDistance",
        "FuseTime"
    },

    Jets = {
        JetTurbine = { "MaxForce", "MaxSpeed" },
        SonicJetTurbine = { "MaxForce", "MaxSpeed" },
        SmallJet = { "MaxForce", "MaxSpeed" }
    },
 
    Wheels = {
        WheelBlock = { "MaxSpeed", "ReverseSpin", "WheelTorque" },
        LargeWheel = { "MaxSpeed", "ReverseSpin", "WheelTorque" },
        FrontWheel = { "MaxSpeed", "ReverseSpin", "WheelTorque" },
        BackWheel = { "MaxSpeed", "ReverseSpin", "WheelTorque" },
        RearWheel = { "MaxSpeed", "ReverseSpin", "WheelTorque" },
        LeftWheel = { "MaxSpeed", "ReverseSpin", "WheelTorque" },
        RightWheel = { "MaxSpeed", "ReverseSpin", "WheelTorque" }
    },

    Aim = {
        "Aim"
    },
    
    Cameras = {
        "ShowCrosshairs"
    },
    
    Activators = {
        "On"
    },
    
    Specials = {
        Servo = {
            "ServoTorque",
            "ServoSpeed",
            "ReverseRotation",
            "TargetAngle"
        },
        
        Piston = {
            "ExtendLength",
            "Speed",
            "LastDirrection"
        },
        
        Delay = {
            "WaitDuration"
        },

        Magnet = { --
            "MagnetEnabled"
        },

        ShieldGenerator = {
            "ShieldEnabled"
        },
        
        Note = {
            "SemitoneOffset"
        },
        
        Rope = {
            "Length",
            "MatchRotation",
            "SecondaryPartRotation",
            "SecondaryPartPosition"
        },
        
        Sign = {
            "Text"
        },
        
        CandyRed = {
            "DepthScale",
            "HeadScale",
            "HeightScale",
            "WidthScale"
        },
        CandyBlue = {
            "DepthScale",
            "HeadScale",
            "HeightScale",
            "WidthScale"
        },
        
        Bar = {
            "Length",
            "AngleLimit",
            "MatchRotation",
            "SecondaryPartRotation",
            "SecondaryPartPosition"
        },

        Spring = {
            "Damping",
            "MaxLength",        -- This is actually FreeLength
            "MaxLengthLimit",   -- Actual MaxLength
            "TargetLength",
            "MinLength",
            "Stiffness",
            "SecondaryPartRotation",
            "SecondaryPartPosition"
        }
    },
    
    SpecialCollision = {
        BoxingGlove = {"CanCollide"},         -- From Glove part
        BoatMotor = {"CanCollide"},           -- From Motor.Bottom
        BoatMotorUltra = {"CanCollide"},      -- From Motor.Bottom
        BoatMotorWinter = {"CanCollide"},     -- From Motor.Bottom
        LockedDoor = {"CanCollide"},          -- From Part
        Portal = {"CanCollide"},              -- From Light
        SpikeTrap = {"CanCollide"},           -- From Box
        PineTree = {"CanCollide"},            -- From Leaves4
        WoodDoor = {"CanCollide"},            -- From Door.DoorFrame
        WoodTrapDoor = {"CanCollide"}         -- From Door.DoorFrame
    },
    
    Lamp = {
        "LightColor",  -- From Light.Color
        "LightEnabled" -- From Light.Enabled
    },
    
    VehicleController = {
        "MaxSpeed",
        "ThrustSpeed",
        "TurnSpeed",
        "HoverForce",
        "HoverHeight"
    },
    
    Thrusters = {
        "MaxThrust",
        "ThrustSpeed"
    },
    
    Buttons = {
        "ButtonColor",
        "ButtonState"
    },
    
    Switches = {
        "SwitchState"
    },
    
    Timers = {
        "Interval",
        "Enabled"
    },
    
    TextDisplays = {
        "Text",
        "TextColor",
        "TextSize",
        "BackgroundColor"
    },
    
    NumberDisplays = {
        "Value",
        "TextColor",
        "BackgroundColor"
    },
    
}

local BlockNameAlias = {
    FrontWheel = "WheelBlock",
    RearWheel = "WheelBlock",
    LeftWheel = "WheelBlock",
    RightWheel = "WheelBlock",
    BackWheel = "WheelBlock",  -- ADDED
    BigWheel = "LargeWheel"
}

function X.SavePlot(filename, teamName)
    if not filename or not teamName then
        return
    end

    local cleanFilename = filename:gsub("%.Build$", ""):gsub("%.vBuild$", "")
    local filePath = "WeshkyBuildStorage/" .. cleanFilename .. ".vBuild"
    
    local function GetTeamPlayers(team)
        local players = {}
        for _, player in ipairs(X.Players:GetPlayers()) do
            if tostring(player.Team) == team then
                X.table_insert(players, player.Name)
            end
        end
        return players
    end
    
    local teamPlayers = GetTeamPlayers(teamName)
    if not teamPlayers or #teamPlayers == 0 then
        return
    end
    
    local zone = X.Config.zones[teamName]
    if not zone then
        return
    end
    
    local blockData = {}
    
    for _, playerName in ipairs(teamPlayers) do
        local playerFolder = workspace.Blocks:FindFirstChild(playerName)
        if playerFolder then
            for _, block in ipairs(playerFolder:GetChildren()) do
                if block:IsA("Model") and block:FindFirstChild("PPart") then
                    local PPart = block.PPart
                    local blockInfo = {}
                    
                    blockInfo.ShowShadow = PPart.CastShadow ~= false
                    blockInfo.CanCollide = PPart.CanCollide
                    blockInfo.Anchored = PPart.Anchored
                    
                    local relativeCF = zone.CFrame:ToObjectSpace(PPart.CFrame)
                    local rx, ry, rz = relativeCF:ToEulerAnglesXYZ()
                    blockInfo.Rotation = string.format("%.3f, %.3f, %.3f", math.deg(rx), math.deg(ry), math.deg(rz))
                    blockInfo.Position = string.format("%.6f, %.6f, %.6f", relativeCF.X, relativeCF.Y, relativeCF.Z)
                    
                    if NormalColorBlock[block.Name] then
                        local defaultColor = Color3.new(unpack(NormalColorBlock[block.Name]))
                        if PPart.Color ~= defaultColor then
                            blockInfo.Color = string.format("%.6f, %.6f, %.6f", PPart.Color.R, PPart.Color.G, PPart.Color.B)
                        end
                    else
                        blockInfo.Color = string.format("%.6f, %.6f, %.6f", PPart.Color.R, PPart.Color.G, PPart.Color.B)
                    end
                    
                    if block:FindFirstChild("TransparencyModifier") then
                        blockInfo.Transparency = block.TransparencyModifier.Value
                    elseif block.Name == "GlassBlock" then
                        blockInfo.Transparency = 0.5
                    end
                    
                    if PPart.Size ~= Vector3.new(2, 2, 2) then
                        blockInfo.Size = string.format("%.6f, %.6f, %.6f", PPart.Size.X, PPart.Size.Y, PPart.Size.Z)
                    end

                    if block.Name == "Sign" then
                        local stringInput = block:FindFirstChild("StringInput")
                        if stringInput and stringInput:IsA("StringValue") then
                            blockInfo.Text = stringInput.Value
                        end
                    end
        
                    -- Save ShieldGenerator state
                    if block.Name == "ShieldGenerator" then
                        local onValue = block:FindFirstChild("On")
                        if onValue and onValue:IsA("BoolValue") then
                            -- Save as 1 if true, 0 if false
                            blockInfo.ShieldEnabled = onValue.Value and 1 or 0
                        end
                    end

                    -- Save Magnet state based on TouchInterest existence
                    if block.Name == "Magnet" then
                        local magnetField = block:FindFirstChild("MagnetField")
                        if magnetField then
                            local touchInterest = magnetField:FindFirstChild("TouchInterest")
                            -- Save as 1 if TouchInterest exists, 0 if not
                            blockInfo.MagnetEnabled = touchInterest and 1 or 0
                        end
                    end

                    -- Save LightBulb PointLight enabled state
                    if block.Name == "LightBulb" then
                        local bulbEnd = block:FindFirstChild("BulbEnd")
                        if bulbEnd then
                            local pointLight = bulbEnd:FindFirstChild("PointLight")
                            if pointLight and pointLight:IsA("PointLight") then
                                -- Save as 1 if enabled, 0 if disabled
                                blockInfo.LightEnabled = pointLight.Enabled and 1 or 0
                            end
                        end
                    end

                    -- Save Servo properties from HingeConstraint
                    if block.Name == "Servo" then
                        if PPart:FindFirstChild("HingeConstraint") then
                            local hinge = PPart.HingeConstraint
                            blockInfo.AngularSpeed = hinge.AngularSpeed
                            blockInfo.ServoTorque = hinge.ServoMaxTorque
                        end
                    end

                    if block.Name == "Spring" then
                        local springConstraint = PPart:FindFirstChild("SpringConstraint")
                        if springConstraint and springConstraint:IsA("SpringConstraint") then
                            blockInfo.Damping = springConstraint.Damping
                            blockInfo.Stiffness = springConstraint.Stiffness
                            blockInfo.MinLength = springConstraint.MinLength
                            blockInfo.MaxLength = springConstraint.MaxLength
                            blockInfo.TargetLength = springConstraint.FreeLength
                        end
                    end

                    if block.Name == "Rope" then
                        local RopeConstraint = PPart:FindFirstChild("RopeConstraint")
                        local alignOrientation = PPart:FindFirstChild("AlignOrientation")
                        
                        if RopeConstraint and RopeConstraint:IsA("RopeConstraint") then
                            blockInfo.Length = RopeConstraint.Length
                        end
                        
                        if alignOrientation and alignOrientation:IsA("AlignOrientation") then
                            if alignOrientation:GetAttribute("Enabled") ~= nil then
                                blockInfo.MatchRotation = alignOrientation:GetAttribute("Enabled") and 1 or 0
                            elseif alignOrientation.enabled ~= nil then
                                blockInfo.MatchRotation = alignOrientation.enabled and 1 or 0
                            else
                                blockInfo.MatchRotation = 1
                            end
                        else
                            blockInfo.MatchRotation = 1
                        end
                    end

                    if block.Name == "Bar" then
                        local RodConstraint = PPart:FindFirstChild("RodConstraint")
                        local AlignOrientation = PPart:FindFirstChild("AlignOrientation")
                        
                        if RodConstraint and RodConstraint:IsA("RodConstraint") then
                            blockInfo.Length = RodConstraint.Length
                            blockInfo.AngleLimit = RodConstraint.LimitAngle0
                        end

                        if RodConstraint and RodConstraint:IsA("RodConstraint") then
                            blockInfo.Length = RodConstraint.Length
                        end
                        
                        if AlignOrientation and AlignOrientation:IsA("AlignOrientation") then
                            if AlignOrientation:GetAttribute("Enabled") ~= nil then
                                blockInfo.MatchRotation = AlignOrientation:GetAttribute("Enabled") and 1 or 0
                            elseif AlignOrientation.enabled ~= nil then
                                blockInfo.MatchRotation = AlignOrientation.enabled and 1 or 0
                            else
                                blockInfo.MatchRotation = 1
                            end
                        else
                            blockInfo.MatchRotation = 1
                        end
                    end

                    -- Save properties for ALL block types
                    for category, props in pairs(PropertiesToSave) do
                        if type(props) == "table" then
                            -- Handle ALL wheel types (FrontWheel, BackWheel, etc.)
                            if string.find(block.Name:lower(), "wheel") then
                                -- Save MaxSpeed
                                if block:FindFirstChild("MaxSpeed") then
                                    blockInfo.MaxSpeed = block.MaxSpeed.Value
                                end
                                
                                -- Save ReverseSpin
                                if block:FindFirstChild("ReverseSpin") then
                                    blockInfo.ReverseSpin = block.ReverseSpin.Value
                                end
                                
                                -- Save WheelTorque from HingeConstraint
                                if block.PPart and block.PPart:FindFirstChild("HingeConstraint") then
                                    local hinge = block.PPart.HingeConstraint
                                    if hinge:IsA("HingeConstraint") then
                                        blockInfo.WheelTorque = hinge.MotorMaxTorque
                                    end
                                end
                                
                            else
                                -- Handle other block types using the alias system
                                local realName = BlockNameAlias[block.Name] or block.Name
                                for blockType, propList in pairs(props) do
                                    if blockType == realName then
                                        for _, prop in ipairs(propList) do
                                            if block:FindFirstChild(prop) then
                                                blockInfo[prop] = block[prop].Value
                                            end
                                        end
                                    end
                                end
                            end
                        end
                    end
                    
                    if block.Name == "Rope" or block.Name == "Bar" or block.Name == "Spring" then
                        if block:FindFirstChild("SecondaryPart") then
                            local secCF = zone.CFrame:ToObjectSpace(block.SecondaryPart.Part.CFrame)
                            local srx, sry, srz = secCF:ToEulerAnglesXYZ()
                            blockInfo.SecondaryPartRotation = string.format("%.3f, %.3f, %.3f", math.deg(srx), math.deg(sry), math.deg(srz))
                            blockInfo.SecondaryPartPosition = string.format("%.6f, %.6f, %.6f", secCF.X, secCF.Y, secCF.Z)
                        end
                    end
                    
                    if not blockData[block.Name] then
                        blockData[block.Name] = {}
                    end
                    
                    X.table_insert(blockData[block.Name], blockInfo)
                end
            end
        end
    end
    
    if not next(blockData) then
        return
    end
    
    local jsonData = {}
    for blockName, blocks in pairs(blockData) do
        jsonData[blockName] = blocks
    end
    
    -- Extract and save keybinds
    local keybinds = X.ExtractKeybinds(teamName)
    if #keybinds > 0 then
        jsonData.Keybinds = keybinds
        print("Saved", #keybinds, "keybind(s)")
    end
    
    -- Extract and save block connections (which switch is connected to which wheel)
    local connections = X.ExtractConnections(teamName)
    if #connections > 0 then
        jsonData.BlockConnections = connections
        print("Saved", #connections, "block connection(s)")
    end

    -- Save proper controller connections
    for _, playerName in ipairs(teamPlayers) do
        local playerFolder = workspace.Blocks:FindFirstChild(playerName)
        if playerFolder then
            for _, block in ipairs(playerFolder:GetChildren()) do
                if block:IsA("Model") then
                    -- Save ControllerId and ControllerRef connections
                    local controllerId = block:FindFirstChild("ControllerId")
                    local controllerRef = block:FindFirstChild("ControllerRef")
                    
                    if controllerId and controllerId:IsA("ObjectValue") and typeof(controllerId.Value) == "Instance" then
                        if not blockInfo then blockInfo = {} end
                        blockInfo.ControllerId = controllerId.Value.Name
                    end

                    if controllerRef and controllerRef:IsA("ObjectValue") and typeof(controllerRef.Value) == "Instance" then
                        if not blockInfo then blockInfo = {} end
                        blockInfo.ControllerRef = controllerRef.Value.Name
                    end
                    
                    -- DON'T save BindUp/BindDown for switches (they're always -1)
                    local isController = block.Name:match("Switch") 
                        or block.Name:match("Button") 
                        or block.Name:match("CarSeat")
                        or block.Name:match("PilotSeat")
                    
                    if not isController then
                        -- Only save meaningful bind values (not -1)
                        local bindUp = block:FindFirstChild("BindUp")
                        local bindDown = block:FindFirstChild("BindDown")
                        
                        if bindUp and bindUp.Value ~= -1 then
                            if not blockInfo then blockInfo = {} end
                            blockInfo.BindUp = bindUp.Value
                        end
                        
                        if bindDown and bindDown.Value ~= -1 then
                            if not blockInfo then blockInfo = {} end
                            blockInfo.BindDown = bindDown.Value
                        end
                    end
                end
            end
        end
    end

    local success, err = pcall(function()
        local jsonString = X.HttpService:JSONEncode(jsonData)
        local compressed = X.SafeCompress(jsonString)
        writefile(filePath, compressed)
    end)
    
    if success then
        print("Build saved successfully to " .. filePath)
    else
        warn("Error saving build:", err)
    end
end

function X.ClearPreview()
    for _, child in next, workspaceChildren(BuildPreview), nil do
        workspaceDestroy(child)
    end
end

X.ClearPreview()

local Players = game:GetService("Players")
local LocalPlayer = Players.LocalPlayer

function X.LoadBlocks(blocksData, teamName, keybindsData, connectionsData)
    if not blocksData or not next(blocksData) then
        warn("No block data provided")
        return false
    end
    
    local zone = teamName and X.Config.zones[teamName] or X.GetPlot()
    if not zone then
        warn("No valid zone")
        return false
    end

    local buildingTool = X.GetTool("BuildingTool")
    local scalingTool = X.GetTool("ScalingTool")
    local paintingTool = X.GetTool("PaintingTool")
    
    local propertiesTool = nil
    local setPropertieRF = nil

    if LocalPlayer.Character then
        propertiesTool = LocalPlayer.Character:FindFirstChild("PropertiesTool")
    end
    if not propertiesTool then
        local backpack = LocalPlayer:FindFirstChild("Backpack")
        if backpack then
            propertiesTool = backpack:FindFirstChild("PropertiesTool")
        end
    end

    if propertiesTool then
        setPropertieRF = propertiesTool:FindFirstChild("SetPropertieRF")
    end

    totalBlocks = 0
    processedBlocks = 0
    local blockTypesCount = 0
    
    for blockType, blockList in pairs(blocksData) do
        -- skip meta entries that are not block types
        if blockType == "Keybinds" or blockType == "BlockConnections" then
            continue
        end
        if not playerData[blockType] then
            warn("Player doesnt have data for block type:", blockType)
            continue
        end
        totalBlocks += #blockList
        blockTypesCount = blockTypesCount + 1
    end
    
    if totalBlocks == 0 then
        warn("No blocks to load")
        return false
    end
    
    X.SetStatus("Placing blocks")
    X.UpdateProgression(0)

    local pendingBlocks = {}
    local processedBlocksList = {}
    local connections = {}
    local placedPositions = {}

    local function onBlockAdded(block)
        if not block:FindFirstChild("PPart") then
            block:WaitForChild("PPart", 2)
            if not block.PPart then return end
        end

        local blockPos = block.PPart.Position
        for i, pending in ipairs(pendingBlocks) do
            if (blockPos - pending.Position).Magnitude < 0.5 then
                table.insert(processedBlocksList, {
                    Block = block,
                    Data = pending.Data
                })
                table.remove(pendingBlocks, i)
                processedBlocks += 1
                X.UpdateProgression((processedBlocks / totalBlocks * 50))
                break
            end
        end
    end

    for _, folder in ipairs(workspace.Blocks:GetDescendants()) do
        if folder:IsA("Folder") then
            local conn = folder.ChildAdded:Connect(onBlockAdded)
            table.insert(connections, conn)
        end
    end

    for blockType, blockList in pairs(blocksData) do
        if blockType == "Keybinds" or blockType == "BlockConnections" then
            continue
        end
        local blockCount = (playerData[blockType] and playerData[blockType].Value) or 0
        local usedBlocks = (playerData[blockType] and playerData[blockType].Used and playerData[blockType].Used.Value) or 0

        for index, blockData in ipairs(blockList) do
            if blockCount - usedBlocks >= index then
                local position = blockData.Position
                local rotation = blockData.Rotation
                if type(position) == "string" then
                    position = X.CFrame_new(Vector3_new(X.Raw(position)))
                end
                if type(rotation) == "string" then
                    rotation = X.AnglesString(rotation)
                end
                
                local cframe = zone.CFrame * position * rotation
                placedPositions[tostring(cframe.Position)] = true

                if blockType == "Spring" or blockType == "Bar" or blockType == "Rope" then
                    if blockData.SecondaryPartPosition and blockData.SecondaryPartRotation then
                        local secPosition = X.CFrame_new(Vector3_new(X.Raw(blockData.SecondaryPartPosition)))
                        local secRotation = X.AnglesString(blockData.SecondaryPartRotation)
                        local secondaryCFrame = zone.CFrame * secPosition * secRotation
                        
                        local args = {
                            blockType,
                            blockCount,
                            zone,
                            cframe,
                            blockData.Anchored ~= false,
                            cframe,
                            secondaryCFrame
                        }
                        
                        if X.ShouldWait(index) then
                            local success, err = pcall(function()
                                remoteInvoke(buildingTool, unpack(args))
                            end)
                            
                            if not success then
                                local args2 = {
                                    blockType,
                                    blockCount,
                                    zone,
                                    secondaryCFrame,
                                    blockData.Anchored ~= false,
                                    secondaryCFrame,
                                    cframe
                                }
                                pcall(function()
                                    remoteInvoke(buildingTool, unpack(args2))
                                end)
                            end
                        end
                        
                        -- Add Spring/Bar/Rope blocks to processedBlocksList so properties can be applied
                        if buildingTool then
                            -- We need to wait for the block to be created before adding it
                            local created = false
                            local createdBlock = nil
                            
                            for i = 1, 100 do
                                local playerFolder = workspace.Blocks:FindFirstChild(player.Name)
                                if playerFolder then
                                    for _, b in ipairs(playerFolder:GetChildren()) do
                                        if b.Name == blockType then
                                            local blockPos = b:FindFirstChild("PPart") and b.PPart.Position or b.Position
                                            if (blockPos - cframe.p).Magnitude < 1 then
                                                table.insert(processedBlocksList, {
                                                    Block = b,
                                                    Data = blockData
                                                })
                                                created = true
                                                break
                                            end
                                        end
                                    end
                                end
                                if created then break end
                                task.wait(0.01)
                            end
                        end
                        
                        usedBlocks = usedBlocks + 1
                        processedBlocks = processedBlocks + 1
                        X.UpdateProgression((processedBlocks / totalBlocks * 50))
                        continue
                    end
                end
                
                if blockData.Size or blockData.Color then
                    table.insert(pendingBlocks, {
                        Position = cframe.p,
                        Data = blockData
                    })
                end

                if X.ShouldWait(index) then
                    task.spawn(remoteInvoke, buildingTool, blockType, blockCount, nil, nil,
                            blockData.Anchored ~= false, cframe)
                end
                
                usedBlocks = usedBlocks + 1
                processedBlocks = processedBlocks + 1
                X.UpdateProgression((processedBlocks / totalBlocks * 50))
            else
                warn("Not enough blocks for", blockType)
                break
            end
        end
    end

    local timeoutTime = 30
    local startTime = os.clock()
    local lastCount = #pendingBlocks

    repeat
        wait(0.5)
        if #pendingBlocks == lastCount then
            if os.clock() - startTime > timeoutTime then
                warn("Timeout waiting for blocks to place")
                break
            end
        else
            lastCount = #pendingBlocks
            startTime = os.clock()
        end
    until #pendingBlocks == 0

    for _, conn in ipairs(connections) do
        conn:Disconnect()
    end

    unbindAllWithAllControllers()
    task.wait(5)

    local bindToolRF_forConnections = nil
    pcall(function()
        bindToolRF_forConnections = LocalPlayer.Character and LocalPlayer.Character:FindFirstChild("BindTool") and LocalPlayer.Character.BindTool:FindFirstChild("RF")
        if not bindToolRF_forConnections then
            local bp = LocalPlayer:FindFirstChild("Backpack")
            if bp and bp:FindFirstChild("BindTool") then
                bindToolRF_forConnections = bp.BindTool:FindFirstChild("RF")
            end
        end
    end)

    if connectionsData and type(connectionsData) == "table" and #connectionsData > 0 then
        for _, connEntry in ipairs(connectionsData) do
            local ctrlName = connEntry.ControllerType
            local ctrlPosStr = connEntry.ControllerPos
            local targetType = connEntry.TargetType
            local targetPosStr = connEntry.TargetPos
            local ctype = connEntry.ConnectionType

            local okc, crel = pcall(function() return Vector3_new(X.Raw(ctrlPosStr)) end)
            local okt, trel = pcall(function() return Vector3_new(X.Raw(targetPosStr)) end)
            if not okc or not okt then
                continue
            end

            local absCtrlPos = (zone and zone.CFrame or X.GetPlot().CFrame) * X.CFrame_new(crel)
            local absTargetPos = (zone and zone.CFrame or X.GetPlot().CFrame) * X.CFrame_new(trel)

            local foundController = nil
            local foundTarget = nil
            local bestCtrlDist = math.huge
            local bestTargetDist = math.huge

            for _, folder in ipairs(workspace.Blocks:GetChildren()) do
                for _, m in ipairs(folder:GetChildren()) do
                    if m:IsA("Model") then
                        local mp = m:FindFirstChild("PPart") or m.PrimaryPart
                        if mp then
                            local d1 = (mp.Position - absCtrlPos.p).Magnitude
                            if m.Name == ctrlName and d1 < bestCtrlDist then
                                bestCtrlDist = d1
                                foundController = m
                            end
                            local d2 = (mp.Position - absTargetPos.p).Magnitude
                            if m.Name == targetType and d2 < bestTargetDist then
                                bestTargetDist = d2
                                foundTarget = m
                            end
                        end
                    end
                end
            end

            local DIST_LIMIT = 1.1
            if bestCtrlDist > DIST_LIMIT then
                foundController = nil
            end
            if bestTargetDist > DIST_LIMIT then
                foundTarget = nil
            end

            if foundController and foundTarget then
                local val = foundTarget:FindFirstChild(ctype)
                if val and val:IsA("ObjectValue") then
                    val.Value = foundController
                else
                    local bound = false
                    if bindToolRF_forConnections then
                        for _, child in ipairs(foundTarget:GetChildren()) do
                            if child:IsA("IntValue") and child.Name:sub(1,4) == "Bind" then
                                pcall(function()
                                    bindToolRF_forConnections:InvokeServer({ child }, foundController, child.Value or -1, false)
                                end)
                                bound = true
                                --
                                break
                            end
                        end
                        if not bound then
                            local descendant = foundTarget:FindFirstChild("BindUp", true) or foundTarget:FindFirstChild("BindDown", true) or foundTarget:FindFirstChild("BindLeft", true) or foundTarget:FindFirstChild("BindRight", true)
                            if descendant and descendant:IsA("IntValue") then
                                pcall(function()
                                    bindToolRF_forConnections:InvokeServer({ descendant }, foundController, descendant.Value or -1, false)
                                end)
                                bound = true
                            end
                        end
                    end
                    if not bound then
                        -- print("error")
                    end
                end
            end
        end
    end

    local nameToPlaced = {}
    local placedList = {}
    for _, pb in ipairs(processedBlocksList) do
        if pb.Block then
            table.insert(placedList, pb.Block)
            nameToPlaced[pb.Block.Name] = nameToPlaced[pb.Block.Name] or {}
            table.insert(nameToPlaced[pb.Block.Name], pb.Block)
        end
    end

    if keybindsData and type(keybindsData) == "table" and #keybindsData > 0 then
        local bindToolRF = nil
        pcall(function()
            bindToolRF = LocalPlayer.Character and LocalPlayer.Character:FindFirstChild("BindTool") and LocalPlayer.Character.BindTool:FindFirstChild("RF")
            if not bindToolRF then
                local bp = LocalPlayer:FindFirstChild("Backpack")
                if bp and bp:FindFirstChild("BindTool") then
                    bindToolRF = bp.BindTool:FindFirstChild("RF")
                end
            end
        end)

        if bindToolRF then
            for _, entry in ipairs(keybindsData) do
                local blockName = entry.BlockName
                local blockPosStr = entry.BlockPos
                local controllerData = entry.ControllerData or {}

                local ok, relPos = pcall(function()
                    return Vector3_new(X.Raw(blockPosStr))
                end)
                if not ok or not relPos then
                    continue
                end
                local targetPos = (zone and zone.CFrame or X.GetPlot().CFrame) * X.CFrame_new(relPos)

                local targetBlock = nil
                local candidates = nameToPlaced[blockName]
                local DIST_LIMIT = 1.1
                if candidates then
                    local bestDist = math.huge
                    for _, cand in ipairs(candidates) do
                        local part = cand:FindFirstChild("PPart") or cand.PrimaryPart
                        if part then
                            local d = (part.Position - targetPos.p).Magnitude
                            if d < bestDist then
                                bestDist = d
                                targetBlock = cand
                            end
                        end
                    end
                    if bestDist > DIST_LIMIT then
                        targetBlock = nil
                    end
                end

                if not targetBlock then
                    local bestDist = math.huge
                    for _, m in ipairs(placedList) do
                        local part = m:FindFirstChild("PPart") or m.PrimaryPart
                        if part and m.Name == blockName then
                            local d = (part.Position - targetPos.p).Magnitude
                            if d < bestDist then
                                bestDist = d
                                targetBlock = m
                            end
                        end
                    end
                    if bestDist > DIST_LIMIT then
                        targetBlock = nil
                    end
                end

                if not targetBlock then
                    continue
                end

                local controllerInstance = nil
                if controllerData.ControllerRelativePos then
                    local ok2, crel = pcall(function()
                        return Vector3_new(X.Raw(controllerData.ControllerRelativePos))
                    end)
                    if ok2 and crel then
                        local absCPos = (zone and zone.CFrame or X.GetPlot().CFrame) * X.CFrame_new(crel)
                        local bestDist = math.huge
                        local desiredName = controllerData.ControllerRef or controllerData.ControllerId
                        if desiredName then
                            for _, m in ipairs(placedList) do
                                if m.Name == desiredName then
                                    local mp = m:FindFirstChild("PPart") or m.PrimaryPart
                                    if mp then
                                        local d = (mp.Position - absCPos.p).Magnitude
                                        if d < bestDist then
                                            bestDist = d
                                            controllerInstance = m
                                        end
                                    end
                                end
                            end
                            if not controllerInstance then
                                for _, m in ipairs(placedList) do
                                    local mp = m:FindFirstChild("PPart") or m.PrimaryPart
                                    if mp then
                                        local d = (mp.Position - absCPos.p).Magnitude
                                        if d < bestDist then
                                            bestDist = d
                                            controllerInstance = m
                                        end
                                    end
                                end
                            end
                        else
                            for _, m in ipairs(placedList) do
                                local mp = m:FindFirstChild("PPart") or m.PrimaryPart
                                if mp then
                                    local d = (mp.Position - absCPos.p).Magnitude
                                    if d < bestDist then
                                        bestDist = d
                                        controllerInstance = m
                                    end
                                end
                            end
                        end
                    end
                end

                if not controllerInstance and (controllerData.ControllerRef or controllerData.ControllerId) then
                    local searchName = controllerData.ControllerRef or controllerData.ControllerId
                    local bestDist = math.huge
                    local targetReferencePos = nil
                    do
                        local part = targetBlock and (targetBlock:FindFirstChild("PPart") or targetBlock.PrimaryPart)
                        if part then targetReferencePos = part.Position end
                    end
                    local candidates = nameToPlaced[searchName]
                    local DIST_LIMIT = 1.1
                    if candidates then
                        local bestDist = math.huge
                        for _, cand in ipairs(candidates) do
                            local mp = cand:FindFirstChild("PPart") or cand.PrimaryPart
                            if mp and targetReferencePos then
                                local d = (mp.Position - targetReferencePos).Magnitude
                                if d < bestDist then
                                    bestDist = d
                                    controllerInstance = cand
                                end
                            elseif mp and not targetReferencePos then
                                controllerInstance = cand
                                break
                            end
                        end
                        if bestDist > DIST_LIMIT then
                            controllerInstance = nil
                        end
                    else
                        local bestDist = math.huge
                        for _, cand in ipairs(placedList) do
                            if cand.Name == searchName then
                                local mp = cand:FindFirstChild("PPart") or cand.PrimaryPart
                                if mp and targetReferencePos then
                                    local d = (mp.Position - targetReferencePos).Magnitude
                                    if d < bestDist then
                                        bestDist = d
                                        controllerInstance = cand
                                    end
                                elseif mp and not targetReferencePos then
                                    controllerInstance = cand
                                    break
                                end
                            end
                        end
                        if bestDist > DIST_LIMIT then
                            controllerInstance = nil
                        end
                    end
                end

                if not controllerInstance then
                    local part = targetBlock:FindFirstChild("PPart") or targetBlock.PrimaryPart
                    if part then
                        local bestDist = math.huge
                        for _, folder in ipairs(workspace.Blocks:GetChildren()) do
                            for _, m in ipairs(folder:GetChildren()) do
                                if m:IsA("Model") and isControllerModel(m) then
                                    local mp = m:FindFirstChild("PPart") or m.PrimaryPart
                                    if mp then
                                        local d = (mp.Position - part.Position).Magnitude
                                        if d < bestDist then
                                            bestDist = d
                                            controllerInstance = m
                                        end
                                    end
                                end
                            end
                        end
                    end
                end

                if controllerInstance and controllerData.Keybinds then
                    for bindName, keyCode in pairs(controllerData.Keybinds) do
                        local bindVal = targetBlock:FindFirstChild(bindName)
                        if bindVal and bindVal:IsA("IntValue") then
                            local success, err = pcall(function()
                                bindToolRF:InvokeServer({ bindVal }, controllerInstance, tonumber(keyCode) or keyCode, false)
                            end)
                            if success then
                                bindVal.Value = tonumber(keyCode) or keyCode
                                task.wait(0.075)
                            else
                                --warn("Bind invoke failed:", bindName, err)
                            end
                        end
                    end
                end
            end
        end
    end

    X.SetStatus("Scaling blocks")
    X.UpdateProgression(25)
    scaledBlocksCount = 0
    for i, blockInfo in ipairs(processedBlocksList) do
        if blockInfo.Data.Size then
            if X.ShouldWait(i) then
                task.spawn(remoteInvoke, scalingTool, blockInfo.Block, blockInfo.Data.Size, blockInfo.Block.PPart.CFrame)
            end
            scaledBlocksCount = scaledBlocksCount + 1
            X.UpdateProgression(25 + (scaledBlocksCount / #processedBlocksList * 25))
        end
    end
    X.UpdateProgression(50)

    X.SetStatus("Applying properties")
    X.UpdateProgression(50)
    propertiesBlocksCount = 0
    for _, blockInfo in ipairs(processedBlocksList) do
        local part = blockInfo.Block
        local data = blockInfo.Data

        if setPropertieRF then
            if data.ShowShadow ~= nil then
                local times3 = data.ShowShadow and 0 or 1
                for i = 1, times3 do
                    local success = pcall(function()
                        setPropertieRF:InvokeServer("Cast shadow", {part}, data.ShowShadow)
                    end)
                    if not success then break end
                end
            end

            if data.CanCollide ~= nil then
                local times = data.CanCollide and 0 or 1
                for i = 1, times do
                    local success = pcall(function()
                        setPropertieRF:InvokeServer("Collision", {part}, data.CanCollide)
                    end)
                    if not success then break end
                end
            end

            if data.Anchored ~= nil then
                local times2 = data.Anchored and 0 or 1
                for i = 1, times2 do
                    local success = pcall(function()
                        setPropertieRF:InvokeServer("Anchored", {part}, data.Anchored)
                    end)
                    if not success then break end
                end
            end

            if data.Transparency ~= nil then
                local steps = math.floor(data.Transparency / 0.25 + 0.5)
                for i = 1, steps do
                    local success = pcall(function()
                        setPropertieRF:InvokeServer("Transparency", {part}, 0.25)
                    end)
                    if not success then break end
                end
            end
        end
        
        propertiesBlocksCount = propertiesBlocksCount + 1
        X.UpdateProgression(50 + (propertiesBlocksCount / #processedBlocksList * 25))
    end
    X.UpdateProgression(75)

    for _, blockInfo in ipairs(processedBlocksList) do
        local block = blockInfo.Block
        local data = blockInfo.Data

        if block.Name == "FrontWheel" then
            if not setPropertieRF then return end

            if data.MaxSpeed then
                local speedCycle = {40, 30, 20, 10, 5, 4, 3, 2, 1, 0.5, 50}
                local targetSpeed = data.MaxSpeed

                local clicksNeeded = 0
                for i, speed in ipairs(speedCycle) do
                    if speed == targetSpeed then
                        clicksNeeded = i - 1
                        break
                    end
                end

                for i = 1, clicksNeeded do
                    setPropertieRF:InvokeServer("Wheel speed", {block})
                end
            end

            if data.ReverseSpin == true then
                setPropertieRF:InvokeServer("Reverse spin", {block}, true)
            end

            if data.WheelTorque then
                local targetTorque = tonumber(data.WheelTorque)

                if targetTorque == 1_000_000 then
                    --print("wheel got standard torque")
                else
                    local requiredClicks = 0

                    if targetTorque == 10_000_000 then
                        requiredClicks = 1
                    elseif targetTorque == 100_000_000 then
                        requiredClicks = 2
                    elseif targetTorque == 1_000_000_000 then
                        requiredClicks = 3
                    elseif targetTorque == 10_000_000_000 then
                        requiredClicks = 4
                    else
                        requiredClicks = 0
                    end

                    print(string.format(
                        requiredClicks,
                        targetTorque
                    ))

                    for i = 1, requiredClicks do
                        setPropertieRF:InvokeServer("Wheel torque", {block})
                        task.wait(0.01)
                    end
                end
            end
        end

        if block.Name == "BackWheelCookie" then
            if not setPropertieRF then return end

            if data.MaxSpeed then
                local speedCycle = {40, 30, 20, 10, 5, 4, 3, 2, 1, 0.5, 50}
                local targetSpeed = data.MaxSpeed

                local clicksNeeded = 0
                for i, speed in ipairs(speedCycle) do
                    if speed == targetSpeed then
                        clicksNeeded = i - 1
                        break
                    end
                end

                for i = 1, clicksNeeded do
                    setPropertieRF:InvokeServer("Wheel speed", {block})
                end
            end

            if data.ReverseSpin == true then
                setPropertieRF:InvokeServer("Reverse spin", {block}, true)
            end

            if data.WheelTorque then
                local targetTorque = tonumber(data.WheelTorque)

                if targetTorque == 1_000_000 then
                    --print("wheel got standard torque")
                else
                    local requiredClicks = 0

                    if targetTorque == 10_000_000 then
                        requiredClicks = 1
                    elseif targetTorque == 100_000_000 then
                        requiredClicks = 2
                    elseif targetTorque == 1_000_000_000 then
                        requiredClicks = 3
                    elseif targetTorque == 10_000_000_000 then
                        requiredClicks = 4
                    else
                        requiredClicks = 0
                    end

                    print(string.format(
                        requiredClicks,
                        targetTorque
                    ))

                    for i = 1, requiredClicks do
                        setPropertieRF:InvokeServer("Wheel torque", {block})
                    end
                end
            end
        end

        if block.Name == "FrontWheelCookie" then
            if not setPropertieRF then return end

            if data.MaxSpeed then
                local speedCycle = {40, 30, 20, 10, 5, 4, 3, 2, 1, 0.5, 50}
                local targetSpeed = data.MaxSpeed

                local clicksNeeded = 0
                for i, speed in ipairs(speedCycle) do
                    if speed == targetSpeed then
                        clicksNeeded = i - 1
                        break
                    end
                end

                for i = 1, clicksNeeded do
                    setPropertieRF:InvokeServer("Wheel speed", {block})
                end
            end

            if data.ReverseSpin == true then
                setPropertieRF:InvokeServer("Reverse spin", {block}, true)
            end

            if data.WheelTorque then
                local targetTorque = tonumber(data.WheelTorque)

                if targetTorque == 1_000_000 then
                    --print("wheel got standard torque")
                else
                    local requiredClicks = 0

                    if targetTorque == 10_000_000 then
                        requiredClicks = 1
                    elseif targetTorque == 100_000_000 then
                        requiredClicks = 2
                    elseif targetTorque == 1_000_000_000 then
                        requiredClicks = 3
                    elseif targetTorque == 10_000_000_000 then
                        requiredClicks = 4
                    else
                        requiredClicks = 0
                    end

                    print(string.format(
                        requiredClicks,
                        targetTorque
                    ))

                    for i = 1, requiredClicks do
                        setPropertieRF:InvokeServer("Wheel torque", {block})
                        task.wait(0.01)
                    end
                end
            end
        end

        if block.Name == "BackWheelMint" then
            if not setPropertieRF then return end

            if data.MaxSpeed then
                local speedCycle = {40, 30, 20, 10, 5, 4, 3, 2, 1, 0.5, 50}
                local targetSpeed = data.MaxSpeed

                local clicksNeeded = 0
                for i, speed in ipairs(speedCycle) do
                    if speed == targetSpeed then
                        clicksNeeded = i - 1
                        break
                    end
                end

                for i = 1, clicksNeeded do
                    setPropertieRF:InvokeServer("Wheel speed", {block})
                end
            end

            if data.ReverseSpin == true then
                setPropertieRF:InvokeServer("Reverse spin", {block}, true)
            end

            if data.WheelTorque then
                local targetTorque = tonumber(data.WheelTorque)

                if targetTorque == 1_000_000 then
                    --print("wheel got standard torque")
                else
                    local requiredClicks = 0

                    if targetTorque == 10_000_000 then
                        requiredClicks = 1
                    elseif targetTorque == 100_000_000 then
                        requiredClicks = 2
                    elseif targetTorque == 1_000_000_000 then
                        requiredClicks = 3
                    elseif targetTorque == 10_000_000_000 then
                        requiredClicks = 4
                    else
                        requiredClicks = 0
                    end

                    print(string.format(
                        requiredClicks,
                        targetTorque
                    ))

                    for i = 1, requiredClicks do
                        setPropertieRF:InvokeServer("Wheel torque", {block})
                    end
                end
            end
        end

        if block.Name == "FrontWheelMint" then
            if not setPropertieRF then return end

            if data.MaxSpeed then
                local speedCycle = {40, 30, 20, 10, 5, 4, 3, 2, 1, 0.5, 50}
                local targetSpeed = data.MaxSpeed

                local clicksNeeded = 0
                for i, speed in ipairs(speedCycle) do
                    if speed == targetSpeed then
                        clicksNeeded = i - 1
                        break
                    end
                end

                for i = 1, clicksNeeded do
                    setPropertieRF:InvokeServer("Wheel speed", {block})
                end
            end

            if data.ReverseSpin == true then
                setPropertieRF:InvokeServer("Reverse spin", {block}, true)
            end

            if data.WheelTorque then
                local targetTorque = tonumber(data.WheelTorque)

                if targetTorque == 1_000_000 then
                    --print("wheel got standard torque")
                else
                    local requiredClicks = 0

                    if targetTorque == 10_000_000 then
                        requiredClicks = 1
                    elseif targetTorque == 100_000_000 then
                        requiredClicks = 2
                    elseif targetTorque == 1_000_000_000 then
                        requiredClicks = 3
                    elseif targetTorque == 10_000_000_000 then
                        requiredClicks = 4
                    else
                        requiredClicks = 0
                    end

                    print(string.format(
                        requiredClicks,
                        targetTorque
                    ))

                    for i = 1, requiredClicks do
                        setPropertieRF:InvokeServer("Wheel torque", {block})
                    end
                end
            end
        end

        if block.Name == "HugeFrontWheel" then
            if not setPropertieRF then return end

            if data.MaxSpeed then
                local speedCycle = {40, 30, 20, 10, 5, 4, 3, 2, 1, 0.5, 50}
                local targetSpeed = data.MaxSpeed

                local clicksNeeded = 0
                for i, speed in ipairs(speedCycle) do
                    if speed == targetSpeed then
                        clicksNeeded = i - 1
                        break
                    end
                end

                for i = 1, clicksNeeded do
                    setPropertieRF:InvokeServer("Wheel speed", {block})
                end
            end

            if data.ReverseSpin == true then
                setPropertieRF:InvokeServer("Reverse spin", {block}, true)
            end

            if data.WheelTorque then
                local targetTorque = tonumber(data.WheelTorque)

                if targetTorque == 10_000_000 then
                    --print("wheel got standard torque")
                else
                    local requiredClicks = 0

                    if targetTorque == 100_000_000 then
                        requiredClicks = 1
                    elseif targetTorque == 1_000_000_000 then 
                        requiredClicks = 2
                    elseif targetTorque == 10_000_000_000 then
                        requiredClicks = 3
                    elseif targetTorque == 1_000_000 then
                        requiredClicks = 4
                    else
                        requiredClicks = 0
                    end

                    print(string.format(
                        requiredClicks,
                        targetTorque
                    ))

                    for i = 1, requiredClicks do
                        setPropertieRF:InvokeServer("Wheel torque", {block})
                    end
                end
            end
        end

        if block.Name == "HugeBackWheel" then
            if not setPropertieRF then return end

            if data.MaxSpeed then
                local speedCycle = {40, 30, 20, 10, 5, 4, 3, 2, 1, 0.5, 50}
                local targetSpeed = data.MaxSpeed

                local clicksNeeded = 0
                for i, speed in ipairs(speedCycle) do
                    if speed == targetSpeed then
                        clicksNeeded = i - 1
                        break
                    end
                end

                for i = 1, clicksNeeded do
                    setPropertieRF:InvokeServer("Wheel speed", {block})
                end
            end

            if data.ReverseSpin == true then
                setPropertieRF:InvokeServer("Reverse spin", {block}, true)
            end

            if data.WheelTorque then
                local targetTorque = tonumber(data.WheelTorque)

                if targetTorque == 10_000_000 then
                    --print("wheel got standard torque")
                else
                    local requiredClicks = 0

                    if targetTorque == 100_000_000 then
                        requiredClicks = 1
                    elseif targetTorque == 1_000_000_000 then 
                        requiredClicks = 2
                    elseif targetTorque == 10_000_000_000 then
                        requiredClicks = 3
                    elseif targetTorque == 1_000_000 then
                        requiredClicks = 4
                    else
                        requiredClicks = 0
                    end

                    print(string.format(
                        requiredClicks,
                        targetTorque
                    ))

                    for i = 1, requiredClicks do
                        setPropertieRF:InvokeServer("Wheel torque", {block})
                    end
                end
            end
        end

        if block.Name == "BackWheel" then
            if not setPropertieRF then return end

            if data.MaxSpeed then
                local speedCycle = {40, 30, 20, 10, 5, 4, 3, 2, 1, 0.5, 50}
                local targetSpeed = data.MaxSpeed

                local clicksNeeded = 0
                for i, speed in ipairs(speedCycle) do
                    if speed == targetSpeed then
                        clicksNeeded = i - 1
                        break
                    end
                end

                for i = 1, clicksNeeded do
                    setPropertieRF:InvokeServer("Wheel speed", {block})
                end
            end

            if data.ReverseSpin == true then
                setPropertieRF:InvokeServer("Reverse spin", {block}, true)
            end

            if data.WheelTorque then
                local targetTorque = tonumber(data.WheelTorque)

                if targetTorque == 1_000_000 then
                    --print("wheel got standard torque")
                else
                    local requiredClicks = 0

                    if targetTorque == 10_000_000 then
                        requiredClicks = 1
                    elseif targetTorque == 100_000_000 then
                        requiredClicks = 2
                    elseif targetTorque == 1_000_000_000 then
                        requiredClicks = 3
                    elseif targetTorque == 10_000_000_000 then
                        requiredClicks = 4
                    else
                        requiredClicks = 0
                    end

                    print(string.format(
                        requiredClicks,
                        targetTorque
                    ))

                    for i = 1, requiredClicks do
                        setPropertieRF:InvokeServer("Wheel torque", {block})
                    end
                end
            end
        end

        if block.Name == "Piston" and setPropertieRF then
            if data.ExtendLength then
                setPropertieRF:InvokeServer("Piston length", {block}, data.ExtendLength)
            end

            if data.Speed then
                setPropertieRF:InvokeServer("Piston speed", {block}, data.Speed)
            end

            if data.LastDirrection == 1 then
                local activateRemote = block:FindFirstChild("PPart") and block.PPart:FindFirstChild("ActivateRemote")
                if activateRemote then
                    activateRemote:FireServer("Push")
                end
            end
        end

        if block.Name == "Delay" and setPropertieRF then
            if data.WaitDuration then
                setPropertieRF:InvokeServer("Delay time", {block}, data.WaitDuration)
            end
        end

        if block.Name == "Spring" and setPropertieRF then
            if data.Damping then
                setPropertieRF:InvokeServer("Damping", {block}, data.Damping)
            end
            if data.MaxLength then
                setPropertieRF:InvokeServer("Max lenght", {block}, data.MaxLength)
            end
            if data.MaxLengthLimit then
                setPropertieRF:InvokeServer("Target lenght", {block}, data.MaxLengthLimit)
            end
            if data.TargetLength then
                setPropertieRF:InvokeServer("Target lenght", {block}, data.TargetLength)
            end
            if data.MinLength then
                setPropertieRF:InvokeServer("Min lenght", {block}, data.MinLength)
            end
            if data.Stiffness then
                setPropertieRF:InvokeServer("Stiffness", {block}, data.Stiffness)
            end
        end

        if block.Name == "Rope" and setPropertieRF then
            if data.Length then
                setPropertieRF:InvokeServer("Length", {block}, data.Length)
            end
            if data.MatchRotation == 0 then
                if setPropertieRF then
                    setPropertieRF:InvokeServer("Match rotation", {block})
                end
            end
        end

        if block.Name == "Bar" and setPropertieRF then
            if data.Length then
                setPropertieRF:InvokeServer("Length", {block}, data.Length)
            end
            if data.AngleLimit then
                setPropertieRF:InvokeServer("Angle limit", {block}, data.AngleLimit)
            end
            if data.MatchRotation == 0 then
                if setPropertieRF then
                    setPropertieRF:InvokeServer("Match rotation", {block})
                end
            end
        end

        if block.Name == "Sign" and data.Text then
            local updateSignRE = block:FindFirstChild("ClickDetector")
                and block.ClickDetector:FindFirstChild("Script")
                and block.ClickDetector.Script:FindFirstChild("UpdateSignRE")

            if updateSignRE and updateSignRE:IsA("RemoteEvent") then
                updateSignRE:FireServer(data.Text)
            end
        end

        if block.Name == "JetTurbine" then
            if setPropertieRF and data.MaxSpeed then
                local fireTimes = 0
                if data.MaxSpeed == 50 then
                    fireTimes = 1
                elseif data.MaxSpeed == 25 then
                    fireTimes = 2
                elseif data.MaxSpeed == 10 then
                    fireTimes = 3
                elseif data.MaxSpeed == 5 then
                    fireTimes = 4
                end

                local fireTimes2 = 0
                if data.MaxForce then
                    if data.MaxForce == 1000000 then
                        fireTimes2 = 1
                    elseif data.MaxForce == 10000000 then
                        fireTimes2 = 2
                    elseif data.MaxForce == 100000000 then
                        fireTimes2 = 3
                    elseif data.MaxForce == 1000000000 then
                        fireTimes2 = 4
                    end
                end
                    
                for i = 1, fireTimes do
                    setPropertieRF:InvokeServer("Jet speed", {block}, data.MaxSpeed or 100)
                end

                for i = 1, fireTimes2 do
                    setPropertieRF:InvokeServer("Jet force", {block}, data.MaxForce or 10000000000)
                end 
            end
        end

        if block.Name == "SonicJetTurbine" then
            if setPropertieRF and data.MaxSpeed then
                local fireTimestz = 0
                if data.MaxSpeed == 50 then
                    fireTimestz = 1
                elseif data.MaxSpeed == 25 then
                    fireTimestz = 2
                elseif data.MaxSpeed == 10 then
                    fireTimestz = 3
                elseif data.MaxSpeed == 5 then
                    fireTimestz = 4
                end

                local fireTimes22 = 0
                if data.MaxForce then
                    if data.MaxForce == 1000000 then
                        fireTimes22 = 1
                    elseif data.MaxForce == 10000000 then
                        fireTimes22 = 2
                    elseif data.MaxForce == 100000000 then
                        fireTimes22 = 3
                    elseif data.MaxForce == 1000000000 then
                        fireTimes22 = 4
                    end
                end
                    
                for i = 1, fireTimestz do
                    setPropertieRF:InvokeServer("Jet speed", {block}, data.MaxSpeed or 200)
                end

                for i = 1, fireTimes22 do
                    setPropertieRF:InvokeServer("Jet force", {block}, data.MaxForce or 10000000000)
                end 
            end
        end
 
        if block.Name == "Servo" then
            if setPropertieRF then
                local fireTimeWinkel = 0
                if data.TargetAngle == 20 then
                    fireTimeWinkel = 1
                elseif data.TargetAngle == 5 then
                    fireTimeWinkel = 2
                elseif data.TargetAngle == 90 then
                    fireTimeWinkel = 3
                elseif data.TargetAngle == 75 then
                    fireTimeWinkel = 4
                elseif data.TargetAngle == 60 then
                    fireTimeWinkel = 5
                end

                local fireTimeWinkelSpeed = 0
                if data.AngularSpeed == 4 then
                    fireTimeWinkelSpeed = 1
                elseif data.AngularSpeed == 3 then
                    fireTimeWinkelSpeed = 2
                elseif data.AngularSpeed == 2 then
                    fireTimeWinkelSpeed = 3
                elseif data.AngularSpeed == 1 then
                    fireTimeWinkelSpeed = 4
                elseif data.AngularSpeed == 0.5 then
                    fireTimeWinkelSpeed = 5
                elseif data.AngularSpeed == 50 then
                    fireTimeWinkelSpeed = 6
                elseif data.AngularSpeed == 40 then
                    fireTimeWinkelSpeed = 7
                elseif data.AngularSpeed == 30 then
                    fireTimeWinkelSpeed = 8
                elseif data.AngularSpeed == 20 then
                    fireTimeWinkelSpeed = 9
                elseif data.AngularSpeed == 10 then
                    fireTimeWinkelSpeed = 10
                end

                local fireTimeWinkeTorgue = 0
                if data.ServoTorque == 10000000 then
                    fireTimeWinkeTorgue = 1
                elseif data.ServoTorque == 100000000 then
                    fireTimeWinkeTorgue = 2
                elseif data.ServoTorque == 1000000000 then
                    fireTimeWinkeTorgue = 3
                elseif data.ServoTorque == 10000000000 then
                    fireTimeWinkeTorgue = 4
                end

                for i = 1, fireTimeWinkel do
                    setPropertieRF:InvokeServer("Servo angle", {block}, data.TargetAngle or 45)
                end

                for i = 1, fireTimeWinkeTorgue do
                    setPropertieRF:InvokeServer("Servo torque", {block}, data.ServoTorque or 1000000)
                end

                for i = 1, fireTimeWinkelSpeed do
                    setPropertieRF:InvokeServer("Servo speed", {block}, data.AngularSpeed or 5)
                end

                if data.ReverseRotation ~= nil then
                    local toggleCount333 = data.ReverseRotation and 1 or 0
                    for i = 1, toggleCount333 do
                        setPropertieRF:InvokeServer("Reverse rotation", {block}, data.ReverseRotation)
                    end
                end
            end
        end

        if block.Name == "LightBulb" then
            if data.LightEnabled == 1 then
                local activateRemote = block.PPart:FindFirstChild("ActivateRemote")
                if activateRemote and activateRemote:IsA("RemoteEvent") then
                    activateRemote:FireServer()
                end
            end
        end

        if block.Name == "ShieldGenerator" then
            if data.ShieldEnabled == 1 then
                local activateRemote = block.PPart:FindFirstChild("ActivateRemote")
                if activateRemote and activateRemote:IsA("RemoteEvent") then
                    activateRemote:FireServer()
                end
            end
        end

        if block.Name == "Note" then
            local MusicBlockFireTimes = 0
            if data.SemitoneOffset == 1 then
                MusicBlockFireTimes = 1
            elseif data.SemitoneOffset == 2 then
                MusicBlockFireTimes = 2
            elseif data.SemitoneOffset == 3 then
                MusicBlockFireTimes = 3
            elseif data.SemitoneOffset == 4 then
                MusicBlockFireTimes = 4
            elseif data.SemitoneOffset == 5 then
                MusicBlockFireTimes = 5
            elseif data.SemitoneOffset == 6 then
                MusicBlockFireTimes = 6
            elseif data.SemitoneOffset == 7 then
                MusicBlockFireTimes = 7
            elseif data.SemitoneOffset == 8 then
                MusicBlockFireTimes = 8
            elseif data.SemitoneOffset == 9 then
                MusicBlockFireTimes = 9
            elseif data.SemitoneOffset == 10 then
                MusicBlockFireTimes = 10
            elseif data.SemitoneOffset == 11 then
                MusicBlockFireTimes = 10
            end

            for i = 1, MusicBlockFireTimes do
                setPropertieRF:InvokeServer("Key", {block}, data.SemitoneOffset or 0)
            end

        end
    end

    local toPaint = {}
    for _, blockInfo in ipairs(processedBlocksList) do
        if blockInfo.Data.Color then
            local blockColor = blockInfo.Data.Color
            local blockName = blockInfo.Block.Name
            
            if X.ShouldPaintBlock(blockName, blockColor) then
                table.insert(toPaint, {blockInfo.Block, blockColor})
            end
        end
    end

    if #toPaint > 0 then
        X.SetStatus("Painting blocks")
        X.UpdateProgression(75)
        
        paintedBlocksCount = 0
        local paintBatch = {}
        for i, paintData in ipairs(toPaint) do
            table.insert(paintBatch, paintData)
            paintedBlocksCount = paintedBlocksCount + 1
        end
        
        local paintArgs = { paintBatch }
        
        if paintingTool then
            remoteInvoke(paintingTool, unpack(paintArgs))
        end
        
        X.UpdateProgression(90)
    else
        X.UpdateProgression(90)
    end

    task.wait(1)

    if not X.AutoWeld.Initialized then
        X.AutoWeld:Init()
    end

    task.wait(2.5)
    --X.AutoWeld:ProcessAllBlocks(processedBlocksList)

    X.AutoWeld:SyncToServer()

    X.ClearPreview()
    X.SetStatus("Done!")
    X.UpdateProgression(100)
    
    task.wait(6)
    X.SetStatus("Ready")
    X.UpdateProgression(0)

    return true
end

function X.LoadFile(filename, scale, teamName)
    -- If filename doesn't have an extension or has .Build, try both
    if type(filename) == "string" and not string.find(filename, "%.") then
        -- Try .vBuild first, then .Build as fallback
        local vPath = "WeshkyBuildStorage/" .. filename .. ".vBuild"
        local buildPath = "WeshkyBuildStorage/" .. filename .. ".Build"
        
        if isfile(vPath) then
            filename = vPath
        elseif isfile(buildPath) then
            filename = buildPath
        end
    end
    
    local content
    if #workspaceChildren(BuildPreview) > 0 then
        content = X.HttpService:JSONEncode(X.Encode(X.GetPreviewBlocks(), X.GetTeam()))
    else
        local fileContent = readfile(filename)
        if not fileContent or fileContent == "" then
            warn("File is empty or not found")
            return
        end
        
        -- Try to convert if it's a legacy .txt format
        local converted = X.Convert(filename)
        if converted then
            content = converted
        else
            -- Safely decompress the content (handles both .Build and .vBuild)
            content = X.SafeDecompress(fileContent)
        end
    end

    local decodedRaw = nil
    local ok, result = pcall(function()
        decodedRaw = X.HttpService:JSONDecode(content)
    end)

    local blocks = X.Decode(content, scale)
    local keybinds = (decodedRaw and decodedRaw.Keybinds) or nil
    local connections = (decodedRaw and decodedRaw.BlockConnections) or nil
    X.LoadBlocks(blocks, teamName, keybinds, connections)
end

function X.PreviewFile(filename, scale, teamName)
    local content
    
    if type(filename) == "string" and not string.find(filename, "%.") then
        -- Try .vBuild first, then .Build as fallback
        local vPath = "WeshkyBuildStorage/" .. filename .. ".vBuild"
        local buildPath = "WeshkyBuildStorage/" .. filename .. ".Build"
        
        if isfile(vPath) then
            filename = vPath
        elseif isfile(buildPath) then
            filename = buildPath
        end
    end
    
    local content
    
    if type(filename) == "table" then
        content = X.HttpService:JSONEncode(filename)
    else
        local fileContent = readfile(filename)
        
        if not fileContent or fileContent == "" then
            warn("File is empty or not found")
            return
        end
        
        -- Attempt to safely decompress
        local jsonString = X.SafeDecompress(fileContent)
        
        local converted = X.Convert(filename)
        content = converted or jsonString
    end
    
    local function DecodeBuildData(json, scale)
        local decodeSuccess, decoded = pcall(function()
            return X.HttpService:JSONDecode(json)
        end)
        
        if not decodeSuccess or not decoded then
            warn("Failed to parse JSON. File may be corrupted.")
            return {}
        end
        
        for blockType, blocks in pairs(decoded) do
            if type(blocks) ~= "table" then continue end
            for _, block in ipairs(blocks) do
                if block.Position and type(block.Position) == "string" then
                    block.Position = Vector3.new(block.Position:match("([^,]+),([^,]+),([^,]+)"))
                end
                
                if block.Rotation and type(block.Rotation) == "string" then
                    local x, y, z = block.Rotation:match("([^,]+),([^,]+),([^,]+)")
                    block.Rotation = CFrame.Angles(X.math_rad(x), X.math_rad(y), X.math_rad(z))
                end
                
                if block.Size and type(block.Size) == "string" then
                    block.Size = Vector3.new(block.Size:match("([^,]+),([^,]+),([^,]+)"))
                end
                
                if block.Color and type(block.Color) == "string" then
                    block.Color = Color3.new(block.Color:match("([^,]+),([^,]+),([^,]+)"))
                end
                
                if block.SecondaryPartPosition and type(block.SecondaryPartPosition) == "string" then
                    block.SecondaryPartPosition = Vector3.new(block.SecondaryPartPosition:match("([^,]+),([^,]+),([^,]+)"))
                end
                
                if block.SecondaryPartRotation and type(block.SecondaryPartRotation) == "string" then
                    local x, y, z = block.SecondaryPartRotation:match("([^,]+),([^,]+),([^,]+)")
                    block.SecondaryPartRotation = CFrame.Angles(X.math_rad(x), X.math_rad(y), X.math_rad(z))
                end
                
                if scale then
                    if block.Position then block.Position = block.Position * scale end
                    if block.Size then block.Size = block.Size * scale end
                    if block.SecondaryPartPosition then block.SecondaryPartPosition = block.SecondaryPartPosition * scale end
                end
            end
        end
        return decoded
    end
    
    local decoded = DecodeBuildData(content, scale or 1)
    local zone = teamName and X.Config.zones[teamName] or X.GetPlot()
    
    for blockType, blockList in pairs(decoded) do
        if BuildingParts:FindFirstChild(blockType) then
            for _, blockData in ipairs(blockList) do
                local clone = workspaceClone(BuildingParts[blockType])
                local cframe = zone.CFrame * CFrame.new(blockData.Position) * blockData.Rotation
                
                local primaryPart = clone:FindFirstChild("PPart")
                
                -- For Spring, Rope, and Bar blocks - don't use modelSetPrimary, position parts individually
                if (blockType == "Spring" or blockType == "Bar" or blockType == "Rope") and blockData.SecondaryPartPosition and blockData.SecondaryPartRotation then
                    local secPosition = Vector3_new(blockData.SecondaryPartPosition)
                    local secRotation = blockData.SecondaryPartRotation
                    local secondaryCFrame = zone.CFrame * CFrame.new(secPosition) * secRotation
                    
                    -- Position primary part
                    if primaryPart then
                        primaryPart.CFrame = cframe
                    end
                    
                    -- Find and position secondary part
                    local secondaryFolder = clone:FindFirstChild("SecondaryPart")
                    local secondaryPart = secondaryFolder and secondaryFolder:FindFirstChild("Part")
                    if secondaryPart then
                        secondaryPart.CFrame = secondaryCFrame
                    end
                    
                    -- Apply properties to all parts
                    for _, part in ipairs(clone:GetDescendants()) do
                        if part:IsA("BasePart") then
                            part.Transparency = blockData.Transparency or 0
                            part.CanCollide = blockData.CanCollide or true
                            part.CastShadow = blockData.ShowShadow ~= false
                            part.Anchored = blockData.Anchored ~= false
                            if blockData.Size and part == primaryPart then
                                part.Size = blockData.Size
                            end
                            if blockData.Color then
                                part.Color = blockData.Color
                            end
                        end
                    end
                    
                    clone.Health.Value = ""
                    clone.Parent = BuildPreview
                else
                    -- Standard block handling - use modelSetPrimary
                    modelSetPrimary(clone, cframe)
                    clone.Health.Value = ""
                    clone.Parent = BuildPreview
                    
                    local part = clone.PPart
                    part.Transparency = blockData.Transparency or 0
                    part.CanCollide = blockData.CanCollide or true
                    part.CastShadow = blockData.ShowShadow ~= false
                    part.Anchored = blockData.Anchored ~= false
                    
                    if blockData.Size then
                        part.Size = blockData.Size
                    end
                    
                    if blockData.Color then
                        part.Color = blockData.Color
                    end
                end
            end
        end
    end
end

function X.UpdatePreview(offset, rotation)
    local previewBlocks = BuildPreview:GetChildren()
    if #previewBlocks == 0 then
        return
    end
    
    if offset then
        for _, block in ipairs(previewBlocks) do
            if block:IsA("Model") then
                if block.PrimaryPart then
                    local currentCF = block:GetPrimaryPartCFrame()
                    block:SetPrimaryPartCFrame(currentCF + offset)
                else
                    for _, part in ipairs(block:GetDescendants()) do
                        if part:IsA("BasePart") then
                            part.CFrame = part.CFrame + offset
                        end
                    end
                end
            elseif block:IsA("BasePart") then
                block.CFrame = block.CFrame + offset
            end
        end
    end
    
    if rotX ~= 0 or rotY ~= 0 or rotZ ~= 0 then
        local totalPosition = Vector3.new(0, 0, 0)
        local blockCount = 0
        
        for _, block in ipairs(previewBlocks) do
            if block:IsA("Model") and block.PrimaryPart then
                totalPosition = totalPosition + block.PrimaryPart.Position
                blockCount = blockCount + 1
            elseif block:IsA("BasePart") then
                totalPosition = totalPosition + block.Position
                blockCount = blockCount + 1
            end
        end
        
        if blockCount > 0 then
            local center = totalPosition / blockCount
            
            local rotationCFrame = CFrame.Angles(
                X.math_rad(rotX),
                X.math_rad(rotY), 
                X.math_rad(rotZ)
            )
            
            for _, block in ipairs(previewBlocks) do
                if block:IsA("Model") and block.PrimaryPart then
                    local primaryPart = block.PrimaryPart
                    local relativePos = primaryPart.Position - center
                    local rotatedPos = rotationCFrame * relativePos
                    local newPosition = center + rotatedPos
                    
                    local currentRotation = primaryPart.CFrame - primaryPart.CFrame.Position
                    local newRotation = rotationCFrame * currentRotation
                    
                    block:SetPrimaryPartCFrame(X.CFrame_new(newPosition) * newRotation)
                    
                elseif block:IsA("BasePart") then
                    local relativePos = block.Position - center
                    local rotatedPos = rotationCFrame * relativePos
                    local newPosition = center + rotatedPos
                    
                    local currentRotation = block.CFrame - block.CFrame.Position
                    local newRotation = rotationCFrame * currentRotation
                    
                    block.CFrame = X.CFrame_new(newPosition) * newRotation
                end
            end
        end
    end
end

function X.MirrorBuild()
    local previewBlocks = BuildPreview:GetChildren()
    if #previewBlocks == 0 then
        return
    end
    
    local totalPosition = Vector3.new(0, 0, 0)
    local blockCount = 0
    
    for _, block in ipairs(previewBlocks) do
        if block:IsA("Model") and block.PrimaryPart then
            totalPosition = totalPosition + block.PrimaryPart.Position
            blockCount = blockCount + 1
        elseif block:IsA("BasePart") then
            totalPosition = totalPosition + block.Position
            blockCount = blockCount + 1
        end
    end
    
    if blockCount == 0 then return end
    
    local center = totalPosition / blockCount
    
    for _, block in ipairs(previewBlocks) do
        if block:IsA("Model") and block.PrimaryPart then
            local primaryPart = block.PrimaryPart
            local relativePos = primaryPart.Position - center
            local mirroredPos = Vector3.new(-relativePos.X, relativePos.Y, relativePos.Z) + center
            
            local currentRotation = primaryPart.CFrame - primaryPart.CFrame.Position
            local x, y, z = currentRotation:ToEulerAnglesXYZ()
            local mirroredRotation = CFrame.Angles(x, -y, z)
            
            block:SetPrimaryPartCFrame(CFrame.new(mirroredPos) * mirroredRotation)
            
        elseif block:IsA("BasePart") then
            local relativePos = block.Position - center
            local mirroredPos = Vector3.new(-relativePos.X, relativePos.Y, relativePos.Z) + center
            
            local currentRotation = block.CFrame - block.CFrame.Position
            local x, y, z = currentRotation:ToEulerAnglesXYZ()
            local mirroredRotation = CFrame.Angles(x, -y, z)
            
            block.CFrame = X.CFrame_new(mirroredPos) * mirroredRotation
        end
    end
end

function X.CreateBlockData(name, cframe, size, color)
    return {
        Name = name,
        PPart = {
            CFrame = cframe,
            CastShadow = false,
            CanCollide = true,
            Anchored = true,
            Transparency = 0,
            Color = color.Color,
            Size = size,
        },
    }
end

local imageCache = nil
local lastUrl = nil
local Image_Server_Url = "https://Img123456.pythonanywhere.com/image"
local imageUrl = nil
local imageBlockType = "MetalBlock"
local imageBlockSize = 0.5
local resolution = 5

X.GetColor = X.Memoize(X.DecodeColor)

function X.GetImage(url)
    if lastUrl == url and imageCache then
        return imageCache
    end
    
    if not url or url == "" then
        warn("No URL provided")
        return nil
    end
    
    if not string.find(url, "://") then
        url = "http://" .. url
    end
    
    local success, result = pcall(function()
        local bodyData = {
            url = url
        }
        
        local response = request({
            Url = Image_Server_Url,
            Method = "POST",
            Headers = {
                ["Content-Type"] = "application/json",
                ["X-API-Key"] = apikey,
            },
            Body = X.HttpService:JSONEncode(bodyData),
            Timeout = 30
        })
        
        if response then            
            if response.StatusCode == 200 then
                local success, decoded = pcall(function()
                    return X.HttpService:JSONDecode(response.Body)
                end)
                
                if success and decoded then
                    return { 
                        success = true, 
                        data = response.Body,
                        decoded = decoded
                    }
                else
                    return { 
                        success = false, 
                        error = "Invalid JSON response",
                        data = response.Body
                    }
                end
            else
                return { 
                    success = false, 
                    error = "HTTP " .. response.StatusCode,
                    data = response.Body
                }
            end
        end
    end)

    if success and result and result.success then
        -- Cache the successful result
        imageCache = result.data
        lastUrl = url
        return result.data
    else
        if result then
            warn("Server error")
            if result.data then
                print("succeful respond")
            end
        else
            warn("Failed to connect to server")
        end
        X.SetStatus("Server error")
        return nil
    end
end

function X.ProcessImage(url, blockType, baseBlockSize, resolution, preview)
    if not url or url == "" then
        warn("None or empty URL provided")
        X.SetStatus("Error: No URL")
        return
    end

    -- Add http:// if missing
    if not string.find(url, "://") then
        url = "http://" .. url
    end

    -- Validate block type
    local blockTemplate = BuildingParts:FindFirstChild(blockType)
    if not blockTemplate then
        return
    end

    -- Parse and validate numeric inputs
    resolution = tonumber(resolution) or 5
    resolution = math.max(1, math.min(20, math.floor(resolution))) -- Limit to reasonable values
    
    baseBlockSize = tonumber(baseBlockSize) or 0.5
    baseBlockSize = math.max(0.1, math.min(5, baseBlockSize))
    
    -- Get image data from server
    local imageData = X.GetImage(url)
    if not imageData then
        X.SetStatus("Failed to load image")
        return
    end

    -- Parse the JSON response
    local decodedImage
    local success, err = pcall(function()
        decodedImage = X.HttpService:JSONDecode(imageData)
    end)

    if not success or not decodedImage then
        return
    end
    
    -- Check for server error
    if decodedImage.error then
        return
    end
    
    -- Validate response structure
    if not decodedImage.dimensions or not decodedImage.pixels then
        return
    end
    
    -- Get dimensions
    local originalWidth = decodedImage.dimensions[1]
    local originalHeight = decodedImage.dimensions[2]
    
    if not originalWidth or not originalHeight then
        warn("Invalid image dimensions")
        return
    end
        
    -- Calculate output size
    local generatedWidth = math.ceil(originalWidth / resolution)
    local generatedHeight = math.ceil(originalHeight / resolution)
    
    -- Limit size to prevent lag
    if generatedWidth > 150 or generatedHeight > 150 then
        return
    end
    
    -- Get plot
    local currentPlot = X.GetPlot()
    if not currentPlot then
        warn("Could not get plot")
        return
    end
    
    -- Calculate positioning
    local yPlotOffset = 5.1 + (generatedHeight * baseBlockSize)
    local xPlotOffset = (generatedWidth * baseBlockSize) / 2
    local plotCFrame = currentPlot.CFrame

    -- Clear preview if needed
    if preview then
        X.ClearPreview()
    end

    local blocksForJsonEncoding = {}
    local totalBlocks = generatedWidth * generatedHeight
    local processed = 0
    local blocksPlaced = 0

    X.SetStatus("Processing Image Data")
    X.UpdateProgression(0)

    -- Process each block position
    for y = 0, generatedHeight - 1 do
        for x = 0, generatedWidth - 1 do
            -- Calculate which pixel to sample (center of the sample area)
            local pixelX = math.floor(x * resolution + resolution/2)
            local pixelY = math.floor(y * resolution + resolution/2)
            
            -- Clamp to image boundaries
            pixelX = math.max(0, math.min(originalWidth - 1, pixelX))
            pixelY = math.max(0, math.min(originalHeight - 1, pixelY))
            
            local pixelIndex = (pixelY * originalWidth) + pixelX + 1
            
            if pixelIndex > 0 and pixelIndex <= #decodedImage.pixels then
                -- Get color data for this pixel
                local colorData = X.GetColor(decodedImage.pixels[pixelIndex])
                
                if colorData and colorData.Color then
                    -- Calculate block position relative to plot
                    local localBlockPosition = Vector3.new(
                        -x * baseBlockSize + xPlotOffset,
                        -y * baseBlockSize + yPlotOffset,
                        0
                    )
                    
                    if preview then
                        -- Create preview block
                        local absoluteCFrame = plotCFrame * X.CFrame_new(localBlockPosition)
                        local blockClone = workspaceClone(blockTemplate)
                        blockClone.Parent = BuildPreview
                        
                        -- Find and configure the main part
                        local primaryPart = blockClone:FindFirstChild("PPart") or blockClone:FindFirstChildWhichIsA("BasePart")
                        if primaryPart then
                            primaryPart.Size = Vector3.new(baseBlockSize, baseBlockSize, baseBlockSize)
                            primaryPart.Color = colorData.Color
                            primaryPart.CFrame = absoluteCFrame
                            primaryPart.Anchored = true
                            primaryPart.CanCollide = false
                            primaryPart.Transparency = 1 - (colorData.Alpha / 255)
                            primaryPart.CastShadow = false
                            
                            -- Make all parts transparent if needed
                            for _, child in ipairs(blockClone:GetDescendants()) do
                                if child:IsA("BasePart") and child ~= primaryPart then
                                    child.Transparency = primaryPart.Transparency
                                end
                            end
                            
                            blocksPlaced = blocksPlaced + 1
                        else
                            blockClone:Destroy()
                        end
                    else
                        -- Prepare data for building
                        local absoluteCFrame = plotCFrame * X.CFrame_new(localBlockPosition)
                        local relativeCFrame = plotCFrame:ToObjectSpace(absoluteCFrame)
                        
                        local blockJsonData = {
                            Position = X.String(relativeCFrame.Position),
                            Rotation = X.GetStringAngles(relativeCFrame),
                            Color = X.String(colorData.Color),
                            Size = X.String(Vector3.new(baseBlockSize, baseBlockSize, baseBlockSize)),
                            Transparency = 1 - (colorData.Alpha / 255),
                            Anchored = true,
                            CanCollide = false,
                            ShowShadow = false
                        }

                        if not blocksForJsonEncoding[blockType] then
                            blocksForJsonEncoding[blockType] = {}
                        end
                        table.insert(blocksForJsonEncoding[blockType], blockJsonData)
                        blocksPlaced = blocksPlaced + 1
                    end
                end
            end
            
            processed = processed + 1
            if processed % 20 == 0 then
                local percent = math.floor((processed / totalBlocks) * 100)
                X.UpdateProgression(percent)
                X.SetStatus("Processing Image")
                task.wait()
            end
        end
    end

    X.UpdateProgression(100)
    
    if preview then
        print("Preview Generated")
    else        
        if next(blocksForJsonEncoding) then
            -- Convert to JSON and build
            local jsonString = X.HttpService:JSONEncode(blocksForJsonEncoding)
            local decoded = X.Decode(jsonString, 1)
            if decoded and next(decoded) then
                X.LoadBlocks(decoded)
            end
        end
    end
end

function X.ListBuild(filename, scale)
    local content
    
    if type(filename) == "table" then
        content = X.HttpService:JSONEncode(filename)
    else
        -- First check if it's a legacy .txt format
        local converted = X.Convert(filename)
        if converted then
            content = converted
        else
            -- Read the file and decompress it
            local fileContent = readfile(filename)
            if not fileContent or fileContent == "" then
                warn("File is empty or not found")
                return
            end
            
            -- Safely decompress the content
            local jsonString = X.SafeDecompress(fileContent)
            content = jsonString
        end
    end
    
    -- Now decode the JSON
    local success, decoded = pcall(function()
        return X.HttpService:JSONDecode(content)
    end)
    
    if not success or not decoded then
        warn("Failed to parse JSON. File may be corrupted.")
        return
    end
    
    local required = {}
    local missing = {}
    local defaultSize = Vector3.new(2, 2, 2)  -- Standard block size
    local scale = scale or 1  -- Use provided scale or default to 1
    
    for blockType, blockList in pairs(decoded) do
        local totalBlocksNeeded = 0
        
        for _, blockData in ipairs(blockList) do
            -- Check if this block has a custom size
            if blockData.Size then
                -- Parse the size string (format: "X,Y,Z")
                local sizeStr = blockData.Size
                if type(sizeStr) == "string" then
                    local x, y, z = string.match(sizeStr, "([^,]+),([^,]+),([^,]+)")
                    if x and y and z then
                        local blockSize = Vector3.new(
                            tonumber(x) or 2,
                            tonumber(y) or 2,
                            tonumber(z) or 2
                        )
                        
                        -- Calculate volume in standard blocks (2x2x2 = 8 cubic units)
                        -- Each standard block is 2x2x2 = 8 cubic units
                        local volume = blockSize.X * blockSize.Y * blockSize.Z
                        local standardBlockVolume = 8  -- 2×2×2
                        
                        -- Account for scaling factor
                        local scaledVolume = volume / standardBlockVolume
                        
                        -- Apply user's scale multiplier
                        if scale and scale ~= 1 then
                            -- If scaling the entire build, adjust volume accordingly
                            scaledVolume = scaledVolume * (scale * scale * scale)
                        end
                        
                        -- Round up to nearest whole block
                        local blocksForThisPart = math.max(1, math.ceil(scaledVolume))
                        totalBlocksNeeded = totalBlocksNeeded + blocksForThisPart
                    else
                        -- If we can't parse size, assume 1 block
                        totalBlocksNeeded = totalBlocksNeeded + 1
                    end
                else
                    totalBlocksNeeded = totalBlocksNeeded + 1
                end
            else
                -- Default size (2,2,2) = 1 block
                totalBlocksNeeded = totalBlocksNeeded + 1
            end
        end
        
        -- Store the total blocks needed for this type
        required[blockType] = totalBlocksNeeded
        
        -- Calculate deficit based on available blocks
        local blockData = playerData[blockType]
        local available = blockData and blockData.Value or 0
        local used = blockData and blockData.Used.Value or 0
        local remaining = math.max(0, available - used)
        local deficit = math.max(0, totalBlocksNeeded - remaining)
        
        missing[blockType] = deficit > 0 and deficit or nil
    end
    
    X.listing:Clear()
    for blockType, count in pairs(required) do
        X.listing:Add(blockType, count, missing[blockType])
    end
end

function X.ListImageBlocks()
    if not imageUrl or not imageBlockType or not imageBlockSize or not resolution then
        return
    end

    local imageData = X.GetImage(imageUrl)
    if imageData == "invalid" or not imageData then
        return
    end

    local decodedImageJson
    local successJsonDecode = pcall(function()
        decodedImageJson = X.HttpService:JSONDecode(imageData)
    end)

    if not successJsonDecode or not decodedImageJson or not decodedImageJson.dimensions or not decodedImageJson.pixels then
        return
    end

    local originalWidth = decodedImageJson.dimensions[1]
    local originalHeight = decodedImageJson.dimensions[2]

    local generatedWidth = math.ceil(originalWidth / resolution)
    local generatedHeight = math.ceil(originalHeight / resolution)

    local required = {}

    for y = 0, generatedHeight - 1 do
        for x = 0, generatedWidth - 1 do
            local startPixelX = x * resolution
            local startPixelY = y * resolution
            local pixelIndex = (startPixelY * originalWidth + startPixelX + 1)

            if pixelIndex <= 0 or pixelIndex > #decodedImageJson.pixels then
                continue
            end

            local colorData = X.GetColor(decodedImageJson.pixels[pixelIndex])
            if not colorData or not colorData.Color then
                continue
            end

            required[imageBlockType] = (required[imageBlockType] or 0) + 1
        end
        if y % 10 == 0 then
            task.wait()
        end
    end

    local missing = {}
    for blockType, count in pairs(required) do
        local available = playerData[blockType] and playerData[blockType].Value or 0
        local deficit = count - available
        missing[blockType] = deficit > 0 and deficit or nil
    end

    X.listing:Clear()
    for blockType, count in pairs(required) do
        X.listing:Add(blockType, count, missing[blockType])
    end
end

local shapeType = "Ball"
local blockType = "WoodBlock"
local radius = 5
local thickness = 1
local centerOnPlot = false
local smoothRotation = false
local blockSpacing = 2
local shapeHeight = 10
local shapeWidth = 10
local shapeDepth = 10

function X.CreatePreviewBlock(position, blockType, rotation)
    local clone = workspaceClone(BuildingParts[blockType])
    local cframe = X.CFrame_new(position)
    if rotation then
        cframe = cframe * rotation
    end
    
    if clone:IsA("Model") and clone.PrimaryPart then
        clone:SetPrimaryPartCFrame(cframe)
    else
        for _, child in ipairs(clone:GetDescendants()) do
            if child:IsA("BasePart") then
                child.CFrame = cframe
                break
            end
        end
    end
    
    clone.Health.Value = ""
    clone.Parent = BuildPreview
    
    -- Apply properties to all parts
    local allParts = clone:GetDescendants()
    for _, part in ipairs(allParts) do
        if part:IsA("BasePart") then
            part.Transparency = 0
            part.CanCollide = true
            part.Anchored = true
            part.CastShadow = true
        end
    end
    
    return clone
end

function X.GetCircleRotation(position, center)
    local direction = (position - center).Unit
    return CFrame.fromMatrix(Vector3.new(), 
        Vector3.new(direction.X, 0, direction.Z),
        Vector3.new(0, 1, 0),
        Vector3.new(-direction.Z, 0, direction.X))
end

function X.RotationFromNormal(normal)
    if not normal then return nil end
    if normal.Magnitude <= 0.001 then return nil end
    local upVector = math.abs(normal.Y) > 0.9 and Vector3_new(0, 0, 1) or Vector3_new(0, 1, 0)
    local rightVector = normal:Cross(upVector).Unit
    upVector = rightVector:Cross(normal).Unit
    return CFrame.fromMatrix(Vector3_new(), rightVector, upVector, normal)
end

function X.GenerateBall(center, radius, blockType, spacing)
    local blocks = {}
    local blockPositions = {}

    -- Use denser segmentation for a smoother sphere similar to Dome
    local verticalSegments = math.max(12, X.math_floor(radius * 6))
    local horizontalSegments = math.max(16, verticalSegments * 2)

    for v = 0, verticalSegments do
        local verticalAngle = (v / verticalSegments) * math.pi
        local y = center.Y + radius * math.cos(verticalAngle)
        local sliceRadius = radius * math.sin(verticalAngle)

        for h = 0, horizontalSegments do
            local horizontalAngle = (h / horizontalSegments) * math.pi * 2
            local x = center.X + sliceRadius * math.cos(horizontalAngle)
            local z = center.Z + sliceRadius * math.sin(horizontalAngle)

            local position = Vector3_new(x, y, z)
            if not blockPositions[tostring(position)] then
                local rotation = smoothRotation and X.RotationFromNormal((position - center).Unit) or nil
                local clone = X.CreatePreviewBlock(position, blockType, rotation)
                X.table_insert(blocks, clone)
                blockPositions[tostring(position)] = true
            end
        end
    end

    return blocks
end

function X.GenerateTorus(center, majorRadius, minorRadius, blockType, spacing)
    local blocks = {}
    local blockPositions = {}
    
    local majorCircumference = 2 * math.pi * majorRadius
    local minorCircumference = 2 * math.pi * minorRadius
    local majorSegments = math.max(8, X.math_floor(majorCircumference / spacing))
    local minorSegments = math.max(8, X.math_floor(minorCircumference / spacing))
    
    for major = 0, majorSegments do
        local majorAngle = (major / majorSegments) * math.pi * 2
        local majorX = math.cos(majorAngle)
        local majorZ = math.sin(majorAngle)
        
        for minor = 0, minorSegments do
            local minorAngle = (minor / minorSegments) * math.pi * 2
            local minorX = math.cos(minorAngle)
            local minorY = math.sin(minorAngle)
            
            local x = center.X + (majorRadius + minorRadius * minorX) * majorX
            local y = center.Y + minorRadius * minorY
            local z = center.Z + (majorRadius + minorRadius * minorX) * majorZ
            
            local position = Vector3.new(x, y, z)
            if not blockPositions[tostring(position)] then
                local rotation = smoothRotation and X.RotationFromNormal((position - center).Unit) or nil
                local clone = X.CreatePreviewBlock(position, blockType, rotation)
                X.table_insert(blocks, clone)
                blockPositions[tostring(position)] = true
            end
        end
    end
    
    return blocks
end

-- Spiral generator removed to simplify shape builder

function X.GenerateDome(center, radius, blockType, spacing)
    local blocks = {}
    local blockPositions = {}
    
    local circumference = 2 * math.pi * radius
    local verticalSegments = math.max(8, X.math_floor(circumference / spacing))
    local horizontalSegments = math.max(8, X.math_floor(circumference / spacing))
    
    for v = 0, verticalSegments / 2 do
        local verticalAngle = (v / verticalSegments) * math.pi
        local y = center.Y + radius * math.cos(verticalAngle)
        local sliceRadius = radius * math.sin(verticalAngle)
        
        for h = 0, horizontalSegments do
            local horizontalAngle = (h / horizontalSegments) * math.pi * 2
            local x = center.X + sliceRadius * math.cos(horizontalAngle)
            local z = center.Z + sliceRadius * math.sin(horizontalAngle)
            
            local position = Vector3.new(x, y, z)
            if not blockPositions[tostring(position)] then
                local rotation = smoothRotation and X.RotationFromNormal((position - center).Unit) or nil
                local clone = X.CreatePreviewBlock(position, blockType, rotation)
                X.table_insert(blocks, clone)
                blockPositions[tostring(position)] = true
            end
        end
    end
    
    return blocks
end

function X.GenerateWave(center, width, height, length, blockType, spacing)
    local blocks = {}
    local blockPositions = {}
    
    local halfWidth = width / 2
    local waveLength = length * 2 * math.pi
    local segments = math.max(8, X.math_floor(waveLength / spacing))
    
    for s = 0, segments do
        local x = (s / segments) * length
        local y = height * math.sin(x)
        
        for w = -halfWidth, halfWidth, spacing do
            local position = center + Vector3.new(x, y, w)
            if not blockPositions[tostring(position)] then
                local rotation = nil
                if smoothRotation then
                    local tangent = Vector3_new(1, height * math.cos(x), 0).Unit
                    local normal = Vector3_new(-height * math.cos(x), 1, 0).Unit
                    local binormal = tangent:Cross(normal).Unit
                    rotation = CFrame.fromMatrix(Vector3_new(), tangent, binormal, normal)
                end
                local clone = X.CreatePreviewBlock(position, blockType, rotation)
                X.table_insert(blocks, clone)
                blockPositions[tostring(position)] = true
            end
        end
    end
    
    return blocks
end

function X.PreviewShape()
    X.ClearPreview()
    
    local plot = X.GetPlot()
    if not plot then
        return
    end
    
    local center = centerOnPlot and plot.Position or player.Character and player.Character.HumanoidRootPart.Position or plot.Position
    center = center + Vector3.new(0, radius + 5, 0)
    
    local blocks = {}
    local blockPositions = {}
    
    if shapeType == "Circle" then
        local circumference = 2 * math.pi * radius
        local segmentLength = 2
        local segments = math.max(8, X.math_floor(circumference / segmentLength))
        
        for i = 1, segments do
            local angle = (i / segments) * math.pi * 2
            local x = math.cos(angle) * radius
            local z = math.sin(angle) * radius
            
            local position = Vector3.new(x, 0, z)
            position = center + position
            
            for t = 1, thickness do
                local offset = (t - 1) * 2
                local offsetPos = position + Vector3.new(0, offset, 0)
                
                if not blockPositions[tostring(offsetPos)] then
                    local rotation = smoothRotation and X.GetCircleRotation(offsetPos, center) or nil
                    local clone = X.CreatePreviewBlock(offsetPos, blockType, rotation)
                    X.table_insert(blocks, clone)
                    blockPositions[tostring(offsetPos)] = true
                end
            end
        end
        
    elseif shapeType == "Ball" then
        blocks = X.GenerateBall(center, radius, blockType, blockSpacing)
        
    elseif shapeType == "Cylinder" then
        local height = radius * 2
        local halfHeight = height / 2
        local circumference = 2 * math.pi * radius
        local segmentLength = blockSpacing
        local segments = math.max(8, X.math_floor(circumference / segmentLength))
        
        for h = -halfHeight, halfHeight, blockSpacing do
            for i = 1, segments do
                local angle = (i / segments) * math.pi * 2
                local x = math.cos(angle) * radius
                local z = math.sin(angle) * radius
                
                local position = center + Vector3.new(x, h, z)
                
                if not blockPositions[tostring(position)] then
                    local rotation = smoothRotation and X.GetCircleRotation(position, center) or nil
                    local clone = X.CreatePreviewBlock(position, blockType, rotation)
                    X.table_insert(blocks, clone)
                    blockPositions[tostring(position)] = true
                end
            end
        end
        
    elseif shapeType == "Torus" then
        blocks = X.GenerateTorus(center, radius, thickness, blockType, blockSpacing)
        
    elseif shapeType == "Dome" then
        blocks = X.GenerateDome(center, radius, blockType, blockSpacing)
        
    elseif shapeType == "Wave" then
        blocks = X.GenerateWave(center, shapeWidth, shapeHeight, shapeDepth, blockType, blockSpacing)
    end
end

X.TextSettings = {
    Content = "Weshky on Top",
    BlockType = "WoodBlock",
    BlockSize = 1,
    Scale = 1,
    LetterSpacing = 1.2,
    WordSpacing = 3,
    FontWidth = 5,
    FontHeight = 5
}

X.FONT_DEFINITIONS_5X5 = {
    ["A"] = { {0,1,1,1,0}, {1,0,0,0,1}, {1,1,1,1,1}, {1,0,0,0,1}, {1,0,0,0,1} },
    ["B"] = { {1,1,1,1,0}, {1,0,0,0,1}, {1,1,1,1,0}, {1,0,0,0,1}, {1,1,1,1,0} },
    ["C"] = { {0,1,1,1,0}, {1,0,0,0,1}, {1,0,0,0,0}, {1,0,0,0,1}, {0,1,1,1,0} },
    ["D"] = { {1,1,1,1,0}, {1,0,0,0,1}, {1,0,0,0,1}, {1,0,0,0,1}, {1,1,1,1,0} },
    ["E"] = { {1,1,1,1,1}, {1,0,0,0,0}, {1,1,1,0,0}, {1,0,0,0,0}, {1,1,1,1,1} },
    ["F"] = { {1,1,1,1,1}, {1,0,0,0,0}, {1,1,1,0,0}, {1,0,0,0,0}, {1,0,0,0,0} },
    ["G"] = { {0,1,1,1,0}, {1,0,0,0,0}, {1,0,1,1,1}, {1,0,0,0,1}, {0,1,1,1,0} },
    ["H"] = { {1,0,0,0,1}, {1,0,0,0,1}, {1,1,1,1,1}, {1,0,0,0,1}, {1,0,0,0,1} },
    ["I"] = { {1,1,1,1,1}, {0,0,1,0,0}, {0,0,1,0,0}, {0,0,1,0,0}, {1,1,1,1,1} },
    ["J"] = { {1,1,1,1,1}, {0,0,0,0,1}, {0,0,0,0,1}, {1,0,0,0,1}, {0,1,1,1,0} },
    ["K"] = { {1,0,0,0,1}, {1,0,0,1,0}, {1,1,1,0,0}, {1,0,0,1,0}, {1,0,0,0,1} },
    ["L"] = { {1,0,0,0,0}, {1,0,0,0,0}, {1,0,0,0,0}, {1,0,0,0,0}, {1,1,1,1,1} },
    ["M"] = { {1,0,0,0,1}, {1,1,0,1,1}, {1,0,1,0,1}, {1,0,0,0,1}, {1,0,0,0,1} },
    ["N"] = { {1,0,0,0,1}, {1,1,0,0,1}, {1,0,1,0,1}, {1,0,0,1,1}, {1,0,0,0,1} },
    ["O"] = { {0,1,1,1,0}, {1,0,0,0,1}, {1,0,0,0,1}, {1,0,0,0,1}, {0,1,1,1,0} },
    ["P"] = { {1,1,1,1,0}, {1,0,0,0,1}, {1,1,1,1,0}, {1,0,0,0,0}, {1,0,0,0,0} },
    ["Q"] = { {0,1,1,1,0}, {1,0,0,0,1}, {1,0,1,0,1}, {1,0,0,1,0}, {0,1,1,0,1} },
    ["R"] = { {1,1,1,1,0}, {1,0,0,0,1}, {1,1,1,1,0}, {1,0,0,1,0}, {1,0,0,0,1} },
    ["S"] = { {0,1,1,1,1}, {1,0,0,0,0}, {0,1,1,1,0}, {0,0,0,0,1}, {1,1,1,1,0} },
    ["T"] = { {1,1,1,1,1}, {0,0,1,0,0}, {0,0,1,0,0}, {0,0,1,0,0}, {0,0,1,0,0} },
    ["U"] = { {1,0,0,0,1}, {1,0,0,0,1}, {1,0,0,0,1}, {1,0,0,0,1}, {0,1,1,1,0} },
    ["V"] = { {1,0,0,0,1}, {1,0,0,0,1}, {1,0,0,0,1}, {0,1,0,1,0}, {0,0,1,0,0} },
    ["W"] = { {1,0,0,0,1}, {1,0,0,0,1}, {1,0,1,0,1}, {1,1,0,1,1}, {1,0,0,0,1} },
    ["X"] = { {1,0,0,0,1}, {0,1,0,1,0}, {0,0,1,0,0}, {0,1,0,1,0}, {1,0,0,0,1} },
    ["Y"] = { {1,0,0,0,1}, {0,1,0,1,0}, {0,0,1,0,0}, {0,0,1,0,0}, {0,0,1,0,0} },
    ["Z"] = { {1,1,1,1,1}, {0,0,0,1,0}, {0,0,1,0,0}, {0,1,0,0,0}, {1,1,1,1,1} },
    
    ["0"] = { {0,1,1,1,0}, {1,0,0,1,1}, {1,0,1,0,1}, {1,1,0,0,1}, {0,1,1,1,0} },
    ["1"] = { {0,0,1,0,0}, {0,1,1,0,0}, {0,0,1,0,0}, {0,0,1,0,0}, {0,1,1,1,0} },
    ["2"] = { {0,1,1,1,0}, {1,0,0,0,1}, {0,0,1,1,0}, {0,1,0,0,0}, {1,1,1,1,1} },
    ["3"] = { {1,1,1,1,0}, {0,0,0,0,1}, {0,1,1,1,0}, {0,0,0,0,1}, {1,1,1,1,0} },
    ["4"] = { {1,0,0,1,0}, {1,0,0,1,0}, {1,1,1,1,1}, {0,0,0,1,0}, {0,0,0,1,0} },
    ["5"] = { {1,1,1,1,1}, {1,0,0,0,0}, {1,1,1,1,0}, {0,0,0,0,1}, {1,1,1,1,0} },
    ["6"] = { {0,1,1,1,0}, {1,0,0,0,0}, {1,1,1,1,0}, {1,0,0,0,1}, {0,1,1,1,0} },
    ["7"] = { {1,1,1,1,1}, {0,0,0,1,0}, {0,0,1,0,0}, {0,1,0,0,0}, {1,0,0,0,0} },
    ["8"] = { {0,1,1,1,0}, {1,0,0,0,1}, {0,1,1,1,0}, {1,0,0,0,1}, {0,1,1,1,0} },
    ["9"] = { {0,1,1,1,0}, {1,0,0,0,1}, {0,1,1,1,1}, {0,0,0,0,1}, {0,1,1,1,0} },
    
    [" "] = { {0,0,0,0,0}, {0,0,0,0,0}, {0,0,0,0,0}, {0,0,0,0,0}, {0,0,0,0,0} },
    ["!"] = { {0,0,1,0,0}, {0,0,1,0,0}, {0,0,1,0,0}, {0,0,0,0,0}, {0,0,1,0,0} },
    ["?"] = { {0,1,1,1,0}, {1,0,0,0,1}, {0,0,1,1,0}, {0,0,0,0,0}, {0,0,1,0,0} },
    ["."] = { {0,0,0,0,0}, {0,0,0,0,0}, {0,0,0,0,0}, {0,0,0,0,0}, {0,0,1,0,0} },
    [","] = { {0,0,0,0,0}, {0,0,0,0,0}, {0,0,0,0,0}, {0,0,1,0,0}, {0,1,0,0,0} },
    [":"] = { {0,0,0,0,0}, {0,0,1,0,0}, {0,0,0,0,0}, {0,0,1,0,0}, {0,0,0,0,0} },
    ["-"] = { {0,0,0,0,0}, {0,0,0,0,0}, {0,1,1,1,0}, {0,0,0,0,0}, {0,0,0,0,0} },
    ["+"] = { {0,0,0,0,0}, {0,0,1,0,0}, {0,1,1,1,0}, {0,0,1,0,0}, {0,0,0,0,0} },
    ["="] = { {0,0,0,0,0}, {0,1,1,1,0}, {0,0,0,0,0}, {0,1,1,1,0}, {0,0,0,0,0} },
    ["#"] = { {0,1,0,1,0}, {1,1,1,1,1}, {0,1,0,1,0}, {1,1,1,1,1}, {0,1,0,1,0} },
    ["$"] = { {0,1,1,1,0}, {1,0,1,0,0}, {0,1,1,1,0}, {0,0,1,0,1}, {0,1,1,1,0} },
    ["%"] = { {1,0,0,0,1}, {0,0,0,1,0}, {0,0,1,0,0}, {0,1,0,0,0}, {1,0,0,0,1} },
    ["&"] = { {0,1,1,0,0}, {1,0,0,1,0}, {0,1,1,0,1}, {1,0,0,1,0}, {0,1,1,0,1} },
    ["("] = { {0,0,1,0,0}, {0,1,0,0,0}, {0,1,0,0,0}, {0,1,0,0,0}, {0,0,1,0,0} },
    [")"] = { {0,0,1,0,0}, {0,0,0,1,0}, {0,0,0,1,0}, {0,0,0,1,0}, {0,0,1,0,0} },
    ["["] = { {0,1,1,1,0}, {0,1,0,0,0}, {0,1,0,0,0}, {0,1,0,0,0}, {0,1,1,1,0} },
    ["]"] = { {0,1,1,1,0}, {0,0,0,1,0}, {0,0,0,1,0}, {0,0,0,1,0}, {0,1,1,1,0} },
    ["{"] = { {0,0,1,1,0}, {0,0,1,0,0}, {0,1,1,0,0}, {0,0,1,0,0}, {0,0,1,1,0} },
    ["}"] = { {0,1,1,0,0}, {0,0,1,0,0}, {0,0,1,1,0}, {0,0,1,0,0}, {0,1,1,0,0} },
    ["<"] = { {0,0,0,1,0}, {0,0,1,0,0}, {0,1,0,0,0}, {0,0,1,0,0}, {0,0,0,1,0} },
    [">"] = { {0,1,0,0,0}, {0,0,1,0,0}, {0,0,0,1,0}, {0,0,1,0,0}, {0,1,0,0,0} },
    ["'"] = { {0,0,1,0,0}, {0,0,1,0,0}, {0,0,0,0,0}, {0,0,0,0,0}, {0,0,0,0,0} },
    ['"'] = { {0,1,0,1,0}, {0,1,0,1,0}, {0,0,0,0,0}, {0,0,0,0,0}, {0,0,0,0,0} },
    ["/"] = { {0,0,0,0,1}, {0,0,0,1,0}, {0,0,1,0,0}, {0,1,0,0,0}, {1,0,0,0,0} },
    ["\\"] = { {1,0,0,0,0}, {0,1,0,0,0}, {0,0,1,0,0}, {0,0,0,1,0}, {0,0,0,0,1} },
    ["|"] = { {0,0,1,0,0}, {0,0,1,0,0}, {0,0,1,0,0}, {0,0,1,0,0}, {0,0,1,0,0} },
    ["_"] = { {0,0,0,0,0}, {0,0,0,0,0}, {0,0,0,0,0}, {0,0,0,0,0}, {1,1,1,1,1} },
    ["@"] = { {0,1,1,1,0}, {1,0,0,0,1}, {1,0,1,1,1}, {1,0,1,0,1}, {0,1,1,1,0} },
}

local DEFAULT_FONT_BLOCK = { {1,1,1,1,1}, {1,1,1,1,1}, {1,1,1,1,1}, {1,1,1,1,1}, {1,1,1,1,1} }

function X.UpdateSettings(settingName, value)
    X.TextSettings[settingName] = value
    X.GenerateTextPreview()
    X.ListTextBlocks()
end

function X.GetLetterDefinition(char)
    if X.TextSettings.FontWidth ~= 5 or X.TextSettings.FontHeight ~= 5 then
        local customDef = {}
        for y = 1, X.TextSettings.FontHeight do
            customDef[y] = {}
            for x = 1, X.TextSettings.FontWidth do
                customDef[y][x] = 1
            end
        end
        return customDef
    end
    return X.FONT_DEFINITIONS_5X5[string.upper(char)] or DEFAULT_FONT_BLOCK
end

function X.GenerateTextPreview()
    X.ClearPreview()
    
    if X.TextSettings.Content == "" then
        if X.listing then
            X.listing:Clear()
        end
        return
    end
    
    local plot = X.GetPlot()
    if not plot then
        if X.listing then
            X.listing:Clear()
        end
        return
    end
    
    local center = plot.Position + Vector3.new(0, 10, 0)
    local currentX = 0
    
    for i = 1, #X.TextSettings.Content do
        local char = X.TextSettings.Content:sub(i, i)
        
        local letterDef = X.GetLetterDefinition(char)
    
        for row = 1, #letterDef do
            for col = 1, #letterDef[row] do
                if letterDef[row][col] == 1 then
                    local position = center + Vector3.new(
                        currentX + (col-1) * X.TextSettings.BlockSize * X.TextSettings.Scale,
                        (#letterDef-row) * X.TextSettings.BlockSize * X.TextSettings.Scale,
                        0
                    )
                    X.CreatePreviewBlock(position, X.TextSettings.BlockType)
                end
            end
        end
        
        currentX = currentX + (#letterDef[1] * X.TextSettings.Scale + X.TextSettings.LetterSpacing) * X.TextSettings.BlockSize
        
    end
end

function X.ListTextBlocks()
    if X.TextSettings.Content == "" then
        return
    end
    
    local blockCount = 0
    
    for i = 1, #X.TextSettings.Content do
        local char = X.TextSettings.Content:sub(i, i)
        if char ~= " " then
            local letterDef = X.GetLetterDefinition(char)
            if letterDef and #letterDef > 0 and #letterDef[1] > 0 then
                blockCount = blockCount + (#letterDef * #letterDef[1])
            end
        end
    end
    
    local available = playerData[X.TextSettings.BlockType] and playerData[X.TextSettings.BlockType].Value or 0
    local deficit = blockCount - available
    
    X.listing:Clear()
    X.listing:Add(X.TextSettings.BlockType, blockCount, deficit > 0 and deficit or nil)
end

local UiColor = "29, 73, 118"
local r, g, b = string.match(UiColor, "(%d+),%s*(%d+),%s*(%d+)")
local mainColor = Color3.fromRGB(tonumber(r), tonumber(g), tonumber(b))

local window = X.library.new({
    text = "Voltara Auto Build",
    size = Vector2.new(360, 538),
    shadow = 0,
    transparency = 0.25,
    color = mainColor,
    boardcolor = Color3.fromRGB(21, 22, 23),
    rounding = 5,
    animation = 0.1,
    position = UDim2.new(0, 310, 0, 40),
})

window.open()

local mainTab = window.new({ text = "Main" })

mainTab:show()

local fileDropdown
local selectedFile
local firstRefreshDone = false 
local isManualRefresh = false

local dropdownObjects = {} 
local nameToPathMap = {}

local function refreshFiles()
    if not fileDropdown then
        fileDropdown = mainTab.new("dropdown", {
            text = "Files",
        })
        fileDropdown.event:Connect(function(option)
            selectedFile = nameToPathMap[option]
        end)
    end

    if isManualRefresh then
        task.wait(0.1)
    end

    local currentBuilds = X.ListBuilds()

    local namesToRemove = {}
    for name, path in pairs(nameToPathMap) do
        local found = false
        for _, newBuild in ipairs(currentBuilds) do
            if newBuild.name == name and newBuild.path == path then
                found = true
                break
            end
        end
        if not found then
            table.insert(namesToRemove, name)
        end
    end

    for _, name in ipairs(namesToRemove) do
        local objToRemove = dropdownObjects[name]
        if objToRemove then
            if objToRemove.object and objToRemove.object.Parent then
                objToRemove.object.Parent = nil
            end
            if type(objToRemove.Destroy) == "function" then
                objToRemove:Destroy()
            end
        end
        dropdownObjects[name] = nil
        nameToPathMap[name] = nil
    end

    local namesToAdd = {}
    for _, newBuild in ipairs(currentBuilds) do
        if not nameToPathMap[newBuild.name] then 
            table.insert(namesToAdd, newBuild)
        end
    end

    for _, buildInfo in ipairs(namesToAdd) do
        local createdItemObj = fileDropdown.new(buildInfo.name)
        
        if createdItemObj then
            dropdownObjects[buildInfo.name] = createdItemObj
            nameToPathMap[buildInfo.name] = buildInfo.path
        end
    end

    if not selectedFile and #currentBuilds > 0 then
        local randomIndex = math.random(1, #currentBuilds)
        local randomBuild = currentBuilds[randomIndex]
        
        selectedFile = randomBuild.path

        local dropdownObj = dropdownObjects[randomBuild.name]
        if dropdownObj then
            if type(dropdownObj.Select) == "function" then
                dropdownObj.Select()

            end
        end
    end
end

refreshFiles()

mainTab.new("button", {
    text = "Refresh Files",
}).event:Connect(function()
    isManualRefresh = true
    task.spawn(function()
        refreshFiles()
        isManualRefresh = false
    end)
end)

local saveFolder = mainTab.new("folder", {
    text = "Saving",
})

saveFolder.new("input", {
    text = "File Name",
    placeholder = "Enter File Name",
}).event:Connect(function(text)
    saveFileName = text .. ".Build"
end)

local teamDropdown = saveFolder.new("dropdown", {
    text = "Team",
})

local teamOptions = {}
teamOptions["My Team"] = teamDropdown.new("My Team")
teamOptions["white"] = teamDropdown.new("white")
teamOptions["blue"] = teamDropdown.new("blue")
teamOptions["green"] = teamDropdown.new("green")
teamOptions["red"] = teamDropdown.new("red")
teamOptions["black"] = teamDropdown.new("black")
teamOptions["yellow"] = teamDropdown.new("yellow")
teamOptions["magenta"] = teamDropdown.new("magenta")

teamDropdown.event:Connect(function(option)
    if option == "My Team" then
        saveTeam = tostring(player.Team)
    else
        saveTeam = option
    end
end)

teamOptions["My Team"]:Select()

saveFolder.new("button", {
    text = "Save To File",
}).event:Connect(function()
    if not saveFileName or not saveTeam then
        warn("Please enter a file name and select a team!")
        return
    end
    X.SavePlot(saveFileName, saveTeam)
    refreshFiles()
end)
saveFolder.open()

local settingsFolder = mainTab.new("folder", {
    text = "Build Settings",
})
settingsFolder.new("switch", {
    text = "Safe Mode",
}).event:Connect(function(state)
    X.Config.safeMode = state
end)

local speedDropdown = settingsFolder.new("dropdown", {
    text = "Speed",
})

local speedOptions = {}
speedOptions["Very Fast"] = speedDropdown.new("Very Fast")
speedOptions["Fast"] = speedDropdown.new("Fast")
speedOptions["Medium"] = speedDropdown.new("Medium")
speedOptions["Slow"] = speedDropdown.new("Slow")

speedDropdown.event:Connect(function(option)
    if option == "Very Fast" then
        X.Config.speedMode = 0
    elseif option == "Fast" then
        X.Config.speedMode = 1
    elseif option == "Medium" then
        X.Config.speedMode = 2
    elseif option == "Slow" then
        X.Config.speedMode = 3
    end
    speedDropdown:close()
end)

speedOptions["Fast"]:Select()

settingsFolder.new("input", {
    text = "",
    placeholder = "Size %",
}).event:Connect(function(value)
    sizePercent = tonumber(value) / 100
end)

settingsFolder.open()

local builderFolder = mainTab.new("folder", {
    text = "Builder",
})

builderFolder.new("button", {
    text = "List Blocks",
}).event:Connect(function()
    X.ListBuild(selectedFile, sizePercent)
end)

builderFolder.new("button", {
    text = "Preview",
}).event:Connect(function()
    if #workspaceChildren(BuildPreview) <= 0 then
        X.PreviewFile(selectedFile, sizePercent)
    else
        X.ClearPreview()
    end
end)

builderFolder.new("button", {
    text = "Load File",
}).event:Connect(function()
    X.LoadFile(selectedFile, #workspaceChildren(BuildPreview) <= 1 and 1 or sizePercent)
end)
builderFolder.open()



local imagesTab = window.new({ text = "Image" })
local loadersTab = window.new({ text = "Loaders" })

imagesTab.new("label", {
    text = "You can Adjust the Image in the Ajusters Tab.",
})
imagesTab.new("label", {
    text = "\nResolution:\nHiger = Bad Image Quality + Less Blocks\nLower = Better Image Quallity + More Blocks",
})
imagesTab.new("label", { text = "" })

local mainSettings = imagesTab.new("folder", {
    text = "Main Settings",
})
mainSettings.new("input", {
    text = "URL",
    placeholder = "Image URL",
}).event:Connect(function(url)
    imageUrl = url
end)
mainSettings.open()

local imageSettings = imagesTab.new("folder", {
    text = "Build Settings",
})
imageSettings.new("input", {
    text = "Block Size",
    placeholder = "0.5",
}).event:Connect(function(size)
    imageBlockSize = tonumber(size)
    X.ClearPreview()
end)

imageSettings.new("input", {
    text = "Resolution",
    placeholder = "5",
}).event:Connect(function(res)
    resolution = tonumber(res)
    X.ClearPreview()
end)

local imageBlockTypeDropdown = imageSettings.new("dropdown", {
    text = "Block Type",
})
imageBlockTypeDropdown.event:Connect(function(blockTypeOption)
    imageBlockType = blockTypeOption
    X.ClearPreview()
end)

for _, part in next, workspaceChildren(BuildingParts), nil do
    local name = part.Name
    if string.sub(name, #name - 4, #name) == "Block" then
        imageBlockTypeDropdown.new(name)
    end
end
imageSettings.open()

local imageBuilder = imagesTab.new("folder", {
    text = "Builder",
})
imageBuilder.new("button", {
    text = "List Blocks",
}).event:Connect(function()
    X.ListImageBlocks()
end)

imageBuilder.new("button", {
    text = "Preview",
}).event:Connect(function()
    if #workspaceChildren(BuildPreview) > 0 then
        X.ClearPreview()
    else
        X.ProcessImage(imageUrl, imageBlockType, imageBlockSize, resolution, true)
    end
end)

imageBuilder.new("button", {
    text = "Load Image",
}).event:Connect(function()
    if #workspaceChildren(BuildPreview) == 0 then
        X.ProcessImage(imageUrl, imageBlockType, imageBlockSize, resolution, true)
    end
    X.LoadFile(selectedFile, #workspaceChildren(BuildPreview) <= 1 and 1 or sizePercent)
end)
imageBuilder.open()


loadersTab.new("label", {
    text = " ",
})

loadersTab.new("label", {
    text = "Warning: Loader are still under Development, \nthere are maybe some Bugs.\nYou can Adjust the Preview in the Ajusters Tab. \n ",
})

loadersTab.new("label", {
    text = " ",
})

local shapesFolder = loadersTab.new("folder", {
    text = "Shape Loader",
})

local shapeTypeDropdown = shapesFolder.new("dropdown", {
    text = "Shape Type",
})
    shapeTypeDropdown.new("Circle")
    shapeTypeDropdown.new("Ball")
    shapeTypeDropdown.new("Cylinder")
    shapeTypeDropdown.new("Torus")
    shapeTypeDropdown.new("Dome")
    shapeTypeDropdown.new("Wave")
shapeTypeDropdown.event:Connect(function(option)
    shapeType = option
end)

local shapeBlockTypeDropdown = shapesFolder.new("dropdown", {
    text = "Block Type",
})
shapeBlockTypeDropdown.event:Connect(function(option)
    blockType = option
end)

for _, part in next, workspaceChildren(BuildingParts), nil do
    local name = part.Name
    if string.sub(name, #name - 4, #name) == "Block" then
        shapeBlockTypeDropdown.new(name)
    end
end

shapesFolder.new("input", {
    text = "Radius/Size",
    placeholder = "5",
}).event:Connect(function(value)
    radius = tonumber(value) or 5
end)

shapesFolder.new("input", {
    text = "Height",
    placeholder = "10",
}).event:Connect(function(value)
    shapeHeight = tonumber(value) or 10
end)

shapesFolder.new("input", {
    text = "Width",
    placeholder = "10",
}).event:Connect(function(value)
    shapeWidth = tonumber(value) or 10
end)

shapesFolder.new("input", {
    text = "Depth",
    placeholder = "10",
}).event:Connect(function(value)
    shapeDepth = tonumber(value) or 10
end)

shapesFolder.new("input", {
    text = "Thickness",
    placeholder = "1",
}).event:Connect(function(value)
    thickness = tonumber(value) or 1
end)

shapesFolder.new("input", {
    text = "Block Spacing",
    placeholder = "2",
}).event:Connect(function(value)
    blockSpacing = math.max(1, tonumber(value) or 2)
end)

-- Removed advanced 'Sides' and 'Turns' controls to simplify UI for normal users

shapesFolder.new("switch", {
    text = "Center on Plot",
}).event:Connect(function(state)
    centerOnPlot = state
end)

shapesFolder.new("switch", {
    text = "Smooth Rotation",
    value = true,
}).event:Connect(function(state)
    smoothRotation = state
end)

local previewButton = shapesFolder.new("button", {
    text = "Preview Shape",
})

previewButton.event:Connect(function()
    if #workspaceChildren(BuildPreview) > 0 then
        X.ClearPreview()
    else
        X.PreviewShape()
    end
end)

shapesFolder.new("button", {
    text = "Build Shape",
}).event:Connect(function()
    if #workspaceChildren(BuildPreview) == 0 then
        X.PreviewShape()
    end
    
    local blocks = {}
    for _, block in ipairs(X.GetPreviewBlocks()) do
        X.table_insert(blocks, X.CreateBlockData(
            block.Name,
            block.PPart.CFrame,
            block.PPart.Size,
            {Color = block.PPart.Color}
        ))
    end
    
    local jsonTable = X.Encode(blocks)
    local decoded = X.Decode(jsonTable, 1)
    X.LoadBlocks(decoded)
end)

local function listShapeBlocks()
    local blocksInPreview = X.GetPreviewBlocks()
    local required = {}
    
    if #blocksInPreview > 0 then
        for _, block in ipairs(blocksInPreview) do
            required[block.Name] = (required[block.Name] or 0) + 1
        end
    else
        local plot = X.GetPlot()
        if plot then
            local center = centerOnPlot and plot.Position or player.Character and player.Character.HumanoidRootPart.Position or plot.Position
            center = center + Vector3.new(0, radius + 5, 0)
            
            if shapeType == "Ball" then
                local volume = (4/3) * math.pi * math.pow(radius, 3)
                local blockVolume = math.pow(blockSpacing, 3)
                required[blockType] = math.ceil(volume / blockVolume)
            elseif shapeType == "Cylinder" then
                local height = radius * 2
                local baseArea = math.pi * math.pow(radius, 2)
                local blocksHeight = math.ceil(height / blockSpacing)
                local blocksBase = math.ceil(baseArea / math.pow(blockSpacing, 2))
                required[blockType] = blocksHeight * blocksBase
            elseif shapeType == "Circle" then
                local circumference = 2 * math.pi * radius
                local segments = math.max(8, X.math_floor(circumference / blockSpacing))
                required[blockType] = segments * thickness
            else
                required[blockType] = math.ceil((radius * 2) / blockSpacing) ^ 2
            end
        end
    end
    
    local missing = {}
    for blockType, count in pairs(required) do
        local available = playerData[blockType] and playerData[blockType].Value or 0
        local used = playerData[blockType] and playerData[blockType].Used.Value or 0
        local remaining = math.max(0, available - used)
        local deficit = math.max(0, count - remaining)
        missing[blockType] = deficit > 0 and deficit or nil
    end

    X.listing:Clear()
    for blockType, count in pairs(required) do
        X.listing:Add(blockType, count, missing[blockType])
    end
end

shapesFolder.new("button", {
    text = "List Blocks",
}).event:Connect(listShapeBlocks)

local textFolder = loadersTab.new("folder", {
    text = "Text Loader",
})

textFolder.new("input", {
    text = "Text Content",
    placeholder = X.TextSettings.Content,
}).event:Connect(function(text)
    X.UpdateSettings("Content", string.upper(text))
end)

local textBlockTypeDropdown = textFolder.new("dropdown", {
    text = "Block Type",
})
textBlockTypeDropdown.event:Connect(function(blockTypeOption)
    X.UpdateSettings("BlockType", blockTypeOption)
end)

textFolder.new("input", {
    text = "Block Size",
    placeholder = tostring(X.TextSettings.BlockSize),
}).event:Connect(function(size)
    X.UpdateSettings("BlockSize", math.max(0.1, tonumber(size) or X.TextSettings.BlockSize))
end)

textFolder.new("input", {
    text = "Scale",
    placeholder = tostring(X.TextSettings.Scale),
}).event:Connect(function(scale)
    X.UpdateSettings("Scale", math.max(0.1, tonumber(scale) or X.TextSettings.Scale))
end)

textFolder.new("input", {
    text = "Letter Spacing",
    placeholder = tostring(X.TextSettings.LetterSpacing),
}).event:Connect(function(spacing)
    X.UpdateSettings("LetterSpacing", math.max(0.1, tonumber(spacing) or X.TextSettings.LetterSpacing))
end)

textFolder.new("input", {
    text = "Word Spacing",
    placeholder = tostring(X.TextSettings.WordSpacing),
}).event:Connect(function(spacing)
    X.UpdateSettings("WordSpacing", math.max(0.1, tonumber(spacing) or X.TextSettings.WordSpacing))
end)

local foundBuildingParts = false
for _, part in next, workspaceChildren(BuildingParts) or {}, nil do
    local name = part.Name
    if string.sub(name, #name - 4, #name) == "Block" then
        textBlockTypeDropdown.new(name)
        foundBuildingParts = true
    end
end
if not foundBuildingParts then
    textBlockTypeDropdown.new(X.TextSettings.BlockType)
end

textFolder.new("button", {
    text = "Preview Text",
}).event:Connect(X.GenerateTextPreview)

textFolder.new("button", {
    text = "List Blocks",
}).event:Connect(X.ListTextBlocks)

textFolder.new("button", {
    text = "Load Text",
}).event:Connect(function()
    if #workspaceChildren(BuildPreview) == 0 then
        X.GenerateTextPreview()
    end
    
    local blocks = {}
    for _, block in ipairs(X.GetPreviewBlocks()) do
        X.table_insert(blocks, X.CreateBlockData(
            block.Name,
            block.PPart.CFrame,
            block.PPart.Size,
            {Color = block.PPart.Color}
        ))
    end
    
    local jsonTable = pcall(X.Encode, blocks) and X.Encode(blocks)
    if not jsonTable then
        return
    end

    local success, decoded = pcall(X.Decode, jsonTable, 1)
    if not success or not decoded then
        return
    end
    
    X.LoadBlocks(decoded)
    X.ClearPreview()
end)
--textFolder.open()

local terrainFolder = loadersTab.new("folder", {
    text = "Terrain Loader",
})

terrainFolder.new("label", {
    text = "Terrain Loader will be updated soon (Blocky Currently)",
})

local terrainSettings = {
    Type = "Mountain",
    BlockType = "GrassBlock",
    Width = 20,
    Height = 10,
    Depth = 20,
    Scale = 2,
    Roughness = 0.5,
    Seed = 1,
    BlockSize = 2,
    SmoothRotation = false,
    EdgeSmoothing = true,
    DetailDensity = 0.4,
}

local terrainTypeDropdown = terrainFolder.new("dropdown", {
    text = "Terrain Type",
})
terrainTypeDropdown.new("Mountain")
terrainTypeDropdown.new("Hill")
terrainTypeDropdown.new("Valley")
terrainTypeDropdown.new("Plateau")
terrainTypeDropdown.new("Crater")
terrainTypeDropdown.new("Ridge")
terrainTypeDropdown.new("Canyon")
terrainTypeDropdown.new("Dunes")
terrainTypeDropdown.event:Connect(function(option)
    terrainSettings.Type = option
end)

local terrainBlockTypeDropdown = terrainFolder.new("dropdown", {
    text = "Block Type",
})
terrainBlockTypeDropdown.event:Connect(function(option)
    terrainSettings.BlockType = option
end)

for _, part in next, workspaceChildren(BuildingParts), nil do
    local name = part.Name
    if string.sub(name, #name - 4, #name) == "Block" then
        terrainBlockTypeDropdown.new(name)
    end
end

terrainFolder.new("input", {
    text = "Width",
    placeholder = tostring(terrainSettings.Width),
}).event:Connect(function(value)
    terrainSettings.Width = math.max(1, tonumber(value) or terrainSettings.Width)
end)

terrainFolder.new("input", {
    text = "Height",
    placeholder = tostring(terrainSettings.Height),
}).event:Connect(function(value)
    terrainSettings.Height = math.max(1, tonumber(value) or terrainSettings.Height)
end)

terrainFolder.new("input", {
    text = "Depth",
    placeholder = tostring(terrainSettings.Depth),
}).event:Connect(function(value)
    terrainSettings.Depth = math.max(1, tonumber(value) or terrainSettings.Depth)
end)

terrainFolder.new("switch", {
    text = "Smooth Rotation",
    value = false,
}).event:Connect(function(state)
    terrainSettings.SmoothRotation = state
end)

terrainFolder.new("switch", {
    text = "Smooth Edges & Corners",
    value = true,
}).event:Connect(function(state)
    terrainSettings.EdgeSmoothing = state
end)

terrainFolder.new("input", {
    text = "Detail Density (0-1)",
    placeholder = "0.4",
}).event:Connect(function(value)
    terrainSettings.DetailDensity = math.max(0, math.min(1, tonumber(value) or 0.4))
end)

local function noise(x, y, seed)
    local random = Random.new(seed + x * 1000 + y * 1000)
    return random:NextNumber()
end

local function perlinNoise(x, y, seed)
    local function fade(t)
        return t * t * t * (t * (t * 6 - 15) + 10)
    end
    
    local function lerp(t, a, b)
        return a + t * (b - a)
    end
    
    local function grad(hash, x, y)
        local h = hash % 8
        local u = h < 4 and x or y
        local v = h < 4 and y or x
        return ((h % 2 == 0) and u or -u) + ((h % 4 < 2) and v or -v)
    end
    
    local X = math.floor(x) % 255
    local Y = math.floor(y) % 255
    
    x = x - math.floor(x)
    y = y - math.floor(y)
    
    local u = fade(x)
    local v = fade(y)
    
    local random = Random.new(seed)
    local p = {}
    for i = 0, 255 do
        p[i] = i
    end
    for i = 255, 0, -1 do
        local j = math.floor(random:NextNumber() * (i + 1))
        p[i], p[j] = p[j], p[i]
    end
    for i = 0, 255 do
        p[256 + i] = p[i]
    end
    
    local A = p[X] + Y
    local AA = p[A]
    local AB = p[A + 1]
    local B = p[X + 1] + Y
    local BA = p[B]
    local BB = p[B + 1]
    
    return lerp(v, lerp(u, grad(p[AA], x, y),
                      grad(p[BA], x - 1, y)),
                 lerp(u, grad(p[AB], x, y - 1),
                      grad(p[BB], x - 1, y - 1)))
end

local function getTerrainHeight(x, z, terrainType, width, depth, height, scale, roughness, seed)
    local normalizedX = x / width * scale
    local normalizedZ = z / depth * scale
    
    local baseNoise = perlinNoise(normalizedX, normalizedZ, seed)
    local detailNoise = perlinNoise(normalizedX * 2, normalizedZ * 2, seed + 1000) * roughness
    
    local heightValue = baseNoise + detailNoise
    
    if terrainType == "Mountain" then
        local centerDist = math.sqrt((x - width/2)^2 + (z - depth/2)^2) / math.sqrt((width/2)^2 + (depth/2)^2)
        heightValue = heightValue * (1 - centerDist)
        return heightValue * height
        
    elseif terrainType == "Hill" then
        return heightValue * height * 0.7
        
    elseif terrainType == "Valley" then
        local centerDist = math.sqrt((x - width/2)^2 + (z - depth/2)^2) / math.sqrt((width/2)^2 + (depth/2)^2)
        heightValue = heightValue * centerDist
        return heightValue * height * 0.5
        
    elseif terrainType == "Plateau" then
        local centerDist = math.sqrt((x - width/2)^2 + (z - depth/2)^2) / math.sqrt((width/2)^2 + (depth/2)^2)
        if centerDist < 0.3 then
            return height * 0.8
        else
            return heightValue * height * (1 - centerDist)
        end
        
    elseif terrainType == "Crater" then
        local centerDist = math.sqrt((x - width/2)^2 + (z - depth/2)^2) / math.sqrt((width/2)^2 + (depth/2)^2)
        heightValue = heightValue * centerDist
        return heightValue * height * 0.3
        
    elseif terrainType == "Ridge" then
        local ridgePos = math.abs(z - depth/2) / (depth/2)
        heightValue = heightValue * (1 - ridgePos)
        return heightValue * height
        
    elseif terrainType == "Canyon" then
        local canyonPos = math.abs(z - depth/2) / (depth/2)
        heightValue = heightValue * canyonPos
        return heightValue * height * 0.8
        
    elseif terrainType == "Dunes" then
        local dunePattern = math.sin(normalizedX * 3) * 0.5 + 0.5
        return (heightValue * 0.5 + dunePattern * 0.5) * height * 0.6
    end
    
    return heightValue * height
end

local function generateTerrainPreview()
    X.ClearPreview()
    
    local plot = X.GetPlot()
    if not plot then
        return
    end
    
    local center = plot.Position + Vector3.new(0, 10, 0)
    local blocks = {}
    local blockCount = 0
    local heightMap = {}
    
    -- First pass: build height map for smoothing
    for x = 0, terrainSettings.Width - 1 do
        if not heightMap[x] then heightMap[x] = {} end
        for z = 0, terrainSettings.Depth - 1 do
            local height = getTerrainHeight(
                x, z, 
                terrainSettings.Type,
                terrainSettings.Width,
                terrainSettings.Depth,
                terrainSettings.Height,
                terrainSettings.Scale,
                terrainSettings.Roughness,
                terrainSettings.Seed
            )
            heightMap[x][z] = height
        end
    end
    
    local startTime = os.clock()
    
    -- Second pass: generate blocks with smooth edges
    for x = 0, terrainSettings.Width - 1 do
        for z = 0, terrainSettings.Depth - 1 do
            local height = heightMap[x][z]
            local yLevels = X.math_floor(height / terrainSettings.BlockSize)
            
            for y = 0, yLevels do
                local position = center + Vector3.new(
                    (x - terrainSettings.Width/2) * terrainSettings.BlockSize,
                    y * terrainSettings.BlockSize,
                    (z - terrainSettings.Depth/2) * terrainSettings.BlockSize
                )
                
                -- Calculate rotation if smooth rotation is enabled
                local rotation = nil
                if terrainSettings.SmoothRotation then
                    local direction = (position - center).Unit
                    rotation = CFrame.fromMatrix(Vector3.new(), 
                        Vector3.new(direction.X, 0, direction.Z),
                        Vector3.new(0, 1, 0),
                        Vector3.new(-direction.Z, 0, direction.X))
                end
                
                local block = X.CreatePreviewBlock(position, terrainSettings.BlockType, rotation)
                X.table_insert(blocks, block)
                blockCount = blockCount + 1
                
                -- Add edge smoothing blocks if enabled
                if y == yLevels then
                    -- Check neighbors for height differences
                    local neighbors = {
                        {x+1, z}, {x-1, z}, {x, z+1}, {x, z-1},
                        {x+1, z+1}, {x-1, z+1}, {x+1, z-1}, {x-1, z-1}
                    }
                    
                    for _, neighbor in ipairs(neighbors) do
                        local nx, nz = neighbor[1], neighbor[2]
                        if heightMap[nx] and heightMap[nx][nz] then
                            local neighborHeight = heightMap[nx][nz]
                            local heightDiff = height - neighborHeight
                            
                            -- Add intermediate edge blocks for smooth transition
                            if heightDiff > terrainSettings.BlockSize * 0.3 then
                                local offsetX = (nx - x) * 0.5
                                local offsetZ = (nz - z) * 0.5
                                local edgePosition = center + Vector3.new(
                                    (x + offsetX - terrainSettings.Width/2) * terrainSettings.BlockSize,
                                    (y + 0.5) * terrainSettings.BlockSize,
                                    (z + offsetZ - terrainSettings.Depth/2) * terrainSettings.BlockSize
                                )
                                
                                local edgeRotation = nil
                                if terrainSettings.SmoothRotation then
                                    local direction = (edgePosition - center).Unit
                                    edgeRotation = CFrame.fromMatrix(Vector3.new(), 
                                        Vector3.new(direction.X, 0, direction.Z),
                                        Vector3.new(0, 1, 0),
                                        Vector3.new(-direction.Z, 0, direction.X))
                                end
                                
                                -- Create smaller edge block for beveled effect
                                local edgeBlock = X.CreatePreviewBlock(edgePosition, terrainSettings.BlockType, edgeRotation)
                                if edgeBlock and edgeBlock.PPart then
                                    edgeBlock.PPart.Size = edgeBlock.PPart.Size * 0.7
                                end
                                X.table_insert(blocks, edgeBlock)
                                blockCount = blockCount + 1
                            end
                        end
                    end
                    
                    -- Add random surface detail blocks for texture
                    if math.random() < 0.4 then
                        local surfacePosition = position + Vector3.new(0, terrainSettings.BlockSize, 0)
                        local surfaceRotation = nil
                        if terrainSettings.SmoothRotation then
                            local direction = (surfacePosition - center).Unit
                            surfaceRotation = CFrame.fromMatrix(Vector3.new(), 
                                Vector3.new(direction.X, 0, direction.Z),
                                Vector3.new(0, 1, 0),
                                Vector3.new(-direction.Z, 0, direction.X))
                        end
                        local surfaceBlock = X.CreatePreviewBlock(
                            surfacePosition,
                            terrainSettings.BlockType,
                            surfaceRotation
                        )
                        if surfaceBlock and surfaceBlock.PPart then
                            surfaceBlock.PPart.Size = surfaceBlock.PPart.Size * (0.6 + math.random() * 0.4)
                        end
                        X.table_insert(blocks, surfaceBlock)
                        blockCount = blockCount + 1
                    end
                end
            end
            
            if blockCount % 100 == 0 then
                task.wait()
            end
        end
    end
    
    local endTime = os.clock()
    
    return blocks
end

local function listTerrainBlocks()
    local estimatedBlocks = 0
    
    for x = 0, terrainSettings.Width - 1 do
        for z = 0, terrainSettings.Depth - 1 do
            local height = getTerrainHeight(
                x, z, 
                terrainSettings.Type,
                terrainSettings.Width,
                terrainSettings.Depth,
                terrainSettings.Height,
                terrainSettings.Scale,
                terrainSettings.Roughness,
                terrainSettings.Seed
            )
            
            estimatedBlocks = estimatedBlocks + X.math_floor(height / terrainSettings.BlockSize) + 1
        end
    end
    
    local available = playerData[terrainSettings.BlockType] and playerData[terrainSettings.BlockType].Value or 0
    local used = playerData[terrainSettings.BlockType] and playerData[terrainSettings.BlockType].Used.Value or 0
    local remaining = math.max(0, available - used)
    local deficit = math.max(0, estimatedBlocks - remaining)
    
    X.listing:Clear()
    X.listing:Add(terrainSettings.BlockType, estimatedBlocks, deficit > 0 and deficit or nil)
end

local previewButton = terrainFolder.new("button", {
    text = "Preview Terrain",
})

previewButton.event:Connect(function()
    if #workspaceChildren(BuildPreview) > 0 then
        X.ClearPreview()
    else
        generateTerrainPreview()
    end
end)

terrainFolder.new("button", {
    text = "List Blocks",
}).event:Connect(listTerrainBlocks)

terrainFolder.new("button", {
    text = "Build Terrain",
}).event:Connect(function()
    if #workspaceChildren(BuildPreview) == 0 then
        generateTerrainPreview()
    end
    
    local blocks = {}
    for _, block in ipairs(X.GetPreviewBlocks()) do
        local blockCFrame = block.PPart.CFrame
        local blockSize = block.PPart.Size
        local blockColor = block.PPart.Color
        
        X.table_insert(blocks, X.CreateBlockData(
            block.Name,
            blockCFrame,
            blockSize,
            {Color = blockColor}
        ))
    end
    
    local jsonTable = X.Encode(blocks)
    local decoded = X.Decode(jsonTable, 1)
    X.LoadBlocks(decoded)
end)

local advancedTerrain = terrainFolder.new("folder", {
    text = "Advanced Options",
})

advancedTerrain.new("input", {
    text = "Scale",
    placeholder = tostring(terrainSettings.Scale),
}).event:Connect(function(value)
    terrainSettings.Scale = math.max(0.1, tonumber(value) or terrainSettings.Scale)
end)

advancedTerrain.new("input", {
    text = "Roughness",
    placeholder = tostring(terrainSettings.Roughness),
}).event:Connect(function(value)
    terrainSettings.Roughness = math.max(0.1, math.min(1, tonumber(value) or terrainSettings.Roughness))
end)

advancedTerrain.new("input", {
    text = "Seed",
    placeholder = tostring(terrainSettings.Seed),
}).event:Connect(function(value)
    terrainSettings.Seed = math.max(1, tonumber(value) or terrainSettings.Seed)
end)

advancedTerrain.new("input", {
    text = "Block Size",
    placeholder = tostring(terrainSettings.BlockSize),
}).event:Connect(function(value)
    terrainSettings.BlockSize = math.max(1, tonumber(value) or terrainSettings.BlockSize)
end)

local qrTab = loadersTab.new("folder", {
    text = "QR Code Loader",
})

qrTab.new("label", {
    text = "Currently Supporting Text and Links.",
})

local qrContent = nil
local qrBlockSize = 2

local qrMainSettings = qrTab.new("folder", {
    text = "Main Settings",
})
qrMainSettings.new("input", {
    text = "QR Content",
    placeholder = "Enter text or URL",
}).event:Connect(function(text)
    qrContent = text
end)

qrMainSettings.new("input", {
    text = "Block Size",
    placeholder = "2",
}).event:Connect(function(size)
    qrBlockSize = math.max(0.5, tonumber(size) or 2)
    X.ClearPreview()
end)
qrMainSettings.open()

local qrBuilder = qrTab.new("folder", {
    text = "Builder",
})

local function generateQRPreview()
    if not qrContent then
        print("No QR content provided")
        return false
    end
    
    local success, response = pcall(function()
        return request({
            Url = "https://Img123456.pythonanywhere.com/qr-code",
            Method = "POST",
            Headers = {
                ["Content-Type"] = "application/json",
                ["X-API-Key"] = apikey,
            },
            Body = X.HttpService:JSONEncode({
                text = qrContent,
                block_size = qrBlockSize,
                scale = 1,
                error_correction = "M"
            })
        })
    end)
    
    if not success or not response then
        print("Request failed")
        return false
    end
        
    local qrData
    success, qrData = pcall(function()
        return X.HttpService:JSONDecode(response.Body)
    end)
    
    if not success then
        print("JSON decode failed")
        return false
    end
    
    -- Check for error in response
    if qrData.error then
        print("Server error:", qrData.error)
        return false
    end
    
    -- Check if we have matrix data
    if not qrData.matrix then
        print("No matrix data in response")
        return false
    end
    
    local matrix = qrData.matrix
    local size = qrData.size or #matrix
    local plot = X.GetPlot()
    
    if not plot then 
        print("No plot found")
        return false
    end
    
    X.ClearPreview()
    
    local center = plot.Position + Vector3.new(0, 15, 0)
    local blockCount = 0
        
    -- Calculate total size for background
    local totalSize = size * qrBlockSize
    local backgroundSize = totalSize + 8  -- Add 4 blocks padding on each side
    
    -- Create single background block (MetalBlock, will be painted white)
    local backgroundPos = center
    local backgroundClone = workspaceClone(BuildingParts["MetalBlock"])
    backgroundClone.Parent = BuildPreview
    
    if backgroundClone:FindFirstChild("PPart") then
        backgroundClone.PPart.Size = Vector3.new(backgroundSize, qrBlockSize, backgroundSize)
        backgroundClone.PPart.CFrame = CFrame.new(backgroundPos)
        backgroundClone.PPart.Anchored = true
        backgroundClone.PPart.CanCollide = false
        backgroundClone.PPart.Transparency = 0
        backgroundClone.PPart.Color = Color3.new(1, 1, 1) -- White color
    end
    
    -- Create black QR code blocks on top of background (PlasticBlock, will be painted black)
    for y = 1, size do
        for x = 1, size do
            if matrix[y] and matrix[y][x] == 1 then  -- QR code pattern (black blocks)
                local position = center + Vector3.new(
                    (x - size/2 - 0.5) * qrBlockSize,
                    qrBlockSize,  -- Raise above background
                    (y - size/2 - 0.5) * qrBlockSize
                )
                
                local clone = workspaceClone(BuildingParts["PlasticBlock"])
                clone.Parent = BuildPreview
                
                if clone:FindFirstChild("PPart") then
                    clone.PPart.Size = Vector3.new(qrBlockSize, qrBlockSize, qrBlockSize)
                    clone.PPart.CFrame = CFrame.new(position)
                    clone.PPart.Anchored = true
                    clone.PPart.CanCollide = false
                    clone.PPart.Transparency = 0
                    clone.PPart.Color = Color3.new(0, 0, 0) -- Black color
                end
                
                blockCount = blockCount + 1
            end
        end
        if y % 5 == 0 then
            task.wait()
        end
    end
    return true
end

qrBuilder.new("button", {
    text = "Preview",
}).event:Connect(function()
    if #workspaceChildren(BuildPreview) > 0 then
        X.ClearPreview()
    else
        generateQRPreview()
    end
end)

local function listQRBlocks()
    if not qrContent then
        return
    end
    
    local success, response = pcall(function()
        return request({
            Url = "https://Img123456.pythonanywhere.com/qr-code",
            Method = "POST",
            Headers = {
                ["Content-Type"] = "application/json",
                ["X-API-Key"] = apikey,
            },
            Body = X.HttpService:JSONEncode({
                text = qrContent,
                block_size = qrBlockSize,
                scale = 1,
                error_correction = "M"
            })
        })
    end)
    
    local qrBlocks = 0
    local size = 21
    
    if success and response then
        local qrData = X.HttpService:JSONDecode(response.Body)
        if qrData and qrData.block_count then
            qrBlocks = qrData.block_count
        end
        if qrData and qrData.size then
            size = qrData.size
        end
    else
        -- Estimate: QR codes are typically ~30% filled
        qrBlocks = math.ceil(size * size * 0.3)
    end
    
    -- We need:
    -- 1. Background block (1 MetalBlock, painted white)
    -- 2. QR pattern blocks (qrBlocks PlasticBlock, painted black)
    
    local metalBlockData = playerData["MetalBlock"]
    local metalAvailable = metalBlockData and metalBlockData.Value or 0
    local metalUsed = metalBlockData and metalBlockData.Used.Value or 0
    local metalRemaining = math.max(0, metalAvailable - metalUsed)
    local metalDeficit = math.max(0, 1 - metalRemaining)
    
    local plasticBlockData = playerData["PlasticBlock"]
    local plasticAvailable = plasticBlockData and plasticBlockData.Value or 0
    local plasticUsed = plasticBlockData and plasticBlockData.Used.Value or 0
    local plasticRemaining = math.max(0, plasticAvailable - plasticUsed)
    local plasticDeficit = math.max(0, qrBlocks - plasticRemaining)
    
    X.listing:Clear()
    X.listing:Add("MetalBlock", 1, metalDeficit > 0 and metalDeficit or nil)
    X.listing:Add("PlasticBlock", qrBlocks, plasticDeficit > 0 and plasticDeficit or nil)
    
    X.UpdateProgression("Done")
end

qrBuilder.new("button", {
    text = "List Blocks",
}).event:Connect(listQRBlocks)

local function buildQRCode()
    if #workspaceChildren(BuildPreview) == 0 then
        if not generateQRPreview() then
            return
        end
        print("QR preview generated, starting build...")
    end
    
    local blocks = {}
    local blocksToPaint = {}
    local previewBlocks = X.GetPreviewBlocks()
    
    if #previewBlocks == 0 then
        print("No preview blocks found")
        return
    end
    
    -- First build all the blocks
    for _, block in ipairs(previewBlocks) do
        if block:FindFirstChild("PPart") then
            X.table_insert(blocks, {
                Name = block.Name,
                PPart = {
                    CFrame = block.PPart.CFrame,
                    CastShadow = false,
                    CanCollide = true,
                    Anchored = true,
                    Transparency = 0,
                    Color = block.PPart.Color, -- Keep original color for now
                    Size = block.PPart.Size,
                },
            })
            
            -- Store blocks that need painting
            X.table_insert(blocksToPaint, {
                Block = block,
                TargetColor = block.PPart.Color
            })
        end
    end
    
    local jsonTable = X.Encode(blocks)
    local decoded = X.Decode(jsonTable, 1)
    
    -- Load the blocks first
    X.LoadBlocks(decoded)
    
    -- Wait a moment for blocks to be placed
    task.wait(2)
    
    -- Now paint the blocks with proper colors
    local paintingTool = X.GetTool("PaintingTool")
    if paintingTool then
        -- Find the placed blocks (they'll be in workspace.Blocks)
        local playerName = X.Players.LocalPlayer.Name
        local playerBlocks = workspace.Blocks:FindFirstChild(playerName)
        
        if playerBlocks then
            local paintArgs = {}
            
            -- Collect all blocks that need painting
            for _, blockFolder in ipairs(playerBlocks:GetChildren()) do
                if blockFolder:IsA("Model") and blockFolder:FindFirstChild("PPart") then
                    local blockName = blockFolder.Name
                    local targetColor = nil
                    
                    -- Determine what color this block should be
                    if blockName == "MetalBlock" then
                        targetColor = Color3.new(1, 1, 1) -- White
                    elseif blockName == "PlasticBlock" then
                        targetColor = Color3.new(0, 0, 0) -- Black
                    end
                    
                    if targetColor then
                        -- Check if color is different from default
                        if X.ShouldPaintBlock(blockName, targetColor) then
                            X.table_insert(paintArgs, {
                                blockFolder,
                                targetColor
                            })
                        end
                    end
                end
            end
            
            -- Paint all blocks at once
            if #paintArgs > 0 then
                remoteInvoke(paintingTool, paintArgs)
            end
        end
    end
    
    X.ClearPreview()
end

qrBuilder.new("button", {
    text = "Load QR",
}).event:Connect(buildQRCode)
qrBuilder.open()



local objSettings = {
    SelectedFile = nil,
    BlockType = "WoodBlock",
    Scale = 1.0,
    Quality = "ULTRA",
    SmoothRotation = true,
    AdvancedMode = true,
    AutoAdjust = true,  
}

local QUALITY_PRESETS = {
    LOW = { 
        VoxelSize = 2.0, 
        SafeVoxelSize = 2.0,
        Description = "Very blocky",
        MaxBlocks = 5000
    },
    MEDIUM = { 
        VoxelSize = 1.0, 
        SafeVoxelSize = 1.0,
        Description = "Decent",
        MaxBlocks = 20000
    },
    HIGH = { 
        VoxelSize = 0.5, 
        SafeVoxelSize = 0.5,
        Description = "Detailed",
        MaxBlocks = 100000
    },
    ULTRA = { 
        VoxelSize = 0.001, 
        SafeVoxelSize = 0.0001, 
        Description = "Near Perfect",
        MaxBlocks = 250000000000
    }
}


function X.SendToServer(filePath, quality, advancedMode)
    if not isfile(filePath) then
        X.SetStatus("File not found")
        return nil
    end
    
    local preset = QUALITY_PRESETS[quality] or QUALITY_PRESETS.HIGH
    local objContent = readfile(filePath)
    
    if not objContent or objContent == "" then
        X.SetStatus("File is empty")
        return nil
    end
    
    local voxelSize = preset.VoxelSize
    if quality == "ULTRA" and advancedMode then
        voxelSize = preset.SafeVoxelSize
        print(string.format("Using safe voxel size: %.2f (was %.2f)", voxelSize, preset.VoxelSize))
    end
    
    X.SetStatus("📡 Sending to server...")
    
    local requestBody = {
        obj_content = objContent,
        voxel_size = voxelSize,
        scale = objSettings.Scale,
        smooth_rotation = objSettings.SmoothRotation,
        advanced_mode = advancedMode
    }
    
    local success, response = pcall(function()
        return request({
            Url = "https://Img123456.pythonanywhere.com/obj-to-voxels-optimized",
            Method = "POST",
            Headers = {
                ["Content-Type"] = "application/json",
                ["X-API-Key"] = apikey,
            },
            Body = X.HttpService:JSONEncode(requestBody),
            Timeout = 90 
        })
    end)
    
    if not success or not response then
        X.SetStatus("❌ Server connection failed")
        return nil
    end
    
    if response.StatusCode ~= 200 then
        X.SetStatus("❌ Server error: " .. tostring(response.StatusCode))
        
        if quality == "ULTRA" and objSettings.AutoAdjust then
            X.SetStatus("⚠️ ULTRA failed, trying HIGH quality...")
            print("Auto-adjusting to HIGH quality")
            
            return X.SendToServer(filePath, "HIGH", advancedMode)
        end
        
        return nil
    end
    
    local voxelData
    success, voxelData = pcall(function()
        return X.HttpService:JSONDecode(response.Body)
    end)
    
    if not success or not voxelData then
        X.SetStatus("❌ Failed to parse server response")
        return nil
    end
    
    if voxelData.error then
        X.SetStatus("❌ Server error: " .. tostring(voxelData.error))
        return nil
    end
    
    print("✅ Server response received!")
    print(string.format("   • Voxel count: %d", voxelData.voxel_count or 0))
    print(string.format("   • Quality mode: %s", voxelData.quality_mode or "standard"))
    
    return voxelData
end

function X.ScaleBlockAdvanced(block, targetSize, targetCFrame)
    if not block then return false end
    
    local scalingTool = X.GetTool("ScalingTool")
    if not scalingTool then
        warn("ScalingTool not found!")
        return false
    end
    
    local part = block:FindFirstChild("PPart") or block.PrimaryPart
    if not part then return false end
    
    local sizeVec = targetSize
    if type(targetSize) == "table" then
        sizeVec = Vector3.new(targetSize[1] or 2, targetSize[2] or 2, targetSize[3] or 2)
    end
    
    local targetCF = targetCFrame or part.CFrame
    
    if math.abs(sizeVec.X - sizeVec.Y) > 0.1 or math.abs(sizeVec.Y - sizeVec.Z) > 0.1 then
        -- Non-uniform size detected
        --print(string.format("🔷 Non-uniform block: %.2f, %.2f, %.2f", 
        --    sizeVec.X, sizeVec.Y, sizeVec.Z))
    end
    
    local success = pcall(function()
        scalingTool:InvokeServer(block, sizeVec, targetCF)
    end)
    
    return success
end

function X.ScaleBlockNonUniform(block, targetSizes, targetCFrame)
    if not block then return false end
    
    local scalingTool = X.GetTool("ScalingTool")
    if not scalingTool then
        warn("ScalingTool not found!")
        return false
    end
    
    local sizeVec
    if type(targetSizes) == "table" then
        sizeVec = Vector3.new(
            targetSizes[1] or 2,
            targetSizes[2] or 2, 
            targetSizes[3] or 2
        )
    else
        sizeVec = targetSizes
    end
    
    local part = block:FindFirstChild("PPart") or block.PrimaryPart
    if not part then return false end
    
    local originalSize = part.Size
    
    print(string.format("Scaling block from (%.2f, %.2f, %.2f) to (%.2f, %.2f, %.2f)", 
        originalSize.X, originalSize.Y, originalSize.Z,
        sizeVec.X, sizeVec.Y, sizeVec.Z))
    
    local targetCF = targetCFrame or part.CFrame
    
    local success = pcall(function()
        scalingTool:InvokeServer(block, sizeVec, targetCF)
    end)
    
    if success then
        task.wait(0.1)
        if part.Size.X ~= sizeVec.X or part.Size.Y ~= sizeVec.Y or part.Size.Z ~= sizeVec.Z then
            print("⚠️ Block may not have scaled correctly - retrying...")
            pcall(function()
                scalingTool:InvokeServer(block, sizeVec, targetCF)
            end)
        else
            print(string.format("✅ Block scaled to %.2f, %.2f, %.2f", 
                part.Size.X, part.Size.Y, part.Size.Z))
        end
    end
    
    return success
end

function X.CreatePerfectBlock(voxelData, basePos, blockType, scalingTool)
    local pos = voxelData.position
    local size = voxelData.size or {2, 2, 2}
    local rotation = voxelData.rotation or {0, 0, 0}
    
    local blockSize = Vector3.new(size[1], size[2], size[3])
    local worldPos = basePos + Vector3.new(pos[1], pos[2], pos[3])
    
    local rotCF = CFrame.Angles(
        math.rad(rotation[1] or 0),
        math.rad(rotation[2] or 0),
        math.rad(rotation[3] or 0)
    )
    
    local clone = workspaceClone(BuildingParts[blockType])
    clone.Parent = BuildPreview
    
    if not clone:FindFirstChild("PPart") then
        clone:Destroy()
        return nil
    end
    
    local part = clone.PPart
    part.CFrame = CFrame.new(worldPos)
    part.Anchored = true
    part.CanCollide = false
    part.Transparency = 0
    
    if scalingTool and (blockSize.X ~= 2 or blockSize.Y ~= 2 or blockSize.Z ~= 2) then
        local success = pcall(function()
            scalingTool:InvokeServer(clone, blockSize, part.CFrame)
        end)
        
        if not success then
            warn("Scaling failed for block")
        end
        
        task.wait(0.005)
    end
    
    local halfSize = part.Size / 2
    

    local rotatedCF = CFrame.new(worldPos) * rotCF
    
    local corners = {
        Vector3.new(-halfSize.X, -halfSize.Y, -halfSize.Z),
        Vector3.new( halfSize.X, -halfSize.Y, -halfSize.Z),
        Vector3.new(-halfSize.X,  halfSize.Y, -halfSize.Z),
        Vector3.new( halfSize.X,  halfSize.Y, -halfSize.Z),
        Vector3.new(-halfSize.X, -halfSize.Y,  halfSize.Z),
        Vector3.new( halfSize.X, -halfSize.Y,  halfSize.Z),
        Vector3.new(-halfSize.X,  halfSize.Y,  halfSize.Z),
        Vector3.new( halfSize.X,  halfSize.Y,  halfSize.Z),
    }
    
    local worldCorners = {}
    local minCorner = Vector3.new(math.huge, math.huge, math.huge)
    local maxCorner = Vector3.new(-math.huge, -math.huge, -math.huge)
    
    for _, corner in ipairs(corners) do
        local worldCorner = worldPos + rotCF * corner
        table.insert(worldCorners, worldCorner)
        
        minCorner = Vector3.new(
            math.min(minCorner.X, worldCorner.X),
            math.min(minCorner.Y, worldCorner.Y),
            math.min(minCorner.Z, worldCorner.Z)
        )
        maxCorner = Vector3.new(
            math.max(maxCorner.X, worldCorner.X),
            math.max(maxCorner.Y, worldCorner.Y),
            math.max(maxCorner.Z, worldCorner.Z)
        )
    end
    
    local actualCenter = (minCorner + maxCorner) / 2
    
    part.CFrame = CFrame.new(actualCenter) * rotCF
    
    return clone
end

function X.PreviewOBJModel()
    X.ClearPreview()
    
    if not objSettings.SelectedFile then
        X.SetStatus("❌ No file selected")
        return
    end
    
    local voxelData = X.SendToServer(objSettings.SelectedFile, objSettings.Quality, objSettings.AdvancedMode)
    
    if not voxelData then
        X.SetStatus("❌ Failed to get voxel data")
        return
    end
    
    print("=== SERVER RESPONSE ===")
    for k, v in pairs(voxelData) do
        print(string.format("Key: %s, Type: %s", k, type(v)))
    end
    
    local voxels = {}
    
    if voxelData.voxels then
        voxels = voxelData.voxels
        print("✅ Found voxels array with " .. #voxels .. " entries")
    elseif voxelData.positions then
        print("📦 Converting positions to voxels")
        for i, pos in ipairs(voxelData.positions) do
            table.insert(voxels, {
                position = pos,
                size = {voxelData.voxel_size or 2, voxelData.voxel_size or 2, voxelData.voxel_size or 2},
                rotation = {0, 0, 0}
            })
        end
    elseif type(voxelData) == "table" and not voxelData.voxels and not voxelData.positions then
        print("⚠️ Response might be direct voxel array")
        for i, item in ipairs(voxelData) do
            if type(item) == "table" and item.position then
                table.insert(voxels, item)
            end
        end
    end
    
    if #voxels == 0 then
        print("❌ No voxels found in response!")
        print("Response content:")
        print(X.HttpService:JSONEncode(voxelData))
        X.SetStatus("❌ No voxel data in response")
        return
    end
    
    print(string.format("📦 Processing %d voxels", #voxels))
    
    local nonUniformCount = 0
    for i, voxel in ipairs(voxels) do
        if i <= 5 then  
            print(string.format("Voxel %d: pos=(%.2f,%.2f,%.2f), size=(%.2f,%.2f,%.2f)", 
                i,
                voxel.position and voxel.position[1] or 0,
                voxel.position and voxel.position[2] or 0,
                voxel.position and voxel.position[3] or 0,
                voxel.size and voxel.size[1] or 2,
                voxel.size and voxel.size[2] or 2,
                voxel.size and voxel.size[3] or 2
            ))
        end
        
        if voxel.size then
            local s = voxel.size
            if math.abs(s[1] - s[2]) > 0.1 or math.abs(s[2] - s[3]) > 0.1 then
                nonUniformCount = nonUniformCount + 1
            end
        end
    end
    
    print(string.format("📊 Non-uniform blocks: %d/%d", nonUniformCount, #voxels))
    
    local plot = X.GetPlot()
    if not plot then
        X.SetStatus("❌ No plot found")
        return
    end
    
    local minX, minY, minZ = math.huge, math.huge, math.huge
    local maxX, maxY, maxZ = -math.huge, -math.huge, -math.huge
    
    for _, voxel in ipairs(voxels) do
        if voxel.position then
            local pos = voxel.position
            minX = math.min(minX, pos[1] or 0)
            minY = math.min(minY, pos[2] or 0)
            minZ = math.min(minZ, pos[3] or 0)
            maxX = math.max(maxX, pos[1] or 0)
            maxY = math.max(maxY, pos[2] or 0)
            maxZ = math.max(maxZ, pos[3] or 0)
        end
    end
    
    local modelCenter = Vector3.new(
        (minX + maxX) / 2,
        (minY + maxY) / 2,
        (minZ + maxZ) / 2
    )
    
    print(string.format("📐 Model bounds: X(%.2f-%.2f) Y(%.2f-%.2f) Z(%.2f-%.2f)", 
        minX, maxX, minY, maxY, minZ, maxZ))
    print(string.format("🎯 Model center: (%.2f, %.2f, %.2f)", 
        modelCenter.X, modelCenter.Y, modelCenter.Z))
    
    local basePos = plot.Position + Vector3.new(0, 15, 0) - modelCenter
    local totalVoxels = #voxels
    
    X.SetStatus(string.format("🏗️ Creating preview: 0/%d voxels", totalVoxels))
    X.UpdateProgression(0)
    
    local BATCH_SIZE = 400
    local placed = 0
    
    for i = 1, totalVoxels, BATCH_SIZE do
        for j = 0, math.min(BATCH_SIZE - 1, totalVoxels - i) do
            local idx = i + j
            local voxel = voxels[idx]
            
            if voxel and voxel.position then
                local pos = voxel.position
                local size = voxel.size or {2, 2, 2}
                
                local worldPos = basePos + Vector3.new(
                    pos[1] or 0,
                    pos[2] or 0,
                    pos[3] or 0
                )
                
                local clone = workspaceClone(BuildingParts["MetalBlock"])
                clone.Parent = BuildPreview
                
                if clone:FindFirstChild("PPart") then
                    local part = clone.PPart
                    
                    part.CFrame = CFrame.new(worldPos)
                    part.Anchored = true
                    part.CanCollide = false
                    part.Transparency = 0.3
                    part.Size = Vector3.new(1, 1, 1)
                    
                    local isNonUniform = math.abs(size[1] - size[2]) > 0.1 or math.abs(size[2] - size[3]) > 0.1
                    
                    if isNonUniform then
                        if size[1] > size[2] * 1.2 then
                            part.Color = Color3.new(1, 0.5, 0.5)
                        elseif size[2] > size[1] * 1.2 then
                            part.Color = Color3.new(0.5, 1, 0.5) 
                        elseif size[3] > size[1] * 1.2 then
                            part.Color = Color3.new(0.5, 0.5, 1) 
                        else
                            part.Color = Color3.new(1, 1, 0)   
                        end
                    else
                        part.Color = Color3.new(1, 1, 1) 
                    end
                end
                
                placed = placed + 1
            end
        end
        
        local percent = math.floor((placed / totalVoxels) * 100)
        X.UpdateProgression(percent)
        X.SetStatus(string.format("🏗️ Preview: %d/%d voxels (%d%%)", 
            placed, totalVoxels, percent))
        task.wait()
    end
    
    X.UpdateProgression(100)
    
    local finalBlocks = X.GetPreviewBlocks()
    print(string.format("✅ Preview complete: %d blocks placed", #finalBlocks))
    
    if #finalBlocks == 0 then
        X.SetStatus("❌ No blocks placed!")
    elseif #finalBlocks == 1 then
        X.SetStatus("⚠️ Only 1 block - something's wrong!")
    else
        X.SetStatus(string.format("✅ Preview: %d voxels", #finalBlocks))
    end
end


function X.VisualizeConnections()
    local previewBlocks = X.GetPreviewBlocks()
    if #previewBlocks == 0 then
        print("No blocks to check")
        return
    end
    
    print("\n🔍 VISUAL CONNECTION CHECK")
    print("Green = Perfect connection")
    print("Yellow = Small gap")
    print("Red = Overlap")
    print("━━━━━━━━━━━━━━━━━━━━━━")
    
    local highlightColor = Color3.new(0, 1, 0)
    
    for i = 1, #previewBlocks do
        for j = i + 1, #previewBlocks do
            local block1 = previewBlocks[i]
            local block2 = previewBlocks[j]
            
            if block1 and block2 and block1:FindFirstChild("PPart") and block2:FindFirstChild("PPart") then
                local part1 = block1.PPart
                local part2 = block2.PPart
                
                local dist = (part1.Position - part2.Position).Magnitude
                local size1 = part1.Size.Magnitude / 2
                local size2 = part2.Size.Magnitude / 2
                local expectedDist = size1 + size2
                
                local ratio = dist / expectedDist
                
                if math.abs(ratio - 1) < 0.05 then
                    highlightColor = Color3.new(0, 1, 0) 
                elseif ratio > 1 then
                    highlightColor = Color3.new(1, 1, 0) 
                else
                    highlightColor = Color3.new(1, 0, 0) 
                end
                
                if i <= 5 then 
                    print(string.format("Blocks %d-%d: %.2f/%.2f = %.2f %s", 
                        i, j, dist, expectedDist, ratio,
                        ratio > 1.05 and "GAP" or (ratio < 0.95 and "OVERLAP" or "PERFECT")))
                end
            end
        end
    end
end

function X.EstimateOBJBlocks()
    if not objSettings.SelectedFile then
        X.listing:Clear()
        X.listing:Add("❌ Error", "No file selected", nil)
        return
    end
    
    X.SetStatus("📊 Getting block count from server...")
    
    local voxelData = X.SendToServer(objSettings.SelectedFile, objSettings.Quality, objSettings.AdvancedMode)
    
    if not voxelData or not voxelData.voxel_count then
        X.SetStatus("❌ Could not get block count")
        return
    end
    
    local estimatedBlocks = voxelData.voxel_count
    local preset = QUALITY_PRESETS[objSettings.Quality] or QUALITY_PRESETS.ULTRA
    
    local blockData = playerData[objSettings.BlockType]
    local available = blockData and blockData.Value or 0
    local used = blockData and blockData.Used.Value or 0
    local remaining = math.max(0, available - used)
    local deficit = math.max(0, estimatedBlocks - remaining)
    
    X.listing:Clear()
    
    X.listing:Add(objSettings.BlockType, estimatedBlocks, deficit > 0 and deficit or nil)
    
    X.listing:Add("Info", "━━━━━━━━━━━━━━━━", nil)
    
    X.listing:Add("Info", string.format("📌 Quality: %s", objSettings.Quality), nil)
    X.listing:Add("Info", string.format("📏 Spacing: %.2f", preset.VoxelSize), nil)
    X.listing:Add("Info", string.format("🔢 Voxels: %d", estimatedBlocks), nil)
    
    if voxelData.advanced_mode then
        X.listing:Add("Info", "✨ Advanced mode: ENABLED", nil)
        X.listing:Add("Info", "   • Non-uniform scaling", nil)
        X.listing:Add("Info", "   • Per-block rotation", nil)
    end
    
    if voxelData.bounds and voxelData.bounds.size then
        local size = voxelData.bounds.size
        X.listing:Add("Info", string.format("📐 Dimensions: %.1f x %.1f x %.1f", 
            size[1] or 0, size[2] or 0, size[3] or 0), nil)
    end
    
    local totalVolume = estimatedBlocks * (preset.VoxelSize^3)
    X.listing:Add("Info", string.format("📦 Volume: %.1f", totalVolume), nil)
    
    X.listing:Add("Info", "━━━━━━━━━━━━━━━━", nil)
    X.listing:Add("Info", string.format("📊 Available: %d", available), nil)
    X.listing:Add("Info", string.format("📊 Used: %d", used), nil)
    X.listing:Add("Info", string.format("📊 Remaining: %d", remaining), nil)
    
    if deficit > 0 then
        X.listing:Add("Info", string.format("⚠️ Need %d more blocks!", deficit), nil)
    else
        X.listing:Add("Info", "✅ Enough blocks available!", nil)
    end
    
    X.SetStatus(string.format("📊 Need %d %s blocks", estimatedBlocks, objSettings.BlockType))
end

function X.BuildOBJModel()
    if #workspaceChildren(BuildPreview) == 0 then
        X.SetStatus("🔄 Generate preview first...")
        return
    end
    
    X.SetStatus("🏗️ Preparing build data...")
    
    local voxelData = X.SendToServer(objSettings.SelectedFile, objSettings.Quality, objSettings.AdvancedMode)
    
    if not voxelData then
        X.SetStatus("❌ Failed to get voxel data")
        return
    end
    
    local voxels = voxelData.voxels or {}
    if #voxels == 0 and voxelData.positions then
        for _, pos in ipairs(voxelData.positions) do
            table.insert(voxels, {
                position = pos,
                size = {voxelData.voxel_size or 2, voxelData.voxel_size or 2, voxelData.voxel_size or 2},
                rotation = {0, 0, 0}
            })
        end
    end
    
    if #voxels == 0 then
        X.SetStatus("❌ No voxel data")
        return
    end
    
    local minX, minY, minZ = math.huge, math.huge, math.huge
    local maxX, maxY, maxZ = -math.huge, -math.huge, -math.huge
    
    for _, voxel in ipairs(voxels) do
        local pos = voxel.position
        minX = math.min(minX, pos[1])
        minY = math.min(minY, pos[2])
        minZ = math.min(minZ, pos[3])
        maxX = math.max(maxX, pos[1])
        maxY = math.max(maxY, pos[2])
        maxZ = math.max(maxZ, pos[3])
    end
    
    local modelCenter = Vector3.new(
        (minX + maxX) / 2,
        (minY + maxY) / 2,
        (minZ + maxZ) / 2
    )
    
    local plot = X.GetPlot()
    local basePos = plot.Position + Vector3.new(0, 15, 0) - modelCenter
    
    local blocks = {}
    local total = #voxels
    
    X.SetStatus(string.format("🏗️ Encoding %d blocks...", total))
    X.UpdateProgression(0)
    
    for i, voxel in ipairs(voxels) do
        local pos = voxel.position
        local size = voxel.size or {2, 2, 2}
        local rot = voxel.rotation or {0, 0, 0}
        
        local worldPos = basePos + Vector3.new(pos[1], pos[2], pos[3])
        
        local rotCF = CFrame.Angles(
            math.rad(rot[1] or 0),
            math.rad(rot[2] or 0),
            math.rad(rot[3] or 0)
        )
        
        local blockData = {
            Name = objSettings.BlockType,
            PPart = {
                CFrame = CFrame.new(worldPos) * rotCF,
                Size = Vector3.new(size[1], size[2], size[3]),
                Color = Color3.new(1, 1, 1),  
                Anchored = true,
                CanCollide = true,
                CastShadow = true,
                Transparency = 0
            }
        }
        
        table.insert(blocks, blockData)
        
        if i % 100 == 0 then
            X.UpdateProgression(math.floor((i / total) * 50))
            task.wait()
        end
    end
    
    X.UpdateProgression(50)
    X.SetStatus("🏗️ Building model...")
    
    local jsonTable = X.Encode(blocks)
    if jsonTable then
        local decoded = X.Decode(jsonTable, 1)
        if decoded and next(decoded) then
            X.LoadBlocks(decoded)
        end
    end
    
    X.ClearPreview()
end


local objTab = window.new({ text = "3D Models" })

objTab.new("label", {
    text = " \n🚀 ADVANCED 3D MODEL LOADER\n✨ Non-uniform scaling + per-block rotation",
})

local fileDropdown = objTab.new("dropdown", {
    text = "📁 Select .OBJ File",
})

local dropdownItems = {}
local nameToPathMap = {}

local function refreshOBJFiles()
    local files = {}
    
    if isfolder("WeshkyBuildStorage") then
        for _, filePath in ipairs(listfiles("WeshkyBuildStorage")) do
            local fileName = filePath:match(".+[\\/](.+)") or filePath
            if string.lower(fileName:sub(-4)) == ".obj" then
                table.insert(files, {
                    name = fileName:sub(1, -5),
                    path = filePath
                })
            end
        end
    end
    
    for _, filePath in ipairs(listfiles("")) do
        local fileName = filePath:match(".+[\\/](.+)") or filePath
        if string.lower(fileName:sub(-4)) == ".obj" then
            local exists = false
            for _, f in ipairs(files) do
                if f.name == fileName:sub(1, -5) then
                    exists = true
                    break
                end
            end
            if not exists then
                table.insert(files, {
                    name = fileName:sub(1, -5),
                    path = filePath
                })
            end
        end
    end
    
    for _, item in pairs(dropdownItems) do
        if item and item.Remove then
            item:Remove()
        end
    end
    dropdownItems = {}
    nameToPathMap = {}
    
    for _, file in ipairs(files) do
        local item = fileDropdown.new(file.name)
        if item then
            dropdownItems[file.name] = item
            nameToPathMap[file.name] = file.path
        end
    end
    
    if #files > 0 and not objSettings.SelectedFile then
        objSettings.SelectedFile = files[1].path
        print("Auto-selected:", files[1].name)
    end
    
    return #files
end

fileDropdown.event:Connect(function(selectedName)
    objSettings.SelectedFile = nameToPathMap[selectedName]
    print("Selected file:", objSettings.SelectedFile)
end)

objTab.new("button", {
    text = "🔄 Refresh File List",
}).event:Connect(refreshOBJFiles)

local settingsFolder = objTab.new("folder", {
    text = "⚙️ Advanced Settings",
})

local qualityDropdown = settingsFolder.new("dropdown", {
    text = "🎚️ Quality Level",
})

qualityDropdown.new("🔴 LOW - 2.0 spacing (fast, blocky)")
qualityDropdown.new("🟡 MEDIUM - 1.0 spacing (balanced)")
qualityDropdown.new("🟢 HIGH - 0.5 spacing (detailed)")
qualityDropdown.new("💎 ULTRA - 0.25 spacing (PERFECT 1:1)")


qualityDropdown.event:Connect(function(option)
    if option:find("ULTRA") then
        qualityStatus.setText("ULTRA mode: using 0.4 spacing (server-safe)")
    elseif option:find("HIGH") then
        qualityStatus.setText("HIGH mode: 0.5 spacing - good detail")
    elseif option:find("MEDIUM") then
        qualityStatus.setText("MEDIUM mode: 1.0 spacing - balanced")
    else
        qualityStatus.setText("LOW mode: 2.0 spacing - fast")
    end
end)
settingsFolder.new("switch", {
    text = "🔄 Auto-adjust quality",
    value = true,
}).event:Connect(function(state)
    objSettings.AutoAdjust = state
end)

local qualityStatus = objTab.new("label", {
    text = "ULTRA mode uses 0.4 spacing (safe)"
})



local blockDropdown = settingsFolder.new("dropdown", {
    text = "🧱 Block Type",
})

for _, part in next, workspaceChildren(BuildingParts), nil do
    local name = part.Name
    if string.sub(name, #name - 4, #name) == "Block" then
        blockDropdown.new(name)
    end
end

blockDropdown.event:Connect(function(option)
    objSettings.BlockType = option
end)

settingsFolder.new("input", {
    text = "📏 Model Scale",
    placeholder = "1.0",
}).event:Connect(function(value)
    objSettings.Scale = tonumber(value) or 1.0
    print("Scale set to:", objSettings.Scale)
end)

local advancedSwitch = settingsFolder.new("switch", {
    text = "✨ Advanced Mode (non-uniform scaling)",
    value = true,
})

advancedSwitch.event:Connect(function(state)
    objSettings.AdvancedMode = state
    if state then
        print("✅ Advanced mode ENABLED - blocks will have custom sizes")
    else
        print("⚠️ Advanced mode DISABLED - using uniform blocks")
    end
end)

local rotationSwitch = settingsFolder.new("switch", {
    text = "🔄 Smooth Rotation (follows surface)",
    value = true,
})

rotationSwitch.event:Connect(function(state)
    objSettings.SmoothRotation = state
end)

settingsFolder.open()

local controlFolder = objTab.new("folder", {
    text = "🎮 Controls",
})

controlFolder.new("button", {
    text = "👁️ Preview Model (Advanced)",
}).event:Connect(X.PreviewOBJModel)

controlFolder.new("button", {
    text = "📊 Count Required Blocks",
}).event:Connect(X.EstimateOBJBlocks)

controlFolder.new("button", {
    text = "🏗️ Build Model",
}).event:Connect(X.BuildOBJModel)

controlFolder.new("button", {
    text = "🔗 Check Connections",
}).event:Connect(X.VisualizeConnections)

controlFolder.open()

function X.TestServerResponse()
    if not objSettings.SelectedFile then
        print("No file selected")
        return
    end
    
    print("🔍 Testing server response...")
    local voxelData = X.SendToServer(objSettings.SelectedFile, objSettings.Quality, objSettings.AdvancedMode)
    
    if not voxelData then
        print("❌ No response from server")
        return
    end
    
    print("\n=== SERVER RESPONSE DEBUG ===")
    print("Response type:", type(voxelData))
    
    if type(voxelData) == "table" then
        print("Table keys:")
        for k, v in pairs(voxelData) do
            print(string.format("  %s: %s", k, type(v)))
            if k == "voxels" and type(v) == "table" then
                print("    voxels count: " .. #v)
                if #v > 0 then
                    print("    First voxel:")
                    for k2, v2 in pairs(v[1]) do
                        print(string.format("      %s: %s", k2, type(v2)))
                    end
                end
            elseif k == "positions" and type(v) == "table" then
                print("    positions count: " .. #v)
            end
        end
    end
    
    print("\n📊 Summary:")
    if voxelData.voxels then
        print("  voxels array: " .. #voxelData.voxels)
    end
    if voxelData.positions then
        print("  positions array: " .. #voxelData.positions)
    end
    if voxelData.voxel_count then
        print("  voxel_count: " .. voxelData.voxel_count)
    end
end

controlFolder.new("button", {
    text = "🔍 Debug Server Response",
}).event:Connect(X.TestServerResponse)


task.spawn(function()
    task.wait(2)
    local fileCount = refreshOBJFiles()
    print(string.format("Found %d .OBJ files", fileCount))
    
    qualityDropdown.set("💎 ULTRA - 0.25 spacing (PERFECT 1:1)")
    blockDropdown.set("WoodBlock")
    advancedSwitch.set(true)
    rotationSwitch.set(true)
    
    print("✅ Advanced 3D Model Loader initialized")
    X.SetStatus("Ready - Select an OBJ file")
end)


function X.ClearOBJPreview()
    X.ClearPreview()
    X.SetStatus("Preview cleared")
end

controlFolder.new("button", {
    text = "🗑️ Clear Preview",
}).event:Connect(X.ClearOBJPreview)

local adjustersTab = window.new({ text = "Adjusters" })

local positionFolder = adjustersTab.new("folder", {
    text = "Position Offset",
})
positionFolder.new("input", {
    text = "Move Multiplier",
    placeholder = "1",
}).event:Connect(function(value)
    moveMultiplier = tonumber(value) or 1
end)

positionFolder.new("button", {
    text = "Move Up",
}).event:Connect(function()
    X.UpdatePreview(Vector3_new(0, moveMultiplier, 0))
end)

positionFolder.new("button", {
    text = "Move Down",
}).event:Connect(function()
    X.UpdatePreview(Vector3_new(0, -moveMultiplier, 0))
end)

positionFolder.new("button", {
    text = "Move Left",
}).event:Connect(function()
    X.UpdatePreview(Vector3_new(moveMultiplier, 0, 0))
end)

positionFolder.new("button", {
    text = "Move Right",
}).event:Connect(function()
    X.UpdatePreview(Vector3_new(-moveMultiplier, 0, 0))
end)

positionFolder.new("button", {
    text = "Move Forwards",
}).event:Connect(function()
    X.UpdatePreview(Vector3_new(0, 0, moveMultiplier))
end)

positionFolder.new("button", {
    text = "Move Backwards",
}).event:Connect(function()
    X.UpdatePreview(Vector3_new(0, 0, -moveMultiplier))
end)
positionFolder.open()

local rotationFolder = adjustersTab.new("folder", {
    text = "Rotation Offset",
})
local rotXSlider = rotationFolder.new("slider", {
    text = "X",
    min = 0,
    max = 360,
    value = rotX,
})
rotXSlider.event:Connect(function(value)
    rotX = value
    X.UpdatePreview()
end)

local rotYSlider = rotationFolder.new("slider", {
    text = "Y",
    min = 0,
    max = 360,
    value = rotY,
})
rotYSlider.event:Connect(function(value)
    rotY = value
    X.UpdatePreview()
end)

local rotZSlider = rotationFolder.new("slider", {
    text = "Z",
    min = 0,
    max = 360,
    value = rotZ,
})
rotZSlider.event:Connect(function(value)
    rotZ = value
    X.UpdatePreview()
end)
rotationFolder.open()

local otherFolder = adjustersTab.new("folder", {
    text = "Other",
})
otherFolder.new("input", {
    text = "Size %",
    placeholder = "100",
}).event:Connect(function(value)
    X.ClearPreview()
    X.PreviewFile(selectedFile, tonumber(value) / 100)
end)

otherFolder.new("button", {
    text = "Mirror Build",
}).event:Connect(X.MirrorBuild)

otherFolder.new("button", {
    text = "Ground Build",
}).event:Connect(function()
    local previewBlocks = BuildPreview:GetChildren()
    if #previewBlocks == 0 then
        return
    end
    
    local lowestY = math.huge
    for _, block in ipairs(previewBlocks) do
        if block:FindFirstChild("PPart") then
            local part = block.PPart
            local partBottom = part.Position.Y - (part.Size.Y / 2)
            if partBottom < lowestY then
                lowestY = partBottom
            end
        end
    end
    
    local plot = X.GetPlot()
    if not plot then return end
    
    local groundLevel = plot.Position.Y + 5.1
    local moveAmount = groundLevel - lowestY
    
    for _, block in ipairs(previewBlocks) do
        if block:FindFirstChild("PPart") then
            block.PPart.CFrame = block.PPart.CFrame + Vector3.new(0, moveAmount, 0)
        end
    end
end)

otherFolder.new("button", {
    text = "Center Build",
}).event:Connect(function()
    local previewBlocks = BuildPreview:GetChildren()
    if #previewBlocks == 0 then
        return
    end    

    local plot = X.GetPlot()
    if not plot then
        return
    end
    
    local minX, minY, minZ = math.huge, math.huge, math.huge
    local maxX, maxY, maxZ = -math.huge, -math.huge, -math.huge
    
    for _, block in ipairs(previewBlocks) do
        local part = nil
        if block:FindFirstChild("PPart") then
            part = block.PPart
        elseif block:IsA("BasePart") then
            part = block
        end
        
        if part then
            local size = part.Size
            local position = part.Position
            
            local halfSize = size / 2
            minX = math.min(minX, position.X - halfSize.X)
            minY = math.min(minY, position.Y - halfSize.Y)
            minZ = math.min(minZ, position.Z - halfSize.Z)
            maxX = math.max(maxX, position.X + halfSize.X)
            maxY = math.max(maxY, position.Y + halfSize.Y)
            maxZ = math.max(maxZ, position.Z + halfSize.Z)
        end
    end
    
    local centerPosition = Vector3.new(
        (minX + maxX) / 2,
        (minY + maxY) / 2,
        (minZ + maxZ) / 2
    )
    
    local totalSize = Vector3.new(maxX - minX, maxY - minY, maxZ - minZ)
    
    local plotCenter = plot.Position
    local targetPosition = Vector3.new(
        plotCenter.X,
        plotCenter.Y + totalSize.Y / 2 + 5,
        plotCenter.Z
    )
    
    local offset = targetPosition - centerPosition
    
    for _, block in ipairs(previewBlocks) do
        if block:IsA("Model") then
            if block.PrimaryPart then
                local currentCF = block:GetPrimaryPartCFrame()
                block:SetPrimaryPartCFrame(currentCF + offset)
            else
                local mainPart = block:FindFirstChild("PPart") or block:FindFirstChildWhichIsA("BasePart")
                if mainPart then
                    mainPart.CFrame = mainPart.CFrame + offset
                end
            end
        elseif block:IsA("BasePart") then
            block.CFrame = block.CFrame + offset
        end
    end
    
    rotX = 0
    rotY = 0
    rotZ = 0
    
    if rotXSlider then rotXSlider.set(0) end
    if rotYSlider then rotYSlider.set(0) end
    if rotZSlider then rotZSlider.set(0) end
end)
otherFolder.open()

mainTab:show()

local function anchorTarget(instance)
    local target = instance

    if instance:IsA("Model") then
        target = instance:FindFirstChild("PPart")
    end

    if target and target:IsA("BasePart") and not target.Anchored then
        target.Anchored = true
    end
end

local function updateHighlight()
    local hasPreviewObjects = false

    for _, child in ipairs(BuildPreview:GetChildren()) do
        if child:IsA("Model") or child:IsA("BasePart") then
            hasPreviewObjects = true
            break
        end
    end

    if hasPreviewObjects then
        if MainHighlight.Adornee ~= BuildPreview then
            MainHighlight.Adornee = BuildPreview
        end
        MainHighlight.Enabled = true
    else
        MainHighlight.Enabled = false
        MainHighlight.Adornee = nil
    end
end

-- Initial setup
for _, child in ipairs(BuildPreview:GetChildren()) do
    anchorTarget(child)
end
updateHighlight()

-- Event-driven updates
BuildPreview.ChildAdded:Connect(function(child)
    if child:IsA("Model") or child:IsA("BasePart") then
        anchorTarget(child)
        updateHighlight()
    end
end)

BuildPreview.ChildRemoved:Connect(function()
    updateHighlight()
end)

task.spawn(function()
    while true do
        task.wait(0.1)
        for _, block in ipairs(workspace.Blocks:GetDescendants()) do
            if block:IsA("Folder") then
                for _, descendant in ipairs(block:GetDescendants()) do
                    if descendant:IsA("IntValue") and descendant.Name == "Health" then
                        local stringValue = Instance.new("StringValue")
                        stringValue.Name = "Health"
                        stringValue.Value = block.Name
                        stringValue.Parent = descendant.Parent
                        descendant:Destroy()
                    end
                end
            end
        end
    end
end)