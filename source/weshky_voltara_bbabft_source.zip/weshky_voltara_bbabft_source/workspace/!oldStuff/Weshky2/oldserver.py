from flask import Flask, request, jsonify
import requests
from PIL import Image, UnidentifiedImageError
from io import BytesIO
import traceback
import urllib.parse
import os
import re
import qrcode
import base64
import numpy as np
from functools import wraps
app = Flask(__name__)

def rgba_to_int(r, g, b, a):
    return (r << 24) | (g << 16) | (b << 8) | a

API_KEY = os.environ.get('API_KEY', 'fd9b1c8e-9a0c-4c3b-8f1e-7a5c8e2d6f4aZ')

def require_api_key(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        # Check header first
        key = request.headers.get('X-API-Key')
        # Fallback to query param
        if not key:
            key = request.args.get('api_key')
        # Fallback to JSON body
        if not key:
            try:
                body = request.get_json(silent=True)
                if isinstance(body, dict):
                    key = body.get('api_key')
            except Exception:
                key = None

        if not key or key != API_KEY:
            return jsonify({"error": "Unauthorized - invalid API key"}), 401
        return f(*args, **kwargs)
    return decorated

@app.route('/image', methods=['POST'])
@require_api_key
def process_image():
    if not request.is_json:
        return "invalid", 400, {'Content-Type': 'text/plain; charset=utf-8'}

    data = request.get_json()
    image_url = data.get('url')

    if not image_url:
        return "invalid", 400, {'Content-Type': 'text/plain; charset=utf-8'}

    try:
        response = requests.get(image_url, timeout=10, stream=True)
        response.raise_for_status()

        img_bytes = BytesIO(response.content)
        img = Image.open(img_bytes)
        img = img.convert("RGBA")

        width, height = img.size
        pixels_data = list(img.getdata())

        processed_pixels = []
        for r, g, b, a in pixels_data:
            processed_pixels.append(rgba_to_int(r, g, b, a))

        return jsonify({
            "dimensions": [width, height],
            "pixels": processed_pixels
        })

    except (requests.exceptions.RequestException, UnidentifiedImageError, IOError):
        traceback.print_exc()
        return "invalid", 400, {'Content-Type': 'text/plain; charset=utf-8'}
    except Exception:
        traceback.print_exc()
        return "invalid", 500, {'Content-Type': 'text/plain; charset=utf-8'}

@app.route('/obj-to-voxels-optimized', methods=['POST'])
@require_api_key
def obj_to_voxels_optimized():
    try:
        data = request.get_json()
        obj_content = data.get('obj_content')
        voxel_size = float(data.get('voxel_size', 2.0))
        scale = float(data.get('scale', 1.0))
        smooth_rotation = data.get('smooth_rotation', True)

        # Ultra quality mode: use 6-7x finer voxel size for near 1:1 recreation
        if smooth_rotation:
            voxel_size = voxel_size * 0.15

        if not obj_content:
            return jsonify({"error": "No OBJ content"}), 400

        # Parse vertices AND faces
        vertices = []
        faces = []
        vertex_index = 0

        for line in obj_content.split('\n'):
            line = line.strip()

            # Parse vertices
            if line.startswith('v ') and not (line.startswith('vt ') or line.startswith('vn ')):
                parts = line.split()
                if len(parts) >= 4:
                    x = float(parts[1]) * scale
                    y = float(parts[2]) * scale
                    z = float(parts[3]) * scale
                    vertices.append((x, y, z))

            # Parse faces
            elif line.startswith('f '):
                parts = line.split()
                face = []
                for i in range(1, len(parts)):
                    vertex_data = parts[i].split('/')
                    vid = int(vertex_data[0])
                    face.append(vid - 1)  # OBJ uses 1-based indexing

                if len(face) >= 3:
                    faces.append(face)

        if not vertices:
            return jsonify({"error": "No vertices found"}), 400

        # Calculate bounds
        min_x = min(v[0] for v in vertices)
        max_x = max(v[0] for v in vertices)
        min_y = min(v[1] for v in vertices)
        max_y = max(v[1] for v in vertices)
        min_z = min(v[2] for v in vertices)
        max_z = max(v[2] for v in vertices)

        center_x = (min_x + max_x) / 2
        center_y = (min_y + max_y) / 2
        center_z = (min_z + max_z) / 2

        # Proper 3D voxelization using face data
        voxel_set = set()
        block_positions = []
        processed = 0
        max_blocks = 500000

        # If we have faces, use proper face-based voxelization
        if faces:
            for face in faces:
                if processed >= max_blocks:
                    break

                # Get triangle vertices
                if len(face) >= 3:
                    v1 = vertices[face[0]]
                    v2 = vertices[face[1]]
                    v3 = vertices[face[2]]

                    # Get bounding box
                    fx_min = min(v1[0], v2[0], v3[0])
                    fx_max = max(v1[0], v2[0], v3[0])
                    fy_min = min(v1[1], v2[1], v3[1])
                    fy_max = max(v1[1], v2[1], v3[1])
                    fz_min = min(v1[2], v2[2], v3[2])
                    fz_max = max(v1[2], v2[2], v3[2])

                    # Voxelize the triangle with proper surface detection
                    x = int(fx_min / voxel_size) * voxel_size
                    while x <= fx_max and processed < max_blocks:
                        y = int(fy_min / voxel_size) * voxel_size
                        while y <= fy_max and processed < max_blocks:
                            z = int(fz_min / voxel_size) * voxel_size
                            while z <= fz_max and processed < max_blocks:
                                key = (round(x, 2), round(y, 2), round(z, 2))

                                if key not in voxel_set:
                                    # Calculate normal and distance
                                    dx1 = v2[0] - v1[0]
                                    dy1 = v2[1] - v1[1]
                                    dz1 = v2[2] - v1[2]
                                    dx2 = v3[0] - v1[0]
                                    dy2 = v3[1] - v1[1]
                                    dz2 = v3[2] - v1[2]

                                    # Cross product for normal
                                    nx = dy1 * dz2 - dz1 * dy2
                                    ny = dz1 * dx2 - dx1 * dz2
                                    nz = dx1 * dy2 - dy1 * dx2
                                    nlen_sq = nx*nx + ny*ny + nz*nz

                                    if nlen_sq > 0:
                                        nlen = nlen_sq ** 0.5
                                        nx /= nlen
                                        ny /= nlen
                                        nz /= nlen

                                        # Distance from voxel center to plane
                                        vx = x + voxel_size/2 - v1[0]
                                        vy = y + voxel_size/2 - v1[1]
                                        vz = z + voxel_size/2 - v1[2]
                                        dist = abs(nx*vx + ny*vy + nz*vz)

                                        # Include voxel if within surface thickness
                                        if dist <= voxel_size * 0.7:
                                            voxel_set.add(key)
                                            block_positions.append([
                                                x - center_x,
                                                y - center_y,
                                                z - center_z
                                            ])
                                            processed += 1
                                z += voxel_size
                            y += voxel_size
                        x += voxel_size
        else:
            # Fallback to vertex-based if no faces
            for v in vertices:
                if processed >= max_blocks:
                    break
                x = int(v[0] / voxel_size) * voxel_size
                y = int(v[1] / voxel_size) * voxel_size
                z = int(v[2] / voxel_size) * voxel_size
                key = (round(x, 2), round(y, 2), round(z, 2))

                if key not in voxel_set:
                    voxel_set.add(key)
                    block_positions.append([x - center_x, y - center_y, z - center_z])
                    processed += 1

        return jsonify({
            "success": True,
            "voxel_count": len(block_positions),
            "positions": block_positions,
            "bounds": {
                "min": [min_x, min_y, min_z],
                "max": [max_x, max_y, max_z],
                "size": [max_x-min_x, max_y-min_y, max_z-min_z]
            },
            "center": [center_x, center_y, center_z],
            "faces_used": len(faces) > 0,
            "total_faces": len(faces),
            "smooth_rotation": smooth_rotation,
            "voxel_size": voxel_size,
            "quality_mode": "ultra" if smooth_rotation else "standard"
        })

    except Exception as e:
        return jsonify({"error": str(e), "traceback": traceback.format_exc()}), 500

@app.route('/qr-code', methods=['POST'])
@require_api_key
def generate_qr_code():
    try:
        data = request.get_json()
        text_content = data.get('text')  # Changed from 'url' to 'text'
        block_size = float(data.get('block_size', 1.0))
        scale = float(data.get('scale', 1.0))
        error_correction = data.get('error_correction', 'M').upper()

        if not text_content:
            return jsonify({"error": "No text content provided"}), 400

        # Map error correction levels
        error_correction_map = {
            'L': qrcode.constants.ERROR_CORRECT_L,
            'M': qrcode.constants.ERROR_CORRECT_M,
            'Q': qrcode.constants.ERROR_CORRECT_Q,
            'H': qrcode.constants.ERROR_CORRECT_H
        }

        ec_level = error_correction_map.get(error_correction, qrcode.constants.ERROR_CORRECT_M)

        # Generate QR code
        qr = qrcode.QRCode(
            version=1,
            error_correction=ec_level,
            box_size=1,
            border=4,
        )

        qr.add_data(text_content)
        qr.make(fit=True)

        # Create QR code matrix
        qr_matrix = qr.get_matrix()

        # Convert to list format
        matrix_list = []
        for row in qr_matrix:
            matrix_list.append([1 if cell else 0 for cell in row])

        size = len(qr_matrix)

        return jsonify({
            "success": True,
            "data": text_content,
            "size": size,
            "matrix": matrix_list,
            "block_count": sum(sum(row) for row in matrix_list),
            "dimensions": [size, size]
        })

    except Exception as e:
        traceback.print_exc()
        return jsonify({"error": str(e), "traceback": traceback.format_exc()}), 500

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5000)