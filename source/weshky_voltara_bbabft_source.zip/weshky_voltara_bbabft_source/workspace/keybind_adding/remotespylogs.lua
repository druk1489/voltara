local args = {
	{
		workspace:WaitForChild("Blocks"):WaitForChild("julia_NakamuraMY"):WaitForChild("Motor"):WaitForChild("BindUp") -- Target
	},
	workspace:WaitForChild("Blocks"):WaitForChild("julia_NakamuraMY"):WaitForChild("Switch"), -- controller 
	-1,
	false
}
game:GetService("Players").LocalPlayer.Character:WaitForChild("BindTool"):WaitForChild("RF"):InvokeServer(unpack(args))

local args = {
	{
		workspace:WaitForChild("Blocks"):WaitForChild("julia_NakamuraMY"):WaitForChild("Motor"):WaitForChild("BindDown")
	},
	workspace:WaitForChild("Blocks"):WaitForChild("julia_NakamuraMY"):WaitForChild("Switch"),
	-1,
	false
}
game:GetService("Players").LocalPlayer.Character:WaitForChild("BindTool"):WaitForChild("RF"):InvokeServer(unpack(args))

local args = {
	{
		workspace:WaitForChild("Blocks"):WaitForChild("julia_NakamuraMY"):WaitForChild("FrontWheel"):WaitForChild("BindRight") -- Target
	},
	workspace:WaitForChild("Blocks"):WaitForChild("julia_NakamuraMY"):WaitForChild("CarSeat"),-- controller 
	100,
	false
}
game:GetService("Players").LocalPlayer.Character:WaitForChild("BindTool"):WaitForChild("RF"):InvokeServer(unpack(args))


local args = {
	{
		workspace:WaitForChild("Blocks"):WaitForChild("julia_NakamuraMY"):WaitForChild("FrontWheel"):WaitForChild("BindUp") -- Target
	},
	workspace:WaitForChild("Blocks"):WaitForChild("julia_NakamuraMY"):WaitForChild("CarSeat"),-- controller 
	119,
	false
}
game:GetService("Players").LocalPlayer.Character:WaitForChild("BindTool"):WaitForChild("RF"):InvokeServer(unpack(args))

local args = {
	{
		workspace:WaitForChild("Blocks"):WaitForChild("julia_NakamuraMY"):WaitForChild("FrontWheel"):WaitForChild("BindLeft") -- Target
	},
	workspace:WaitForChild("Blocks"):WaitForChild("julia_NakamuraMY"):WaitForChild("CarSeat"),-- controller 
	101,
	false
}
game:GetService("Players").LocalPlayer.Character:WaitForChild("BindTool"):WaitForChild("RF"):InvokeServer(unpack(args))

local args = {
	{
		workspace:WaitForChild("Blocks"):WaitForChild("julia_NakamuraMY"):WaitForChild("FrontWheel"):WaitForChild("BindDown") -- Target
	},
	workspace:WaitForChild("Blocks"):WaitForChild("julia_NakamuraMY"):WaitForChild("CarSeat"),-- controller 
	114,
	false
}
game:GetService("Players").LocalPlayer.Character:WaitForChild("BindTool"):WaitForChild("RF"):InvokeServer(unpack(args))



--------------------------------------------------------------------------------------------------------------------------------------------------------------- Unbind Remotespy
--------------------------------------------------------------------------------------------------------------------------------------------------------------- Unbinding only
---------------------------------------------------------------------------------------------------------------------------------------------------------------
---------------------------------------------------------------------------------------------------------------------------------------------------------------
---------------------------------------------------------------------------------------------------------------------------------------------------------------
---------------------------------------------------------------------------------------------------------------------------------------------------------------

local args = {
	{
		workspace:WaitForChild("Blocks"):WaitForChild("julia_NakamuraMY"):WaitForChild("FrontWheel"):WaitForChild("BindRight")
	},
	workspace:WaitForChild("Blocks"):WaitForChild("julia_NakamuraMY"):WaitForChild("Switch"),
	-1,
	true
}
game:GetService("Players").LocalPlayer:WaitForChild("Backpack"):WaitForChild("BindTool"):WaitForChild("RF"):InvokeServer(unpack(args))


local args = {
	{
		workspace:WaitForChild("Blocks"):WaitForChild("julia_NakamuraMY"):WaitForChild("FrontWheel"):WaitForChild("BindUp")
	},
	workspace:WaitForChild("Blocks"):WaitForChild("julia_NakamuraMY"):WaitForChild("Switch"),
	-1,
	true
}
game:GetService("Players").LocalPlayer:WaitForChild("Backpack"):WaitForChild("BindTool"):WaitForChild("RF"):InvokeServer(unpack(args))


local args = {
	{
		workspace:WaitForChild("Blocks"):WaitForChild("julia_NakamuraMY"):WaitForChild("FrontWheel"):WaitForChild("BindLeft")
	},
	workspace:WaitForChild("Blocks"):WaitForChild("julia_NakamuraMY"):WaitForChild("Switch"),
	-1,
	true
}
game:GetService("Players").LocalPlayer:WaitForChild("Backpack"):WaitForChild("BindTool"):WaitForChild("RF"):InvokeServer(unpack(args))


local args = {
	{
		workspace:WaitForChild("Blocks"):WaitForChild("julia_NakamuraMY"):WaitForChild("FrontWheel"):WaitForChild("BindDown")
	},
	workspace:WaitForChild("Blocks"):WaitForChild("julia_NakamuraMY"):WaitForChild("Switch"),
	-1,
	true
}
game:GetService("Players").LocalPlayer:WaitForChild("Backpack"):WaitForChild("BindTool"):WaitForChild("RF"):InvokeServer(unpack(args))

local args = {
	{
		workspace:WaitForChild("Blocks"):WaitForChild("julia_NakamuraMY"):WaitForChild("FrontWheel"):WaitForChild("BindRight")
	},
	workspace:WaitForChild("Blocks"):WaitForChild("julia_NakamuraMY"):WaitForChild("CarSeat"),
	-1,
	true
}
game:GetService("Players").LocalPlayer:WaitForChild("Backpack"):WaitForChild("BindTool"):WaitForChild("RF"):InvokeServer(unpack(args))


local args = {
	{
		workspace:WaitForChild("Blocks"):WaitForChild("julia_NakamuraMY"):WaitForChild("FrontWheel"):WaitForChild("BindUp")
	},
	workspace:WaitForChild("Blocks"):WaitForChild("julia_NakamuraMY"):WaitForChild("CarSeat"),
	-1,
	true
}
game:GetService("Players").LocalPlayer:WaitForChild("Backpack"):WaitForChild("BindTool"):WaitForChild("RF"):InvokeServer(unpack(args))


local args = {
	{
		workspace:WaitForChild("Blocks"):WaitForChild("julia_NakamuraMY"):WaitForChild("FrontWheel"):WaitForChild("BindLeft")
	},
	workspace:WaitForChild("Blocks"):WaitForChild("julia_NakamuraMY"):WaitForChild("CarSeat"),
	-1,
	true
}
game:GetService("Players").LocalPlayer:WaitForChild("Backpack"):WaitForChild("BindTool"):WaitForChild("RF"):InvokeServer(unpack(args))


local args = {
	{
		workspace:WaitForChild("Blocks"):WaitForChild("julia_NakamuraMY"):WaitForChild("FrontWheel"):WaitForChild("BindDown")
	},
	workspace:WaitForChild("Blocks"):WaitForChild("julia_NakamuraMY"):WaitForChild("CarSeat"),
	-1,
	true
}
game:GetService("Players").LocalPlayer:WaitForChild("Backpack"):WaitForChild("BindTool"):WaitForChild("RF"):InvokeServer(unpack(args))

local args = {
	{
		workspace:WaitForChild("Blocks"):WaitForChild("julia_NakamuraMY"):WaitForChild("Piston"):WaitForChild("BindUp")
	},
	workspace:WaitForChild("Blocks"):WaitForChild("julia_NakamuraMY"):WaitForChild("Switch"),
	-1,
	true
}
game:GetService("Players").LocalPlayer:WaitForChild("Backpack"):WaitForChild("BindTool"):WaitForChild("RF"):InvokeServer(unpack(args))


local args = {
	{
		workspace:WaitForChild("Blocks"):WaitForChild("julia_NakamuraMY"):WaitForChild("Piston"):WaitForChild("BindDown")
	},
	workspace:WaitForChild("Blocks"):WaitForChild("julia_NakamuraMY"):WaitForChild("Switch"),
	-1,
	true
}
game:GetService("Players").LocalPlayer:WaitForChild("Backpack"):WaitForChild("BindTool"):WaitForChild("RF"):InvokeServer(unpack(args))
