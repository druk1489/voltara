local library = loadstring(game:HttpGet("https://raw.githubusercontent.com/Vyrusspcs/library/refs/heads/main/tech.lua"))()



local window = library:window({name = "Voltara", suffix = " BABFT", gameInfo = "Voltara Hub for Build a Boat for Treasure "})

window:seperator({name = "Main Features"})

-- Auto Build Tab
do
    local main, database = window:tab({name = "Auto Build", icon = "hammer", tabs = {"Main", "Database"}})

    -- Main sub-tab: two columns side by side
    local page = main:sub_tab({size = 2})

    do -- Left column
        local column = page:column({})
        local section = column:section({name = "Build Settings", default = true})
        section:toggle({name = "Auto Build", seperator = true, callback = function(bool) print("Auto Build:", bool) end})
        section:toggle({name = "Anti-AFK", seperator = true})
        section:dropdown({name = "Build Mode", items = {"Normal", "Fast", "Instant"}, default = "Normal", seperator = true})
        section:toggle({name = "Auto Collect Gold", seperator = true})
        section:toggle({name = "Loop Build", seperator = true})
    end

    do -- Right column
        local column = page:column({})
        local section = column:section({name = "Boat Options", default = true})
        section:dropdown({name = "Saved Boats", items = {"Boat 1", "Boat 2", "Boat 3"}, default = "Boat 1", seperator = true})
        section:toggle({name = "Auto Save Boat", seperator = true})
        section:toggle({name = "Delete Old Boat", seperator = true})
        section:toggle({name = "Notify on Complete", seperator = true, callback = function(bool) print("Notify:", bool) end})
    end

    -- Database sub-tab: two columns
    local db_page = database:sub_tab({size = 2})

    do
        local column = db_page:column({})
        local section = column:section({name = "Boat Database", default = true})
        section:label({name = "Browse community boats", info = "Select a boat from the database to auto-build it.\nBoats are sorted by popularity."})
        section:dropdown({name = "Category", items = {"Popular", "Speed", "Tank", "Troll", "Custom"}, default = "Popular", seperator = true})
        section:dropdown({name = "Sort By", items = {"Newest", "Most Used", "Rating"}, default = "Newest", seperator = true})
    end

    do
        local column = db_page:column({})
        local section = column:section({name = "Import / Export", default = true})
        section:toggle({name = "Auto Import on Join", seperator = true})
        section:toggle({name = "Share Builds", seperator = true})
    end
end

-- Autofarm Tab
do
    local main, webhook = window:tab({name = "Autofarm", tabs = {"Main", "Webhook"}})

    local page = main:sub_tab({size = 2})

    do
        local column = page:column({})
        local section = column:section({name = "Farm Settings", default = true})
        section:toggle({name = "Enable Autofarm", seperator = true, callback = function(bool) print("Autofarm:", bool) end})
        section:dropdown({name = "Farm Type", items = {"Gold", "Quest", "Chest", "All"}, default = "Gold", seperator = true})
        section:toggle({name = "Auto Collect Chests", seperator = true})
        section:toggle({name = "Anti-AFK", seperator = true})
        section:toggle({name = "Auto Rejoin", seperator = true})
    end

    do
        local column = page:column({})
        local section = column:section({name = "Stats", default = true})
        section:label({name = "Session Stats", info = "Tracks your current farming session.\nGold earned, chests opened, time elapsed."})
        section:toggle({name = "Show Stats Overlay", seperator = true})
        section:toggle({name = "Log to Console", seperator = true})
    end

    -- Webhook sub-tab
    local wh_page = webhook:sub_tab({size = 2})

    do
        local column = wh_page:column({})
        local section = column:section({name = "Discord Webhook", default = true})
        section:toggle({name = "Enable Webhook", seperator = true})
        section:toggle({name = "Send on Gold Milestone", seperator = true})
        section:toggle({name = "Send on Chest Found", seperator = true})
        section:toggle({name = "Send on Error", seperator = true})
    end

    do
        local column = wh_page:column({})
        local section = column:section({name = "Webhook Config", default = true})
        section:dropdown({name = "Interval", items = {"1 min", "5 min", "10 min", "30 min"}, default = "5 min", seperator = true})
        section:toggle({name = "Include Screenshot", seperator = true})
    end
end

-- Loaders Tab
do
    local img_loader, shape_loader, text_loader, qr_loader = window:tab({name = "Loaders", tabs = {"Image Loader", "Shape Loader", "Text Loader", "QR Code Loader"}})

    -- Image Loader
    do
        local page = img_loader:sub_tab({size = 2})

        do
            local column = page:column({})
            local section = column:section({name = "Image Settings", default = true})
            section:toggle({name = "Enable Image Loader", seperator = true, callback = function(bool) print("Image Loader:", bool) end})
            section:dropdown({name = "Resolution", items = {"32x32", "64x64", "128x128", "256x256"}, default = "64x64", seperator = true})
            section:toggle({name = "Dithering", seperator = true})
            section:dropdown({name = "Palette", items = {"Full", "Limited", "Grayscale"}, default = "Full", seperator = true})
        end

        do
            local column = page:column({})
            local section = column:section({name = "Build Options", default = true})
            section:dropdown({name = "Block Type", items = {"Wood", "Plastic", "Glass", "Metal"}, default = "Wood", seperator = true})
            section:toggle({name = "Auto Scale", seperator = true})
            section:toggle({name = "Flatten Image", seperator = true})
        end
    end

    -- Shape Loader
    do
        local page = shape_loader:sub_tab({size = 2})

        do
            local column = page:column({})
            local section = column:section({name = "Shape Settings", default = true})
            section:dropdown({name = "Shape", items = {"Circle", "Sphere", "Pyramid", "Cylinder", "Cube"}, default = "Sphere", seperator = true})
            section:toggle({name = "Hollow", seperator = true})
            section:toggle({name = "Smooth Edges", seperator = true})
        end

        do
            local column = page:column({})
            local section = column:section({name = "Dimensions", default = true})
            section:dropdown({name = "Size", items = {"Small", "Medium", "Large", "Custom"}, default = "Medium", seperator = true})
            section:dropdown({name = "Material", items = {"Wood", "Plastic", "Glass", "Metal"}, default = "Wood", seperator = true})
            section:toggle({name = "Auto Place", seperator = true, callback = function(bool) print("Auto Place:", bool) end})
        end
    end

    -- Text Loader
    do
        local page = text_loader:sub_tab({size = 2})

        do
            local column = page:column({})
            local section = column:section({name = "Text Settings", default = true})
            section:toggle({name = "Enable Text Loader", seperator = true})
            section:dropdown({name = "Font", items = {"ProggyTiny", "MonoSpace", "Tahoma", "Arial"}, default = "MonoSpace", seperator = true})
            section:dropdown({name = "Size", items = {"Small", "Medium", "Large"}, default = "Medium", seperator = true})
        end

        do
            local column = page:column({})
            local section = column:section({name = "Style", default = true})
            section:toggle({name = "Bold", seperator = true})
            section:toggle({name = "3D Text", seperator = true})
            local toggle = section:toggle({name = "Custom Color", seperator = true})
            toggle:colorpicker({})
        end
    end

    -- QR Code Loader
    do
        local page = qr_loader:sub_tab({size = 2})

        do
            local column = page:column({})
            local section = column:section({name = "QR Settings", default = true})
            section:toggle({name = "Enable QR Loader", seperator = true})
            section:dropdown({name = "Error Correction", items = {"Low", "Medium", "Quartile", "High"}, default = "Medium", seperator = true})
            section:dropdown({name = "Block Size", items = {"1x1", "2x2", "3x3"}, default = "1x1", seperator = true})
        end

        do
            local column = page:column({})
            local section = column:section({name = "Output", default = true})
            section:toggle({name = "Auto Build", seperator = true})
            section:toggle({name = "Preview First", seperator = true})
        end
    end
end

-- 3D Models Tab
do
    local obj_loader = window:tab({name = "3D Models", tabs = {".OBJ Loader"}})

    local page = obj_loader:sub_tab({size = 2})

    do
        local column = page:column({})
        local section = column:section({name = "Model Settings", default = true})
        section:toggle({name = "Enable OBJ Loader", seperator = true, callback = function(bool) print("OBJ Loader:", bool) end})
        section:dropdown({name = "Detail Level", items = {"Low", "Medium", "High", "Ultra"}, default = "Medium", seperator = true})
        section:toggle({name = "Wireframe Mode", seperator = true})
        section:toggle({name = "Fill Faces", seperator = true})
        section:dropdown({name = "Material", items = {"Wood", "Plastic", "Glass", "Metal", "Ice"}, default = "Wood", seperator = true})
    end

    do
        local column = page:column({})
        local section = column:section({name = "Transform", default = true})
        section:dropdown({name = "Scale", items = {"0.5x", "1x", "2x", "5x", "10x"}, default = "1x", seperator = true})
        section:toggle({name = "Auto Center", seperator = true})
        section:toggle({name = "Preview Before Build", seperator = true})
        section:toggle({name = "Optimize Mesh", seperator = true, info = "Reduces block count by merging similar faces.\nMay reduce visual quality slightly."})
    end
end

window:seperator({name = "Extra Features"})

-- Example Tab (ESP style)
do
    local enemies, teammates, self_section = window:tab({name = "Example", tabs = {"Enemies", "Teammates", "Self"}})

    for _, tab in {enemies, teammates, self_section} do
        local header_col = tab:column({})
        local header = header_col:section({name = "General", default = true, toggle = false})
        header:label({name = "This is a title!", info = "Hello there this is a paragraph.. adawdawdawdHello there this is a paragraph.. adawdawdawdHello there this is a paragraph.. adawdawdawdHello there this is a paragraph.. adawdawdawd\nextra info here ig"})

        local page = tab:sub_tab({order = -10000, size = 2})

        for i = 1, 2 do
            local column = page:column({})
            local section = column:section({name = "General", default = true})
            section:toggle({name = "Enable ESP", seperator = true, callback = function(bool) print(bool) end})
            section:toggle({name = "Through walls", seperator = true})
            local toggle = section:toggle({name = "Shared ESP", seperator = true}):colorpicker({})

            -- Sub Section Example
                local toggle = section:toggle({name = "Name", seperator = true})
                toggle:colorpicker({})
                local sub_section = toggle:settings({})
                sub_section:toggle({name = "Show Display Names", seperator = true})
                sub_section:dropdown({name = "Font Name", items = {"ProggyTiny", "MonoSpace", "Tahoma"}, default = "MonoSpace", seperator = true})
                sub_section:colorpicker({name = "Another Colorpicker why not", seperator = true})
                sub_section:keybind({name = "Keybind", callback = function(bool) print(bool) end, info = "Hello there this is a paragraph.. adawdawdawdHello there this is a paragraph.. adawdawdawdHello there this is a paragraph.. adawdawdawdHello there this is a paragraph.. adawdawdawd\nextra info here ig"})
            --

            section:toggle({name = "Weapon", seperator = true, info = "Hello there this is a paragraph.. adawdawdawdHello there this is a paragraph.. adawdawdawdHello there this is a paragraph.. adawdawdawdHello there this is a paragraph.. adawdawdawd\nextra info here ig"}):colorpicker({})
            section:dropdown({name = "Flags", items = {"Scoped", "Flashed", "Knocked", "Touched"}, default = {"Scoped", "Flashed", "Knocked"}, multi = true, seperator = true})
            section:toggle({name = "Other Shit", seperator = false}):colorpicker({})
        end
    end
end



library:init_config(window)
