-- Decompiled with Velocity Script Decompiler
local v_u_1 = game.Players.LocalPlayer
local v_u_2 = {
    0,
    0,
    0,
    100,
    200,
    300,
    400,
    500,
    600,
    700,
    800,
    900,
    1000,
    1100,
    1200,
    1300,
    1400,
    1500,
    1600,
    1700,
    1800,
    1900,
    2000,
    2100,
    2200,
    2300,
    2400,
    2500,
    2600,
    2700,
    2800,
    2900,
    3000,
    3100,
    3200,
    3300,
    3400,
    3500,
    3600,
    3700,
    3800,
    3900,
    4000,
    4100,
    4200,
    4300,
    4400,
    4500,
    4600,
    4700,
    4800,
    4900,
    5000,
    5100,
    5200,
    5300,
    5400,
    5500,
    5600,
    5700,
    5800,
    5900,
    6000,
    6100,
    6200,
    6300,
    6400,
    6500,
    6600,
    6700,
    6800,
    6900,
    7000,
    7100,
    7200,
    7300,
    7400,
    7500,
    7600,
    7700,
    7800,
    7900,
    8000,
    8100,
    8200,
    8300,
    8400,
    8500,
    8600,
    8700,
    8800,
    8900,
    9000,
    9100,
    9200,
    9300,
    9400,
    9500,
    9600,
    9700,
    9800,
    9900,
    10000
}
function active()
    -- upvalues: (copy) v_u_1, (copy) v_u_2
    local v3 = v_u_2[getNumOfSlotsOwned(v_u_1) + 1]
    if v3 then
        script.Parent.Parent.Parent.PromptBuySlot.Buy2.PriceLable.Text = tostring(v3)
        script.Parent.Parent.Parent.PromptBuySlot.Buy2.BackgroundColor3 = Color3.fromRGB(0, 132, 255)
        script.Parent.Parent.Parent.PromptBuySlot.Buy2.GoldImage.ImageColor3 = Color3.fromRGB(255, 255, 255)
    else
        script.Parent.Parent.Parent.PromptBuySlot.Buy2.PriceLable.Text = ""
        script.Parent.Parent.Parent.PromptBuySlot.Buy2.BackgroundColor3 = Color3.fromRGB(91, 91, 91)
        script.Parent.Parent.Parent.PromptBuySlot.Buy2.GoldImage.ImageColor3 = Color3.fromRGB(91, 91, 91)
    end
    script.Parent.Parent.Parent.PromptBuySlot.Visible = true
end
function getNumOfSlotsOwned(p4)
    local v5 = true
    local v6 = 3
    while v5 do
        local v7 = p4.OtherData
        local v8 = v6 + 1
        if v7:FindFirstChild("Slot" .. tostring(v8)) then
            v6 = v6 + 1
            v5 = true
        else
            v5 = false
        end
    end
    return v6
end
script.Parent.MouseButton1Click:Connect(active)
