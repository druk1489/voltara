const copyButton = document.getElementById("copyLoadstring");
const codeElement = document.getElementById("loadstringCode");
const copyState = document.getElementById("copyState");

if (copyButton && codeElement) {
  copyButton.addEventListener("click", async () => {
    const text = codeElement.textContent || "";
    try {
      await navigator.clipboard.writeText(text);
      copyState.textContent = "Loadstring copied.";
      window.setTimeout(() => {
        copyState.textContent = "";
      }, 2200);
    } catch (_err) {
      copyState.textContent = "Clipboard failed. Copy manually from the code block.";
    }
  });
}
